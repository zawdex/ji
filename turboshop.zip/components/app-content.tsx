"use client"

import { useAppStore } from "@/lib/store"
import { BottomNavigation } from "./bottom-navigation"
import { NotificationArea } from "./notification"
import { HomePage } from "./pages/home-page"
import { ShopPage } from "./pages/shop-page"
import { CategoryPage } from "./pages/category-page"
import { RechargePage } from "./pages/recharge-page"
import { OrdersPage } from "./pages/orders-page"
import { ProfilePage } from "./pages/profile-page"
import { LoadingSpinner } from "./loading-spinner"

export function AppContent() {
  const { currentPage, isLoading } = useAppStore()

  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <HomePage />
      case "shop":
        return <ShopPage />
      case "category":
        return <CategoryPage />
      case "recharge":
        return <RechargePage />
      case "orders":
        return <OrdersPage />
      case "profile":
        return <ProfilePage />
      default:
        return <HomePage />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <NotificationArea />
      {isLoading && <LoadingSpinner />}
      {renderPage()}
      <BottomNavigation />
    </div>
  )
}
