"use client"

import { Ban } from "lucide-react"
import { Button } from "@/components/ui/button"

export function ErrorScreen() {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-red-500 to-pink-600 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl p-8 max-w-md w-full mx-4 text-center shadow-2xl">
        <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Ban className="h-8 w-8 text-red-500" />
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
        <p className="text-gray-600 mb-6">Telegram UserID not found. Please open this application from Telegram.</p>
        <Button
          onClick={() => window.location.reload()}
          className="w-full bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600"
        >
          Retry
        </Button>
      </div>
    </div>
  )
}
