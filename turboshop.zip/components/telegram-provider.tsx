"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { getTelegramUser, initTelegramApp } from "@/lib/telegram"
import { useAppStore } from "@/lib/store"
import type { TelegramUser } from "@/lib/types"
import { ErrorScreen } from "./error-screen"
import { LoadingSpinner } from "./loading-spinner"

interface TelegramContextType {
  user: TelegramUser | null
  isReady: boolean
}

const TelegramContext = createContext<TelegramContextType>({
  user: null,
  isReady: false,
})

export function useTelegram() {
  return useContext(TelegramContext)
}

export function TelegramProvider({ children }: { children: ReactNode }) {
  const [isReady, setIsReady] = useState(false)
  const [hasError, setHasError] = useState(false)
  const { setTelegramUser, telegramUser } = useAppStore()

  useEffect(() => {
    // Initialize Telegram WebApp
    initTelegramApp()

    // Get user data
    const user = getTelegramUser()

    if (user) {
      setTelegramUser(user)
      setIsReady(true)
    } else {
      // In production, show error if no Telegram user
      if (process.env.NODE_ENV === "production") {
        setHasError(true)
      } else {
        // Development fallback
        setTelegramUser({
          id: 6468293575,
          first_name: "Demo",
          last_name: "User",
          username: "demouser",
          language_code: "en",
          is_premium: true,
          photo_url: "https://via.placeholder.com/150?text=User",
        })
        setIsReady(true)
      }
    }
  }, [setTelegramUser])

  if (hasError) {
    return <ErrorScreen />
  }

  if (!isReady) {
    return <LoadingSpinner />
  }

  return <TelegramContext.Provider value={{ user: telegramUser, isReady }}>{children}</TelegramContext.Provider>
}
