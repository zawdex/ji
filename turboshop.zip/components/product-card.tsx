"use client"

import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import type { Product } from "@/lib/types"

interface ProductCardProps {
  product: Product
  onClick: () => void
  showStock?: boolean
}

export function ProductCard({ product, onClick, showStock = false }: ProductCardProps) {
  const stockClass =
    product.stock > 10
      ? "bg-green-100 text-green-800"
      : product.stock > 0
        ? "bg-yellow-100 text-yellow-800"
        : "bg-red-100 text-red-800"

  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
    >
      <div className="text-center">
        <div className="relative w-20 h-20 mx-auto mb-3">
          <Image
            src={product.image_url || "/placeholder.svg?height=80&width=80&query=game item"}
            alt={product.name}
            fill
            className="object-contain rounded-lg"
          />
        </div>
        <h3 className="font-semibold text-gray-800 text-sm mb-1 line-clamp-2">{product.name}</h3>
        <p className="text-blue-600 font-bold">{product.price.toLocaleString()} MMK</p>
        <div className="flex items-center justify-center mt-2 gap-1 flex-wrap">
          <Badge variant="secondary" className="text-xs">
            {product.category}
          </Badge>
          {showStock && <Badge className={stockClass}>Stock: {product.stock}</Badge>}
        </div>
      </div>
    </div>
  )
}
