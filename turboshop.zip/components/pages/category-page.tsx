"use client"

import { useState, useMemo } from "react"
import { ChevronLeft, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product-card"
import { ProductModal } from "@/components/product-modal"
import { useAppStore } from "@/lib/store"
import type { Product } from "@/lib/types"

export function CategoryPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const { products, currentCategory, setCurrentPage, setCurrentCategory } = useAppStore()

  const categoryProducts = useMemo(() => {
    return products.filter((p) => p.category === currentCategory)
  }, [products, currentCategory])

  const filteredProducts = useMemo(() => {
    if (!searchQuery) return categoryProducts

    const query = searchQuery.toLowerCase()
    return categoryProducts.filter(
      (p) => p.name.toLowerCase().includes(query) || p.description.toLowerCase().includes(query),
    )
  }, [categoryProducts, searchQuery])

  const handleBack = () => {
    setCurrentCategory(null)
    setCurrentPage("home")
  }

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }

  return (
    <div className="container mx-auto px-4 pt-6 pb-24">
      {/* Header */}
      <div className="flex items-center mb-6">
        <Button
          variant="ghost"
          size="icon"
          className="w-10 h-10 rounded-full bg-white shadow-md mr-3"
          onClick={handleBack}
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <div>
          <h2 className="text-xl font-bold text-gray-800">{currentCategory}</h2>
          <p className="text-gray-600 text-sm">Browse all {currentCategory} products</p>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl p-3 shadow-md mb-6">
        <div className="flex items-center">
          <Search className="h-5 w-5 text-gray-400 ml-2 mr-3" />
          <Input
            type="text"
            placeholder="Search in category..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="border-0 focus-visible:ring-0 shadow-none"
          />
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-2 gap-4">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} onClick={() => handleProductClick(product)} showStock />
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <Search className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No products found in this category</p>
        </div>
      )}

      {/* Product Modal */}
      <ProductModal product={selectedProduct} open={isModalOpen} onOpenChange={setIsModalOpen} />
    </div>
  )
}
