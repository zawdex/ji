"use client"

import type React from "react"

import { useEffect, useState, useRef } from "react"
import { ChevronLeft, Gem, CloudUpload, Send, Loader2, CheckCircle, Clock, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { api } from "@/lib/api"
import { useAppStore } from "@/lib/store"
import { showNotification } from "@/components/notification"
import type { PaymentMethod, RechargeRequest } from "@/lib/types"
import { cn } from "@/lib/utils"

const PRESET_AMOUNTS = [1000, 5000, 10000, 20000, 50000]

export function RechargePage() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([])
  const [rechargeHistory, setRechargeHistory] = useState<RechargeRequest[]>([])
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null)
  const [customAmount, setCustomAmount] = useState("")
  const [selectedMethod, setSelectedMethod] = useState<string>("")
  const [screenshot, setScreenshot] = useState<File | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const fileInputRef = useRef<HTMLInputElement>(null)
  const { balance, setBalance, setCurrentPage } = useAppStore()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      const [methods, history] = await Promise.all([api.getPaymentMethods(), api.getRechargeHistory()])

      setPaymentMethods(methods)
      setRechargeHistory(history)

      if (methods.length > 0) {
        setSelectedMethod(String(methods[0].id))
      }
    } catch (error) {
      console.error("Failed to load recharge data:", error)
      showNotification("Failed to load payment methods", "error")
    }
  }

  const handleAmountSelect = (amount: number) => {
    setSelectedAmount(amount)
    setCustomAmount(String(amount))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (file.size > 5 * 1024 * 1024) {
      showNotification("File size must be less than 5MB", "error")
      return
    }

    if (!file.type.match("image.*")) {
      showNotification("Please select an image file", "error")
      return
    }

    setScreenshot(file)
    showNotification("Screenshot selected successfully", "success")
  }

  const handleSubmit = async () => {
    const amount = Number.parseFloat(customAmount)

    if (!amount || amount <= 0) {
      showNotification("Please enter a valid amount", "warning")
      return
    }

    if (!selectedMethod) {
      showNotification("Please select a payment method", "warning")
      return
    }

    if (!screenshot) {
      showNotification("Please upload a payment screenshot", "warning")
      return
    }

    setIsSubmitting(true)

    try {
      const result = await api.submitRecharge(amount, Number.parseInt(selectedMethod), screenshot)

      showNotification(`Recharge request submitted! Request ID: #${result.recharge_id}`, "success")

      // Reset form
      setSelectedAmount(null)
      setCustomAmount("")
      setScreenshot(null)
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }

      // Reload history
      const history = await api.getRechargeHistory()
      setRechargeHistory(history)
    } catch (error) {
      const message = error instanceof Error ? error.message : "Recharge failed"
      showNotification(message, "error")
    } finally {
      setIsSubmitting(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-4 w-4" />
      case "pending":
        return <Clock className="h-4 w-4" />
      default:
        return <XCircle className="h-4 w-4" />
    }
  }

  const getStatusClass = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-red-100 text-red-800"
    }
  }

  return (
    <div className="container mx-auto px-4 pt-6 pb-24">
      {/* Header */}
      <div className="flex items-center mb-6">
        <Button
          variant="ghost"
          size="icon"
          className="w-10 h-10 rounded-full bg-white shadow-md mr-3"
          onClick={() => setCurrentPage("home")}
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <div>
          <h2 className="text-xl font-bold text-gray-800">Recharge Balance</h2>
          <p className="text-gray-600 text-sm">Top up your account balance</p>
        </div>
      </div>

      {/* Balance Display */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-500 to-blue-700 p-5 text-white shadow-lg mb-6">
        <div className="absolute -top-10 -right-10 w-24 h-24 bg-white/10 rounded-full" />
        <div className="absolute -bottom-8 -left-8 w-20 h-20 bg-white/10 rounded-full" />

        <div className="relative text-center">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Gem className="h-8 w-8" />
          </div>
          <p className="text-blue-100">Current Balance</p>
          <h2 className="text-4xl font-bold">{balance.toLocaleString()} MMK</h2>
        </div>
      </div>

      {/* Recharge Form */}
      <div className="bg-white rounded-2xl p-5 shadow-lg mb-6">
        {/* Amount Selection */}
        <h3 className="text-lg font-bold text-gray-800 mb-4">Select Amount</h3>
        <div className="grid grid-cols-2 gap-3 mb-6">
          {PRESET_AMOUNTS.map((amount) => (
            <button
              key={amount}
              onClick={() => handleAmountSelect(amount)}
              className={cn(
                "border-2 rounded-xl p-4 text-center transition-all duration-300",
                selectedAmount === amount ? "border-blue-500 bg-blue-50" : "border-gray-200 hover:border-blue-300",
              )}
            >
              <div className="font-bold text-gray-800">{amount.toLocaleString()}</div>
              <div className="text-sm text-gray-500">MMK</div>
            </button>
          ))}
        </div>

        {/* Custom Amount */}
        <div className="mb-6">
          <Label className="mb-2 block">Custom Amount</Label>
          <div className="flex gap-2">
            <div className="flex-1 flex">
              <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500">
                MMK
              </span>
              <Input
                type="number"
                placeholder="Enter custom amount"
                value={customAmount}
                onChange={(e) => {
                  setCustomAmount(e.target.value)
                  setSelectedAmount(null)
                }}
                className="rounded-l-none"
              />
            </div>
            <Button
              onClick={() => {
                if (customAmount && Number.parseFloat(customAmount) > 0) {
                  showNotification(`Amount set to ${Number.parseInt(customAmount).toLocaleString()} MMK`, "info")
                }
              }}
            >
              Apply
            </Button>
          </div>
        </div>

        {/* Payment Methods */}
        <div className="border-t border-gray-200 pt-4 mb-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Payment Methods</h3>
          <RadioGroup value={selectedMethod} onValueChange={setSelectedMethod}>
            <div className="space-y-3">
              {paymentMethods.map((method) => (
                <div
                  key={method.id}
                  className="flex items-start p-3 border border-gray-200 rounded-lg hover:border-blue-300 transition-colors cursor-pointer"
                  onClick={() => setSelectedMethod(String(method.id))}
                >
                  <RadioGroupItem value={String(method.id)} className="mt-1 mr-3" />
                  <div className="flex-1">
                    <Label className="font-medium text-gray-800 cursor-pointer">{method.name}</Label>
                    <p className="text-sm text-gray-600 mt-1">{method.account_info}</p>
                    {method.instructions && <p className="text-xs text-blue-600 mt-1">{method.instructions}</p>}
                  </div>
                </div>
              ))}
            </div>
          </RadioGroup>
        </div>

        {/* Screenshot Upload */}
        <div className="border-t border-gray-200 pt-4 mb-6">
          <Label className="mb-2 block">Upload Payment Screenshot</Label>
          <div
            className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100"
            onClick={() => fileInputRef.current?.click()}
          >
            <CloudUpload className="h-8 w-8 text-gray-400 mb-2" />
            <p className="text-sm text-gray-500">{screenshot ? screenshot.name : "Click to upload or drag and drop"}</p>
            <p className="text-xs text-gray-400">PNG, JPG, GIF (MAX. 5MB)</p>
          </div>
          <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
        </div>

        {/* Submit Button */}
        <Button
          className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
          onClick={handleSubmit}
          disabled={isSubmitting}
        >
          {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Send className="h-4 w-4 mr-2" />}
          Submit Recharge Request
        </Button>
      </div>

      {/* Recharge History */}
      <div className="bg-white rounded-2xl p-5 shadow-lg">
        <h3 className="text-lg font-bold text-gray-800 mb-4">Recent Recharges</h3>
        <div className="space-y-3">
          {rechargeHistory.length > 0 ? (
            rechargeHistory.slice(0, 5).map((request) => (
              <div
                key={request.id}
                className="flex justify-between items-center py-3 border-b border-gray-200 last:border-0"
              >
                <div>
                  <p className="font-medium text-gray-800">{request.amount.toLocaleString()} MMK</p>
                  <p className="text-xs text-gray-500">{new Date(request.created_at).toLocaleDateString()}</p>
                </div>
                <span
                  className={cn(
                    "text-xs font-medium px-2.5 py-0.5 rounded-full flex items-center gap-1",
                    getStatusClass(request.status),
                  )}
                >
                  {getStatusIcon(request.status)}
                  {request.status}
                </span>
              </div>
            ))
          ) : (
            <p className="text-gray-500 text-center py-4">No recharge history</p>
          )}
        </div>
      </div>
    </div>
  )
}
