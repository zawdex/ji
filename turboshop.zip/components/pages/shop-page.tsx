"use client"

import { useState, useMemo } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ProductCard } from "@/components/product-card"
import { ProductModal } from "@/components/product-modal"
import { useAppStore } from "@/lib/store"
import type { Product } from "@/lib/types"

export function ShopPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const { products } = useAppStore()

  const filteredProducts = useMemo(() => {
    if (!searchQuery) return products

    const query = searchQuery.toLowerCase()
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query),
    )
  }, [products, searchQuery])

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }

  return (
    <div className="container mx-auto px-4 pt-6 pb-24">
      {/* Header */}
      <div className="flex items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">All Products</h2>
        <Badge className="ml-3 bg-blue-100 text-blue-800">{filteredProducts.length} products</Badge>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl p-3 shadow-md mb-6">
        <div className="flex items-center">
          <Search className="h-5 w-5 text-gray-400 ml-2 mr-3" />
          <Input
            type="text"
            placeholder="Search all products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="border-0 focus-visible:ring-0 shadow-none"
          />
        </div>
      </div>

      {/* Products Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-2 gap-4">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} onClick={() => handleProductClick(product)} showStock />
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <Search className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No products found</p>
        </div>
      )}

      {/* Product Modal */}
      <ProductModal product={selectedProduct} open={isModalOpen} onOpenChange={setIsModalOpen} />
    </div>
  )
}
