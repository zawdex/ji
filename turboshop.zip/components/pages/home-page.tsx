"use client"

import { useEffect, useState } from "react"
import { Search, Zap, ChevronRight } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { BalanceCard } from "@/components/balance-card"
import { CategoryCard } from "@/components/category-card"
import { ProductCard } from "@/components/product-card"
import { ProductModal } from "@/components/product-modal"
import { api } from "@/lib/api"
import { useAppStore } from "@/lib/store"
import { showNotification } from "@/components/notification"
import type { Product, Category } from "@/lib/types"

export function HomePage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([])
  const [mlbbProducts, setMlbbProducts] = useState<Product[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const { balance, setProducts, setCurrentCategory, setCurrentPage, setBalance, setIsLoading } = useAppStore()

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    setIsLoading(true)
    try {
      const [productsData, profileData] = await Promise.all([api.getProducts(), api.getProfile()])

      setProducts(productsData)
      setBalance(profileData.user.balance)

      // Extract categories
      const categoryMap = new Map<string, number>()
      productsData.forEach((p) => {
        const count = categoryMap.get(p.category) || 0
        categoryMap.set(p.category, count + 1)
      })

      const cats: Category[] = Array.from(categoryMap.entries()).map(([name, count]) => ({
        name,
        product_count: count,
        image_url: productsData.find((p) => p.category === name)?.image_url || "",
      }))

      setCategories(cats)
      setFeaturedProducts(productsData.slice(0, 4))

      const mlbb = productsData.filter((p) => p.category === "Mobile Legends").slice(0, 3)
      setMlbbProducts(mlbb)
    } catch (error) {
      console.error("Failed to load data:", error)
      showNotification("Failed to load products", "error")
    } finally {
      setIsLoading(false)
    }
  }

  const handleCategoryClick = (categoryName: string) => {
    setCurrentCategory(categoryName)
    setCurrentPage("category")
  }

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }

  const filteredProducts = searchQuery
    ? featuredProducts.filter(
        (p) =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.category.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : featuredProducts

  return (
    <div className="container mx-auto px-4 pt-6 pb-24">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Turbo Gaming</h1>
          <p className="text-gray-600 text-sm">Your ultimate gaming destination</p>
        </div>
        <div className="text-right">
          <p className="text-gray-500 text-xs">Balance</p>
          <p className="font-bold text-blue-600 text-xl">{balance.toLocaleString()} MMK</p>
        </div>
      </div>

      {/* Balance Card */}
      <div className="mb-6">
        <BalanceCard />
      </div>

      {mlbbProducts.length > 0 && (
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg">
                <Zap className="h-4 w-4 text-white" />
              </div>
              <h2 className="text-lg font-bold text-gray-800">Quick MLBB Top-up</h2>
              <Badge variant="secondary" className="bg-blue-100 text-blue-700 text-xs">
                Instant
              </Badge>
            </div>
            <button
              onClick={() => handleCategoryClick("Mobile Legends")}
              className="text-blue-500 text-sm font-medium flex items-center"
            >
              View All <ChevronRight className="h-4 w-4" />
            </button>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {mlbbProducts.map((product) => (
              <button
                key={product.id}
                onClick={() => handleProductClick(product)}
                className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-3 text-center hover:shadow-md hover:border-blue-400 transition-all"
              >
                <div className="text-blue-600 font-bold text-sm">
                  {product.name.replace("Mobile Legends", "").replace("Diamonds", "💎").trim()}
                </div>
                <div className="text-gray-800 font-semibold mt-1">{product.price.toLocaleString()}</div>
                <div className="text-xs text-gray-500">MMK</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Search */}
      <div className="bg-white rounded-xl p-3 shadow-md mb-6">
        <div className="flex items-center">
          <Search className="h-5 w-5 text-gray-400 ml-2 mr-3" />
          <Input
            type="text"
            placeholder="Search games and products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="border-0 focus-visible:ring-0 shadow-none"
          />
        </div>
      </div>

      {/* Categories */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-800">Game Categories</h2>
          <button onClick={() => setCurrentPage("shop")} className="text-blue-500 text-sm font-medium">
            View All
          </button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {categories.map((category) => (
            <CategoryCard
              key={category.name}
              name={category.name}
              productCount={category.product_count}
              onClick={() => handleCategoryClick(category.name)}
            />
          ))}
        </div>
      </div>

      {/* Featured Products */}
      <div>
        <h2 className="text-xl font-bold text-gray-800 mb-4">Featured Products</h2>
        <div className="grid grid-cols-2 gap-4">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} onClick={() => handleProductClick(product)} />
          ))}
        </div>
      </div>

      {/* Product Modal */}
      <ProductModal product={selectedProduct} open={isModalOpen} onOpenChange={setIsModalOpen} />
    </div>
  )
}
