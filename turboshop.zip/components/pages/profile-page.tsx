"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { Award as IdCard, Calendar, DollarSign, RefreshCw, LogOut, ExternalLink, Users, Radio } from "lucide-react"
import { Button } from "@/components/ui/button"
import { api } from "@/lib/api"
import { useAppStore } from "@/lib/store"
import { closeTelegramApp } from "@/lib/telegram"
import { showNotification } from "@/components/notification"

const TELEGRAM_LINKS = [
  {
    title: "Direct Support",
    handle: "@itachiX_coder",
    url: "https://t.me/itachiX_coder",
    description: "Click to message our support team directly",
    buttonText: "Message Now",
    icon: "telegram",
    gradient: "from-blue-500 to-blue-600",
    bgGradient: "from-blue-50 to-blue-100",
    borderColor: "border-blue-300 hover:border-blue-500",
  },
  {
    title: "News & Updates",
    handle: "@your_channel",
    url: "https://t.me/your_channel",
    description: "Get latest promotions and updates",
    buttonText: "Join Channel",
    icon: "broadcast",
    gradient: "from-blue-400 to-blue-500",
    bgGradient: "from-gray-50 to-gray-100",
    borderColor: "border-gray-300 hover:border-blue-400",
  },
  {
    title: "Community Group",
    handle: "@your_group",
    url: "https://t.me/your_group",
    description: "Join our community discussion",
    buttonText: "Join Group",
    icon: "users",
    gradient: "from-green-500 to-green-600",
    bgGradient: "from-green-50 to-green-100",
    borderColor: "border-green-300 hover:border-green-500",
  },
]

export function ProfilePage() {
  const [isLoading, setIsLoading] = useState(false)
  const { telegramUser, user, setUser, setBalance } = useAppStore()

  useEffect(() => {
    loadProfile()
  }, [])

  const loadProfile = async () => {
    setIsLoading(true)
    try {
      const data = await api.getProfile()
      setUser(data.user)
      setBalance(data.user.balance)
    } catch (error) {
      console.error("Failed to load profile:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleRefresh = () => {
    loadProfile()
    showNotification("Profile refreshed!", "success")
  }

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to logout?")) {
      closeTelegramApp()
    }
  }

  const displayUser = user || telegramUser

  return (
    <div className="container mx-auto px-4 pt-6 pb-24">
      <h2 className="text-xl font-bold text-gray-800 mb-6">Profile</h2>

      <div className="bg-white rounded-2xl p-6 shadow-lg">
        {/* Profile Photo & Info */}
        <div className="text-center mb-6">
          <div className="w-24 h-24 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 p-1 mx-auto mb-4">
            <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-white">
              <Image
                src={displayUser?.photo_url || "/placeholder.svg?height=96&width=96&query=user avatar"}
                alt="Profile Photo"
                fill
                className="object-cover"
              />
            </div>
          </div>
          <h3 className="text-xl font-bold text-gray-800">
            {displayUser?.first_name} {displayUser?.last_name}
          </h3>
          <p className="text-gray-600">{displayUser?.username ? `@${displayUser.username}` : "No username"}</p>
        </div>

        {/* User Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-gray-50 rounded-xl p-4 text-center">
            <IdCard className="h-5 w-5 text-blue-500 mx-auto mb-2" />
            <p className="text-sm text-gray-500">User ID</p>
            <p className="font-bold text-gray-800">{displayUser?.id}</p>
          </div>
          <div className="bg-gray-50 rounded-xl p-4 text-center">
            <Calendar className="h-5 w-5 text-blue-500 mx-auto mb-2" />
            <p className="text-sm text-gray-500">Join Date</p>
            <p className="font-bold text-gray-800">
              {user?.join_date ? new Date(user.join_date).toLocaleDateString() : "N/A"}
            </p>
          </div>
        </div>

        {/* Total Spent */}
        <div className="bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl p-4 text-white text-center mb-6">
          <DollarSign className="h-6 w-6 mx-auto mb-2" />
          <p className="text-blue-100">Total Spent</p>
          <h2 className="text-2xl font-bold">{(user?.total_spent || 0).toLocaleString()} MMK</h2>
        </div>

        {/* Telegram Support */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center justify-center">
            <svg className="w-5 h-5 mr-2 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z" />
            </svg>
            Telegram Support
          </h3>

          <div className="space-y-4">
            {TELEGRAM_LINKS.map((link, index) => (
              <a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`flex flex-col items-center p-5 bg-gradient-to-br ${link.bgGradient} rounded-2xl border-2 ${link.borderColor} hover:shadow-lg transition-all duration-300 hover:scale-[1.02]`}
              >
                <div
                  className={`w-16 h-16 rounded-full bg-gradient-to-r ${link.gradient} flex items-center justify-center mb-3 shadow-md`}
                >
                  {link.icon === "telegram" ? (
                    <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z" />
                    </svg>
                  ) : link.icon === "broadcast" ? (
                    <Radio className="w-8 h-8 text-white" />
                  ) : (
                    <Users className="w-8 h-8 text-white" />
                  )}
                </div>
                <h4 className="font-bold text-gray-800 text-lg">{link.title}</h4>
                <p className={`font-medium mt-1 ${link.icon === "users" ? "text-green-600" : "text-blue-600"}`}>
                  {link.handle}
                </p>
                <p className="text-sm text-gray-600 mt-2 text-center">{link.description}</p>
                <div
                  className={`mt-3 px-4 py-2 bg-gradient-to-r ${link.gradient} text-white rounded-full text-sm font-medium flex items-center`}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  {link.buttonText}
                </div>
              </a>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            className="flex-1 border-blue-500 text-blue-500 hover:bg-blue-50 bg-transparent"
            onClick={handleRefresh}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button
            variant="outline"
            className="flex-1 border-red-500 text-red-500 hover:bg-red-50 bg-transparent"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  )
}
