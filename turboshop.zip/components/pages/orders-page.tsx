"use client"

import { useEffect, useState } from "react"
import { Package, Calendar, Zap, CheckCircle, Clock, XCircle, RefreshCw, Copy } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { api } from "@/lib/api"
import { showNotification } from "@/components/notification"
import type { Order } from "@/lib/types"
import { cn } from "@/lib/utils"

export function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [filter, setFilter] = useState("all")
  const [isLoading, setIsLoading] = useState(false)
  const [expandedOrder, setExpandedOrder] = useState<number | null>(null)

  useEffect(() => {
    loadOrders(filter)
  }, [filter])

  const loadOrders = async (status: string) => {
    setIsLoading(true)
    try {
      const data = await api.getOrders(status)
      setOrders(data)
    } catch (error) {
      console.error("Failed to load orders:", error)
      showNotification("Failed to load orders", "error")
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-3 w-3" />
      case "processing":
        return <RefreshCw className="h-3 w-3" />
      case "pending":
        return <Clock className="h-3 w-3" />
      default:
        return <XCircle className="h-3 w-3" />
    }
  }

  const getStatusClass = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "processing":
        return "bg-blue-100 text-blue-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-red-100 text-red-800"
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    showNotification("Copied to clipboard!", "success")
  }

  const isAutoTopup = (order: Order) => {
    return order.mlbb_order_id || order.custom_fields_data?.mlbb_order_id
  }

  return (
    <div className="container mx-auto px-4 pt-6 pb-24">
      {/* Header */}
      <div className="flex items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">My Orders</h2>
        <Badge className="ml-3 bg-blue-100 text-blue-800">{orders.length} orders</Badge>
      </div>

      {/* Filter */}
      <div className="bg-white rounded-xl p-3 shadow-md mb-6">
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger>
            <SelectValue placeholder="Filter orders" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Orders</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="processing">Processing</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Orders List */}
      {isLoading ? (
        <div className="text-center py-10">
          <RefreshCw className="h-8 w-8 text-gray-400 mx-auto animate-spin" />
          <p className="text-gray-500 mt-2">Loading orders...</p>
        </div>
      ) : orders.length > 0 ? (
        <div className="space-y-4">
          {orders.map((order) => {
            const autoTopup = isAutoTopup(order)
            const mlbbOrderId = order.mlbb_order_id || order.custom_fields_data?.mlbb_order_id
            const mlbbUsername = order.custom_fields_data?.mlbb_username
            const isExpanded = expandedOrder === order.id

            return (
              <div
                key={order.id}
                className={cn(
                  "bg-white rounded-xl shadow-md overflow-hidden transition-all",
                  autoTopup && "border-l-4 border-l-blue-500",
                )}
              >
                <div className="p-4 cursor-pointer" onClick={() => setExpandedOrder(isExpanded ? null : order.id)}>
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-gray-800">{order.product_data?.name || "Unknown Product"}</h3>
                        {autoTopup && (
                          <Badge variant="outline" className="text-blue-600 border-blue-300 text-xs">
                            <Zap className="h-3 w-3 mr-1" /> Auto
                          </Badge>
                        )}
                      </div>
                      <p className="text-blue-600 font-bold">{order.total_price.toLocaleString()} MMK</p>
                    </div>
                    <span
                      className={cn(
                        "text-xs font-medium px-2.5 py-0.5 rounded-full flex items-center gap-1 ml-2",
                        getStatusClass(order.status),
                      )}
                    >
                      {getStatusIcon(order.status)}
                      {order.status}
                    </span>
                  </div>

                  <div className="text-sm text-gray-500 mb-2 flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    {new Date(order.created_at).toLocaleString()}
                  </div>

                  {autoTopup && mlbbOrderId && (
                    <div className="flex items-center gap-2 text-sm text-blue-600 bg-blue-50 rounded-lg px-3 py-2">
                      <Zap className="h-4 w-4" />
                      <span className="font-medium">Order: {mlbbOrderId}</span>
                      {mlbbUsername && <span className="text-gray-600">• {mlbbUsername}</span>}
                    </div>
                  )}
                </div>

                {isExpanded && (
                  <div className="border-t border-gray-100 bg-gray-50 p-4">
                    <h4 className="text-sm font-semibold text-gray-700 mb-3">Order Details</h4>

                    {/* Order ID */}
                    <div className="flex justify-between items-center py-2 border-b border-gray-200">
                      <span className="text-sm text-gray-600">Order ID</span>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm">#{order.id}</span>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0"
                          onClick={(e) => {
                            e.stopPropagation()
                            copyToClipboard(String(order.id))
                          }}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>

                    {/* MLBB specific details */}
                    {autoTopup && (
                      <>
                        {mlbbOrderId && (
                          <div className="flex justify-between items-center py-2 border-b border-gray-200">
                            <span className="text-sm text-gray-600">MLBB Order ID</span>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-sm text-blue-600">{mlbbOrderId}</span>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 w-6 p-0"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  copyToClipboard(mlbbOrderId)
                                }}
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        )}
                        {mlbbUsername && (
                          <div className="flex justify-between items-center py-2 border-b border-gray-200">
                            <span className="text-sm text-gray-600">In-Game Name</span>
                            <span className="font-medium text-sm">{mlbbUsername}</span>
                          </div>
                        )}
                      </>
                    )}

                    {/* Custom fields */}
                    {Object.entries(order.custom_fields_data || {})
                      .filter(([key]) => !["mlbb_order_id", "mlbb_username"].includes(key))
                      .map(([key, value]) => (
                        <div
                          key={key}
                          className="flex justify-between items-center py-2 border-b border-gray-200 last:border-0"
                        >
                          <span className="text-sm text-gray-600">
                            {key.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                          </span>
                          <span className="font-medium text-sm">{value}</span>
                        </div>
                      ))}

                    {/* Status info for completed auto-topup */}
                    {autoTopup && order.status === "completed" && (
                      <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center gap-2 text-green-700">
                          <CheckCircle className="h-4 w-4" />
                          <span className="text-sm font-medium">Diamonds delivered successfully!</span>
                        </div>
                        <p className="text-xs text-green-600 mt-1">
                          Check your MLBB account to confirm the diamonds have been added.
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      ) : (
        <div className="text-center py-10">
          <Package className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No orders found</p>
        </div>
      )}
    </div>
  )
}
