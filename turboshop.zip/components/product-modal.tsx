"use client"

import { useState } from "react"
import Image from "next/image"
import { ShoppingCart, Shield, Loader2, CheckCircle, XCircle, AlertTriangle, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { api } from "@/lib/api"
import { useAppStore } from "@/lib/store"
import { showNotification } from "./notification"
import type { Product } from "@/lib/types"

interface ProductModalProps {
  product: Product | null
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ProductModal({ product, open, onOpenChange }: ProductModalProps) {
  const [customFields, setCustomFields] = useState<Record<string, string>>({})
  const [isLoading, setIsLoading] = useState(false)
  const [isVerifying, setIsVerifying] = useState(false)
  const [verificationResult, setVerificationResult] = useState<{
    success: boolean
    name?: string
    message?: string
  } | null>(null)

  const { balance, setBalance } = useAppStore()

  if (!product) return null

  const isMLBB = product.category === "Mobile Legends"

  const handleInputChange = (fieldName: string, value: string) => {
    setCustomFields((prev) => ({ ...prev, [fieldName]: value }))
    setVerificationResult(null)
  }

  const handleVerifyRole = async () => {
    const accountId = customFields.account_id
    const serverId = customFields.server_id

    if (!accountId || !serverId) {
      showNotification("Please enter both Account ID and Server ID", "warning")
      return
    }

    if (!/^\d+$/.test(accountId) || !/^\d+$/.test(serverId)) {
      showNotification("Account ID and Server ID must contain only numbers", "warning")
      return
    }

    setIsVerifying(true)
    setVerificationResult(null)

    try {
      const result = await api.checkMLBBRole(accountId, serverId)

      if (result.status === "success") {
        setVerificationResult({
          success: true,
          name: result.name,
          message: "Account verified successfully!",
        })
        showNotification("MLBB account verified successfully!", "success")
      } else {
        setVerificationResult({
          success: false,
          message: result.message || "Verification failed",
        })
        showNotification(result.message || "Verification failed", "error")
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "Verification failed"
      setVerificationResult({
        success: false,
        message,
      })
      showNotification(message, "error")
    } finally {
      setIsVerifying(false)
    }
  }

  const handlePlaceOrder = async () => {
    // Validate required fields
    const missingFields: string[] = []
    product.input_fields.forEach((field) => {
      const fieldKey = field.label.toLowerCase().replace(/\s+/g, "_")
      if (!customFields[fieldKey]) {
        missingFields.push(field.label)
      }
    })

    if (missingFields.length > 0) {
      showNotification(`Please fill in: ${missingFields.join(", ")}`, "warning")
      return
    }

    // Check balance
    if (balance < product.price) {
      showNotification(`Insufficient balance! You need ${product.price.toLocaleString()} MMK`, "error")
      return
    }

    // Confirm if MLBB account not verified
    if (isMLBB && !verificationResult?.success) {
      const confirm = window.confirm(
        "Your MLBB account has not been verified.\n\nDo you want to proceed without verification?",
      )
      if (!confirm) return
    }

    setIsLoading(true)

    try {
      const result = isMLBB
        ? await api.autoTopup(product.id, customFields)
        : await api.placeOrder(product.id, customFields)

      setBalance(result.new_balance)

      let message = `Order placed successfully! Order ID: #${result.order_id}`
      if (result.mlbb_order_id) {
        message += ` | MLBB Order: ${result.mlbb_order_id}`
      }
      if (result.username) {
        message += ` | Username: ${result.username}`
      }

      showNotification(message, "success")
      onOpenChange(false)
      setCustomFields({})
      setVerificationResult(null)
    } catch (error) {
      const message = error instanceof Error ? error.message : "Order failed"
      showNotification(message, "error")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Product Details
            {isMLBB && (
              <Badge variant="outline" className="text-blue-600 border-blue-300">
                <Zap className="h-3 w-3 mr-1" /> Auto Top-up
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Product Image & Info */}
          <div className="text-center">
            <div className="relative w-40 h-40 mx-auto mb-4">
              <Image
                src={product.image_url || "/placeholder.svg?height=160&width=160&query=game item"}
                alt={product.name}
                fill
                className="object-contain rounded-xl shadow-md"
              />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">{product.name}</h3>
            <h2 className="text-2xl font-bold text-blue-600">{product.price.toLocaleString()} MMK</h2>
            <p className="text-gray-600 mt-2 text-sm">{product.description}</p>

            <div className="mt-2">
              <Badge variant="secondary">{product.category}</Badge>
            </div>
          </div>

          {/* Input Fields */}
          <div className="space-y-4">
            {product.input_fields.map((field) => {
              const fieldKey = field.label.toLowerCase().replace(/\s+/g, "_")

              return (
                <div key={fieldKey} className="space-y-2">
                  <Label className="flex items-center gap-1">
                    {field.label}
                    <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    type={field.type === "number" ? "number" : "text"}
                    placeholder={field.placeholder}
                    value={customFields[fieldKey] || ""}
                    onChange={(e) => handleInputChange(fieldKey, e.target.value)}
                    min={field.type === "number" ? 1 : undefined}
                    className="border-gray-300"
                  />
                  {field.instructions && <p className="text-xs text-gray-500">{field.instructions}</p>}
                </div>
              )
            })}
          </div>

          {isMLBB && (
            <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="font-semibold text-blue-900 flex items-center gap-2">
                    <Shield className="h-4 w-4" />
                    MLBB Account Verification
                  </h4>
                  <p className="text-sm text-blue-700">Verify your account for instant top-up</p>
                </div>
                <Button
                  size="sm"
                  onClick={handleVerifyRole}
                  disabled={isVerifying || !customFields.account_id || !customFields.server_id}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isVerifying ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <Shield className="h-4 w-4 mr-1" />
                      Verify
                    </>
                  )}
                </Button>
              </div>

              {verificationResult && (
                <div
                  className={`p-3 rounded-lg ${
                    verificationResult.success
                      ? "bg-green-100 border border-green-300"
                      : "bg-red-100 border border-red-300"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {verificationResult.success ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600" />
                    )}
                    <span className={`font-medium ${verificationResult.success ? "text-green-800" : "text-red-800"}`}>
                      {verificationResult.success ? "Account Verified!" : "Verification Failed"}
                    </span>
                  </div>
                  {verificationResult.name && (
                    <p className="text-sm text-green-700 mt-1 ml-7">
                      In-Game Name: <strong>{verificationResult.name}</strong>
                    </p>
                  )}
                  {!verificationResult.success && verificationResult.message && (
                    <p className="text-sm text-red-700 mt-1 ml-7">{verificationResult.message}</p>
                  )}
                </div>
              )}

              {/* Auto top-up info */}
              <div className="mt-3 p-2 bg-blue-100 rounded-lg">
                <p className="text-xs text-blue-800 flex items-center gap-1">
                  <Zap className="h-3 w-3" />
                  Diamonds will be added to your account automatically after payment
                </p>
              </div>
            </div>
          )}

          {/* Balance Warning */}
          {balance < product.price && (
            <div className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0" />
              <div>
                <span className="text-sm font-medium text-yellow-800">Insufficient balance</span>
                <p className="text-xs text-yellow-700">
                  You need {product.price.toLocaleString()} MMK but have {balance.toLocaleString()} MMK
                </p>
              </div>
            </div>
          )}

          {/* Current Balance Display */}
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <span className="text-sm text-gray-600">Your Balance</span>
            <span className="font-bold text-green-600">{balance.toLocaleString()} MMK</span>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <Button variant="outline" className="flex-1 bg-transparent" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
              onClick={handlePlaceOrder}
              disabled={isLoading || balance < product.price}
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : isMLBB ? (
                <Zap className="h-4 w-4 mr-2" />
              ) : (
                <ShoppingCart className="h-4 w-4 mr-2" />
              )}
              {isMLBB ? "Auto Top-up" : "Place Order"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
