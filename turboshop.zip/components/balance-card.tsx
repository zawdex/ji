"use client"

import { Wallet, CreditCard, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"

export function BalanceCard() {
  const { balance, setCurrentPage, setCurrentCategory } = useAppStore()

  const handleQuickTopup = () => {
    setCurrentCategory("Mobile Legends")
    setCurrentPage("category")
  }

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-500 to-blue-700 p-5 text-white shadow-lg">
      <div className="absolute -top-10 -right-10 w-24 h-24 bg-white/10 rounded-full" />
      <div className="absolute -bottom-8 -left-8 w-20 h-20 bg-white/10 rounded-full" />

      <div className="relative flex items-center justify-between mb-4">
        <div>
          <p className="text-blue-100">Your Balance</p>
          <h2 className="text-3xl font-bold">{balance.toLocaleString()} MMK</h2>
        </div>
        <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
          <Wallet className="h-8 w-8" />
        </div>
      </div>

      <div className="flex gap-3">
        <Button onClick={() => setCurrentPage("recharge")} className="flex-1 bg-white text-blue-600 hover:bg-blue-50">
          <CreditCard className="h-4 w-4 mr-2" />
          Recharge
        </Button>
        <Button
          onClick={handleQuickTopup}
          variant="outline"
          className="flex-1 border-white/50 text-white hover:bg-white/20 bg-transparent"
        >
          <Zap className="h-4 w-4 mr-2" />
          MLBB Top-up
        </Button>
      </div>
    </div>
  )
}
