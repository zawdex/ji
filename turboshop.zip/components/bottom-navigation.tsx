"use client"

import { Home, ShoppingBag, Package, User } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { cn } from "@/lib/utils"

const navItems = [
  { id: "home", label: "Home", icon: Home },
  { id: "shop", label: "Shop", icon: ShoppingBag },
  { id: "orders", label: "Orders", icon: Package },
  { id: "profile", label: "Profile", icon: User },
]

export function BottomNavigation() {
  const { currentPage, setCurrentPage, setCurrentCategory } = useAppStore()

  const handleNavClick = (pageId: string) => {
    if (pageId === "home") {
      setCurrentCategory(null)
    }
    setCurrentPage(pageId)
  }

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white shadow-lg border-t border-gray-200 z-30">
      <div className="container mx-auto px-4">
        <div className="flex justify-between py-3">
          {navItems.map((item) => {
            const isActive = currentPage === item.id
            const Icon = item.icon

            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={cn(
                  "flex flex-col items-center rounded-lg px-3 py-2 transition-colors",
                  isActive ? "text-blue-500 bg-blue-50" : "text-gray-500 hover:bg-gray-50",
                )}
              >
                <Icon className="h-5 w-5 mb-1" />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            )
          })}
        </div>
      </div>
    </nav>
  )
}
