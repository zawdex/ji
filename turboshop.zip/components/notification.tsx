"use client"

import { useEffect, useState } from "react"
import { CheckCircle, XCircle, AlertTriangle, Info, X } from "lucide-react"
import { cn } from "@/lib/utils"

type NotificationType = "success" | "error" | "warning" | "info"

interface Notification {
  id: string
  message: string
  type: NotificationType
}

let addNotificationFn: ((message: string, type: NotificationType) => void) | null = null

export function showNotification(message: string, type: NotificationType = "info") {
  if (addNotificationFn) {
    addNotificationFn(message, type)
  }
}

export function NotificationArea() {
  const [notifications, setNotifications] = useState<Notification[]>([])

  useEffect(() => {
    addNotificationFn = (message: string, type: NotificationType) => {
      const id = Date.now().toString()
      setNotifications((prev) => [...prev, { id, message, type }])

      setTimeout(() => {
        setNotifications((prev) => prev.filter((n) => n.id !== id))
      }, 5000)
    }

    return () => {
      addNotificationFn = null
    }
  }, [])

  const removeNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id))
  }

  const icons = {
    success: CheckCircle,
    error: XCircle,
    warning: AlertTriangle,
    info: Info,
  }

  const colors = {
    success: "border-green-500 text-green-500",
    error: "border-red-500 text-red-500",
    warning: "border-yellow-500 text-yellow-500",
    info: "border-blue-500 text-blue-500",
  }

  return (
    <div className="fixed top-4 right-4 z-40 space-y-3 max-w-sm">
      {notifications.map((notification) => {
        const Icon = icons[notification.type]

        return (
          <div
            key={notification.id}
            className={cn(
              "bg-white rounded-lg shadow-lg p-4 border-l-4 flex items-start gap-3",
              colors[notification.type],
            )}
          >
            <Icon className="h-5 w-5 shrink-0" />
            <p className="text-sm font-medium text-gray-900 flex-1">{notification.message}</p>
            <button onClick={() => removeNotification(notification.id)} className="text-gray-400 hover:text-gray-500">
              <X className="h-4 w-4" />
            </button>
          </div>
        )
      })}
    </div>
  )
}
