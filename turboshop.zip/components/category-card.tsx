"use client"

import { Gamepad2, Target, Flame, Wind, Crosshair } from "lucide-react"
import { cn } from "@/lib/utils"

interface CategoryCardProps {
  name: string
  productCount: number
  onClick: () => void
}

const categoryConfig: Record<string, { icon: typeof Gamepad2; gradient: string; textColor: string }> = {
  "Mobile Legends": {
    icon: Gamepad2,
    gradient: "from-blue-500 to-purple-600",
    textColor: "text-blue-600",
  },
  "PUBG Mobile": {
    icon: Target,
    gradient: "from-orange-500 to-red-500",
    textColor: "text-orange-600",
  },
  "Free Fire": {
    icon: Flame,
    gradient: "from-yellow-500 to-orange-500",
    textColor: "text-orange-500",
  },
  "Genshin Impact": {
    icon: Wind,
    gradient: "from-teal-500 to-blue-600",
    textColor: "text-teal-600",
  },
  "Call of Duty": {
    icon: Crosshair,
    gradient: "from-red-500 to-pink-600",
    textColor: "text-red-600",
  },
}

export function CategoryCard({ name, productCount, onClick }: CategoryCardProps) {
  const config = categoryConfig[name] || {
    icon: Gamepad2,
    gradient: "from-gray-500 to-gray-700",
    textColor: "text-gray-600",
  }

  const Icon = config.icon

  return (
    <div onClick={onClick} className="group cursor-pointer">
      <div className="relative">
        <div className="bg-white rounded-2xl p-5 shadow-lg hover:shadow-2xl transition-all duration-500 group-hover:-translate-y-2 border border-gray-100 overflow-hidden">
          {/* Top gradient bar on hover */}
          <div
            className={cn(
              "absolute top-0 left-0 w-full h-1 bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-opacity duration-500",
              config.gradient,
            )}
          />

          {/* Icon */}
          <div className="relative mb-5">
            <div
              className={cn(
                "w-16 h-16 mx-auto rounded-2xl bg-gradient-to-r p-1.5 shadow-lg group-hover:scale-110 group-hover:rotate-3 transition-all duration-500",
                config.gradient,
              )}
            >
              <div className="w-full h-full rounded-xl bg-white flex items-center justify-center">
                <Icon className={cn("h-7 w-7", config.textColor)} />
              </div>
            </div>
          </div>

          {/* Category info */}
          <div className="text-center">
            <h3 className="font-bold text-gray-800 text-base mb-2 group-hover:text-gray-900 transition-colors">
              {name}
            </h3>

            <div className="inline-flex items-center justify-center px-3 py-1.5 rounded-full bg-gradient-to-r from-gray-50 to-gray-100 border border-gray-200 group-hover:from-gray-100 group-hover:to-gray-200 transition-all duration-300">
              <span className={cn("text-xs font-semibold", config.textColor)}>
                {productCount} {productCount === 1 ? "Product" : "Products"}
              </span>
            </div>
          </div>

          {/* Bottom indicator */}
          <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-all duration-300">
            <div className={cn("w-8 h-1 rounded-full bg-gradient-to-r", config.gradient)} />
          </div>
        </div>

        {/* Popular badge */}
        {productCount > 10 && (
          <div className="absolute -top-2 -right-2 z-10">
            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-md">
              <Flame className="h-3 w-3 mr-1" />
              Popular
            </span>
          </div>
        )}
      </div>
    </div>
  )
}
