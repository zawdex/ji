// In-memory database storage that works in v0 preview environment

type DatabaseStore = Record<string, any>

// Global in-memory store
const memoryStore: DatabaseStore = {}

// Generic read function - returns from memory or default value
export async function readData<T>(filename: string, defaultValue: T): Promise<T> {
  if (memoryStore[filename] !== undefined) {
    return memoryStore[filename] as T
  }
  // Initialize with default value
  memoryStore[filename] = defaultValue
  return defaultValue
}

// Generic write function - saves to memory
export async function writeData<T>(filename: string, data: T): Promise<void> {
  memoryStore[filename] = data
}

// Atomic update function
export async function updateData<T>(filename: string, defaultValue: T, updater: (data: T) => T): Promise<T> {
  const data = await readData(filename, defaultValue)
  const updated = updater(data)
  await writeData(filename, updated)
  return updated
}

// Helper to check if data exists
export async function dataExists(filename: string): Promise<boolean> {
  return memoryStore[filename] !== undefined
}

// Clear all data (for testing)
export function clearAllData(): void {
  Object.keys(memoryStore).forEach((key) => {
    delete memoryStore[key]
  })
}

// Get all keys (for debugging)
export function getAllKeys(): string[] {
  return Object.keys(memoryStore)
}
