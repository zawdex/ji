// Core types for the Turbo Gaming application

export interface TelegramUser {
  id: number
  first_name: string
  last_name?: string
  username?: string
  language_code?: string
  is_premium?: boolean
  photo_url?: string
}

export interface User {
  id: number
  telegram_id: number
  username: string
  first_name: string
  last_name: string
  photo_url: string
  is_premium: boolean
  balance: number
  total_spent: number
  join_date: string
  updated_at: string
}

export interface Product {
  id: number
  name: string
  category: string
  price: number
  stock: number
  image_url: string
  description: string
  input_fields: InputField[]
  status: string
  game_data?: {
    pid?: string
    amount?: string
    platform?: string
  }
}

export interface InputField {
  label: string
  type: string
  placeholder: string
  validation?: string
  instructions?: string
}

export interface Category {
  name: string
  product_count: number
  image_url: string
}

export interface Order {
  id: number
  user_id: number
  product_id: number
  product_data: Product
  total_price: number
  custom_fields_data: Record<string, string>
  status: "pending" | "processing" | "completed" | "cancelled"
  mlbb_order_id?: string
  mlbb_username?: string
  created_at: string
}

export interface PaymentMethod {
  id: number
  name: string
  account_info: string
  instructions?: string
  status: string
}

export interface RechargeRequest {
  id: number
  user_id: number
  amount: number
  payment_method_id: number
  payment_method_name: string
  screenshot_path: string
  status: "pending" | "approved" | "rejected"
  created_at: string
}

export interface RoleCheckResult {
  status: "success" | "error"
  name?: string
  user_id?: string
  zone_id?: string
  message?: string
}
