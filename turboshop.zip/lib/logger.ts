import { readData, updateData } from "./database"
import { SCHEMA } from "./db-schema"
import type { DbLog } from "./db-types"

export type LogType = "admin_action" | "order" | "recharge" | "system" | "error" | "security"
export type LogLevel = "info" | "warning" | "error" | "critical"

export interface LogEntry {
  type: LogType
  level?: LogLevel
  action: string
  user_id?: number
  admin_id?: number
  details: Record<string, any>
  ip_address?: string
  user_agent?: string
}

export async function log(entry: LogEntry): Promise<void> {
  try {
    await updateData<DbLog[]>(SCHEMA.LOGS, [], (logs) => {
      const newLog: DbLog = {
        id: logs.length + 1,
        type: entry.type,
        action: entry.action,
        user_id: entry.user_id,
        admin_id: entry.admin_id,
        details: {
          ...entry.details,
          level: entry.level || "info",
        },
        ip_address: entry.ip_address,
        user_agent: entry.user_agent,
        created_at: new Date().toISOString(),
      }

      logs.push(newLog)

      // Keep only last 10000 logs
      if (logs.length > 10000) {
        logs.splice(0, logs.length - 10000)
      }

      return logs
    })
  } catch (error) {
    console.error("[Logger] Failed to write log:", error)
  }
}

// Convenience logging functions
export const logger = {
  info: (action: string, details: Record<string, any>, opts?: Partial<LogEntry>) =>
    log({ type: "system", level: "info", action, details, ...opts }),

  warning: (action: string, details: Record<string, any>, opts?: Partial<LogEntry>) =>
    log({ type: "system", level: "warning", action, details, ...opts }),

  error: (action: string, details: Record<string, any>, opts?: Partial<LogEntry>) =>
    log({ type: "error", level: "error", action, details, ...opts }),

  critical: (action: string, details: Record<string, any>, opts?: Partial<LogEntry>) =>
    log({ type: "error", level: "critical", action, details, ...opts }),

  security: (action: string, details: Record<string, any>, opts?: Partial<LogEntry>) =>
    log({ type: "security", level: "warning", action, details, ...opts }),

  adminAction: (action: string, adminId: number, details: Record<string, any>) =>
    log({ type: "admin_action", action, admin_id: adminId, details }),

  orderLog: (action: string, userId: number, details: Record<string, any>) =>
    log({ type: "order", action, user_id: userId, details }),

  rechargeLog: (action: string, userId: number, details: Record<string, any>) =>
    log({ type: "recharge", action, user_id: userId, details }),
}

// Get logs with filtering
export async function getLogs(options: {
  type?: LogType
  level?: LogLevel
  user_id?: number
  admin_id?: number
  from_date?: string
  to_date?: string
  limit?: number
  offset?: number
}): Promise<{ logs: DbLog[]; total: number }> {
  const allLogs = await readData<DbLog[]>(SCHEMA.LOGS, [])

  let filtered = allLogs

  if (options.type) {
    filtered = filtered.filter((l) => l.type === options.type)
  }

  if (options.level) {
    filtered = filtered.filter((l) => l.details?.level === options.level)
  }

  if (options.user_id) {
    filtered = filtered.filter((l) => l.user_id === options.user_id)
  }

  if (options.admin_id) {
    filtered = filtered.filter((l) => l.admin_id === options.admin_id)
  }

  if (options.from_date) {
    filtered = filtered.filter((l) => new Date(l.created_at) >= new Date(options.from_date!))
  }

  if (options.to_date) {
    filtered = filtered.filter((l) => new Date(l.created_at) <= new Date(options.to_date!))
  }

  // Sort by newest first
  filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())

  const total = filtered.length
  const limit = options.limit || 50
  const offset = options.offset || 0

  return {
    logs: filtered.slice(offset, offset + limit),
    total,
  }
}

// Export logs to JSON
export async function exportLogs(options?: {
  type?: LogType
  from_date?: string
  to_date?: string
}): Promise<string> {
  const { logs } = await getLogs({ ...options, limit: 100000 })
  return JSON.stringify(logs, null, 2)
}
