"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { TelegramUser, Product, User } from "./types"

export interface CartItem {
  id: number
  product: Product
  quantity: number
  custom_fields: Record<string, string>
}

interface AppStore {
  // User state
  telegramUser: TelegramUser | null
  user: User | null
  balance: number
  isAuthenticated: boolean

  // Products state
  products: Product[]
  currentCategory: string | null

  // Cart state
  cart: CartItem[]
  cartTotal: number

  // UI state
  isLoading: boolean
  currentPage: string
  notification: { message: string; type: "success" | "error" | "info" | "warning" } | null

  // User Actions
  setTelegramUser: (user: TelegramUser | null) => void
  setUser: (user: User | null) => void
  setBalance: (balance: number) => void

  // Products Actions
  setProducts: (products: Product[]) => void
  setCurrentCategory: (category: string | null) => void

  // Cart Actions
  addToCart: (product: Product, quantity: number, customFields: Record<string, string>) => void
  updateCartItem: (itemId: number, quantity: number) => void
  removeFromCart: (itemId: number) => void
  clearCart: () => void
  getCartTotal: () => number
  getCartItemCount: () => number

  // UI Actions
  setIsLoading: (loading: boolean) => void
  setCurrentPage: (page: string) => void
  showNotification: (message: string, type: "success" | "error" | "info" | "warning") => void
  clearNotification: () => void
}

export const useAppStore = create<AppStore>()(
  persist(
    (set, get) => ({
      // Initial state
      telegramUser: null,
      user: null,
      balance: 0,
      isAuthenticated: false,
      products: [],
      currentCategory: null,
      cart: [],
      cartTotal: 0,
      isLoading: false,
      currentPage: "home",
      notification: null,

      // User Actions
      setTelegramUser: (user) => set({ telegramUser: user, isAuthenticated: !!user }),
      setUser: (user) => set({ user, balance: user?.balance || 0 }),
      setBalance: (balance) => set({ balance }),

      // Products Actions
      setProducts: (products) => set({ products }),
      setCurrentCategory: (category) => set({ currentCategory: category }),

      // Cart Actions
      addToCart: (product, quantity, customFields) => {
        const { cart } = get()
        const existingIndex = cart.findIndex(
          (item) =>
            item.product.id === product.id && JSON.stringify(item.custom_fields) === JSON.stringify(customFields),
        )

        let newCart: CartItem[]
        if (existingIndex >= 0) {
          newCart = cart.map((item, index) =>
            index === existingIndex ? { ...item, quantity: item.quantity + quantity } : item,
          )
        } else {
          const newItem: CartItem = {
            id: Date.now(),
            product,
            quantity,
            custom_fields: customFields,
          }
          newCart = [...cart, newItem]
        }

        const newTotal = newCart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)

        set({ cart: newCart, cartTotal: newTotal })
      },

      updateCartItem: (itemId, quantity) => {
        const { cart } = get()
        let newCart: CartItem[]

        if (quantity <= 0) {
          newCart = cart.filter((item) => item.id !== itemId)
        } else {
          newCart = cart.map((item) => (item.id === itemId ? { ...item, quantity } : item))
        }

        const newTotal = newCart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)

        set({ cart: newCart, cartTotal: newTotal })
      },

      removeFromCart: (itemId) => {
        const { cart } = get()
        const newCart = cart.filter((item) => item.id !== itemId)
        const newTotal = newCart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
        set({ cart: newCart, cartTotal: newTotal })
      },

      clearCart: () => set({ cart: [], cartTotal: 0 }),

      getCartTotal: () => {
        const { cart } = get()
        return cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
      },

      getCartItemCount: () => {
        const { cart } = get()
        return cart.reduce((sum, item) => sum + item.quantity, 0)
      },

      // UI Actions
      setIsLoading: (isLoading) => set({ isLoading }),
      setCurrentPage: (currentPage) => set({ currentPage }),
      showNotification: (message, type) => set({ notification: { message, type } }),
      clearNotification: () => set({ notification: null }),
    }),
    {
      name: "turbo-gaming-storage",
      partialize: (state) => ({
        cart: state.cart,
        cartTotal: state.cartTotal,
      }),
    },
  ),
)
