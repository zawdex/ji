import { readData, updateData } from "./database"
import { SCHEMA } from "./db-schema"
import type { DbAdmin } from "./db-types"
import crypto from "crypto"

const ADMIN_SESSION_COOKIE = "admin_session"
const SESSION_DURATION = 24 * 60 * 60 * 1000 // 24 hours

interface AdminSession {
  adminId: number
  token: string
  expiresAt: number
}

const sessions = new Map<string, AdminSession>()

export function generateToken(): string {
  return crypto.randomBytes(32).toString("hex")
}

export function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex")
}

export async function createAdminSession(adminId: number): Promise<string> {
  const token = generateToken()
  const session: AdminSession = {
    adminId,
    token,
    expiresAt: Date.now() + SESSION_DURATION,
  }
  sessions.set(token, session)
  return token
}

export async function validateAdminSession(token: string): Promise<DbAdmin | null> {
  const session = sessions.get(token)

  if (!session || session.expiresAt < Date.now()) {
    if (session) {
      sessions.delete(token)
    }
    return null
  }

  const admins = await readData<DbAdmin[]>(SCHEMA.ADMINS, [])
  return admins.find((a) => a.id === session.adminId && a.is_active) || null
}

export async function getAdminFromRequest(request: Request): Promise<DbAdmin | null> {
  const cookieHeader = request.headers.get("cookie")
  if (!cookieHeader) return null

  const cookies = Object.fromEntries(cookieHeader.split("; ").map((c) => c.split("=")))

  const token = cookies[ADMIN_SESSION_COOKIE]
  if (!token) return null

  return validateAdminSession(token)
}

export async function destroyAdminSession(token: string): Promise<void> {
  sessions.delete(token)
}

export async function getAdminByTelegramId(telegramId: number): Promise<DbAdmin | null> {
  const admins = await readData<DbAdmin[]>(SCHEMA.ADMINS, [])
  return admins.find((a) => a.telegram_id === telegramId) || null
}

export async function createAdmin(adminData: Partial<DbAdmin>): Promise<DbAdmin> {
  return updateData<DbAdmin[]>(SCHEMA.ADMINS, [], (admins) => {
    const newAdmin: DbAdmin = {
      id: admins.length + 1,
      telegram_id: adminData.telegram_id || 0,
      username: adminData.username || "",
      full_name: adminData.full_name || "",
      role: adminData.role || "admin",
      permissions: adminData.permissions || ["view_orders", "view_recharges"],
      is_active: true,
      created_at: new Date().toISOString(),
      last_login: new Date().toISOString(),
    }
    admins.push(newAdmin)
    return admins
  }).then((admins) => admins[admins.length - 1])
}

export function hasPermission(admin: DbAdmin, permission: string): boolean {
  if (admin.role === "super_admin") return true
  return admin.permissions.includes(permission)
}
