import { readData } from "./database"
import { SCHEMA, DEFAULT_SETTINGS } from "./db-schema"
import type { DbProduct, DbCategory } from "./db-types"

export interface PriceCalculation {
  base_price: number
  category_markup: number
  global_markup: number
  final_price: number
  profit: number
}

export async function calculateProductPrice(basePrice: number, categoryMarkup: number): Promise<PriceCalculation> {
  const settings = await readData<Record<string, any>>(SCHEMA.SETTINGS, DEFAULT_SETTINGS)
  const globalMarkup = settings.global_markup_percentage?.value || 5

  // Apply category markup first, then global markup
  const afterCategoryMarkup = basePrice * (1 + categoryMarkup / 100)
  const finalPrice = Math.ceil(afterCategoryMarkup * (1 + globalMarkup / 100))

  return {
    base_price: basePrice,
    category_markup: categoryMarkup,
    global_markup: globalMarkup,
    final_price: finalPrice,
    profit: finalPrice - basePrice,
  }
}

export async function updateAllProductPrices(): Promise<void> {
  const products = await readData<DbProduct[]>(SCHEMA.PRODUCTS, [])
  const categories = await readData<DbCategory[]>(SCHEMA.CATEGORIES, [])
  const settings = await readData<Record<string, any>>(SCHEMA.SETTINGS, DEFAULT_SETTINGS)
  const globalMarkup = settings.global_markup_percentage?.value || 5

  const updatedProducts = products.map((product) => {
    const category = categories.find((c) => c.id === product.category_id)
    const categoryMarkup = category?.markup_percentage || 0

    const afterCategoryMarkup = product.base_price * (1 + categoryMarkup / 100)
    const finalPrice = Math.ceil(afterCategoryMarkup * (1 + globalMarkup / 100))

    return {
      ...product,
      markup_percentage: categoryMarkup + globalMarkup,
      final_price: finalPrice,
      updated_at: new Date().toISOString(),
    }
  })

  const { writeData } = await import("./database")
  await writeData(SCHEMA.PRODUCTS, updatedProducts)
}

export function formatPrice(amount: number): string {
  return `${amount.toLocaleString()} MMK`
}

export function formatCurrency(amount: number, currency = "MMK"): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currency === "MMK" ? "MMK" : currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}
