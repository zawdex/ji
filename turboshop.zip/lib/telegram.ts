"use client"

import type { TelegramUser } from "./types"

// Telegram WebApp types
declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        initData: string
        initDataUnsafe: {
          user?: TelegramUser
        }
        expand: () => void
        enableClosingConfirmation: () => void
        setBackgroundColor: (color: string) => void
        close: () => void
        themeParams?: {
          bg_color?: string
          text_color?: string
          hint_color?: string
          link_color?: string
          button_color?: string
          button_text_color?: string
        }
      }
    }
  }
}

export function getTelegramWebApp() {
  if (typeof window !== "undefined" && window.Telegram?.WebApp) {
    return window.Telegram.WebApp
  }
  return null
}

export function getTelegramUser(): TelegramUser | null {
  const tg = getTelegramWebApp()

  if (tg?.initDataUnsafe?.user) {
    return tg.initDataUnsafe.user
  }

  // Development mode fallback
  if (process.env.NODE_ENV === "development") {
    return {
      id: 6468293575,
      first_name: "Demo",
      last_name: "User",
      username: "demouser",
      language_code: "en",
      is_premium: true,
      photo_url: "https://via.placeholder.com/150?text=User",
    }
  }

  return null
}

export function getInitData(): string {
  const tg = getTelegramWebApp()
  return tg?.initData || "development_mode"
}

export function initTelegramApp() {
  const tg = getTelegramWebApp()
  if (tg) {
    tg.expand()
    tg.enableClosingConfirmation()
    tg.setBackgroundColor("#f0f4ff")
  }
}

export function closeTelegramApp() {
  const tg = getTelegramWebApp()
  if (tg) {
    tg.close()
  } else {
    window.location.reload()
  }
}
