import { readData, updateData } from "./database"
import { SCHEMA, DEFAULT_CATEGORIES, DEFAULT_PRODUCTS, DEFAULT_PAYMENT_METHODS, DEFAULT_SETTINGS } from "./db-schema"
import type { DbUser, DbProduct, DbOrder, DbRecharge, DbTransaction, DbLog } from "./db-types"

// User helpers
export async function getUser(telegramId: number): Promise<DbUser | null> {
  const users = await readData<DbUser[]>(SCHEMA.USERS, [])
  return users.find((u) => u.telegram_id === telegramId) || null
}

export async function createUser(telegramId: number, userData: Partial<DbUser>): Promise<DbUser> {
  return updateData<DbUser[]>(SCHEMA.USERS, [], (users) => {
    const newUser: DbUser = {
      id: users.length + 1,
      telegram_id: telegramId,
      username: userData.username || "",
      first_name: userData.first_name || "",
      last_name: userData.last_name || "",
      photo_url: userData.photo_url || "",
      is_premium: userData.is_premium || false,
      balance: 10000, // Initial balance
      total_spent: 0,
      join_date: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      last_active: new Date().toISOString(),
      is_banned: false,
      role: "user",
    }
    users.push(newUser)
    return users
  }).then((users) => users[users.length - 1])
}

export async function updateUserBalance(userId: number, amount: number, type: "add" | "subtract"): Promise<number> {
  const users = await updateData<DbUser[]>(SCHEMA.USERS, [], (users) => {
    const user = users.find((u) => u.id === userId)
    if (user) {
      const oldBalance = user.balance
      user.balance = type === "add" ? user.balance + amount : user.balance - amount
      user.updated_at = new Date().toISOString()

      // Create transaction log
      createTransaction({
        user_id: userId,
        type: type === "add" ? "recharge" : "order",
        amount: amount,
        balance_before: oldBalance,
        balance_after: user.balance,
        reference_type: "manual",
        reference_id: 0,
        description: `Balance ${type === "add" ? "added" : "deducted"}: ${amount}`,
      })
    }
    return users
  })

  const user = users.find((u) => u.id === userId)
  return user?.balance || 0
}

// Product helpers
export async function getProducts(): Promise<DbProduct[]> {
  return readData<DbProduct[]>(SCHEMA.PRODUCTS, DEFAULT_PRODUCTS)
}

export async function getProductById(productId: number): Promise<DbProduct | null> {
  const products = await getProducts()
  return products.find((p) => p.id === productId) || null
}

export async function updateProductStock(productId: number, quantity: number): Promise<void> {
  await updateData<DbProduct[]>(SCHEMA.PRODUCTS, DEFAULT_PRODUCTS, (products) => {
    const product = products.find((p) => p.id === productId)
    if (product) {
      product.stock = Math.max(0, product.stock - quantity)
      product.updated_at = new Date().toISOString()
      if (product.stock === 0) {
        product.status = "out_of_stock"
      }
    }
    return products
  })
}

// Order helpers
export async function createOrder(orderData: Omit<DbOrder, "id" | "created_at" | "updated_at">): Promise<DbOrder> {
  return updateData<DbOrder[]>(SCHEMA.ORDERS, [], (orders) => {
    const newOrder: DbOrder = {
      ...orderData,
      id: orders.length + 1,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    orders.push(newOrder)
    return orders
  }).then((orders) => orders[orders.length - 1])
}

export async function getOrders(userId?: number, status?: string): Promise<DbOrder[]> {
  const orders = await readData<DbOrder[]>(SCHEMA.ORDERS, [])
  let filtered = orders

  if (userId) {
    filtered = filtered.filter((o) => o.user_id === userId)
  }

  if (status && status !== "all") {
    filtered = filtered.filter((o) => o.status === status)
  }

  return filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
}

export async function updateOrderStatus(
  orderId: number,
  status: DbOrder["status"],
  adminNotes?: string,
): Promise<void> {
  await updateData<DbOrder[]>(SCHEMA.ORDERS, [], (orders) => {
    const order = orders.find((o) => o.id === orderId)
    if (order) {
      order.status = status
      order.updated_at = new Date().toISOString()
      if (adminNotes) {
        order.admin_notes = adminNotes
      }
      if (status === "completed") {
        order.completed_at = new Date().toISOString()
        order.payment_status = "paid"
      }
      if (status === "rejected" || status === "refunded") {
        // Refund user balance
        updateUserBalance(order.user_id, order.total_price, "add")
      }
    }
    return orders
  })
}

// Recharge helpers
export async function createRecharge(rechargeData: Omit<DbRecharge, "id" | "created_at">): Promise<DbRecharge> {
  return updateData<DbRecharge[]>(SCHEMA.RECHARGES, [], (recharges) => {
    const newRecharge: DbRecharge = {
      ...rechargeData,
      id: recharges.length + 1,
      created_at: new Date().toISOString(),
    }
    recharges.push(newRecharge)
    return recharges
  }).then((recharges) => recharges[recharges.length - 1])
}

export async function getRecharges(userId?: number, status?: string): Promise<DbRecharge[]> {
  const recharges = await readData<DbRecharge[]>(SCHEMA.RECHARGES, [])
  let filtered = recharges

  if (userId) {
    filtered = filtered.filter((r) => r.user_id === userId)
  }

  if (status) {
    filtered = filtered.filter((r) => r.status === status)
  }

  return filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
}

export async function updateRechargeStatus(
  rechargeId: number,
  status: "approved" | "rejected",
  adminId: number,
  adminNotes?: string,
): Promise<void> {
  const recharges = await updateData<DbRecharge[]>(SCHEMA.RECHARGES, [], (recharges) => {
    const recharge = recharges.find((r) => r.id === rechargeId)
    if (recharge) {
      recharge.status = status
      recharge.processed_by = adminId
      recharge.processed_at = new Date().toISOString()
      if (adminNotes) {
        recharge.admin_notes = adminNotes
      }
    }
    return recharges
  })

  const recharge = recharges.find((r) => r.id === rechargeId)
  if (recharge && status === "approved") {
    await updateUserBalance(recharge.user_id, recharge.amount, "add")
  }
}

// Transaction helpers
export async function createTransaction(
  transactionData: Omit<DbTransaction, "id" | "created_at">,
): Promise<DbTransaction> {
  return updateData<DbTransaction[]>(SCHEMA.TRANSACTIONS, [], (transactions) => {
    const newTransaction: DbTransaction = {
      ...transactionData,
      id: transactions.length + 1,
      created_at: new Date().toISOString(),
    }
    transactions.push(newTransaction)
    return transactions
  }).then((transactions) => transactions[transactions.length - 1])
}

export async function getTransactions(userId: number, limit = 50): Promise<DbTransaction[]> {
  const transactions = await readData<DbTransaction[]>(SCHEMA.TRANSACTIONS, [])
  return transactions
    .filter((t) => t.user_id === userId)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, limit)
}

// Log helpers
export async function createLog(logData: Omit<DbLog, "id" | "created_at">): Promise<void> {
  await updateData<DbLog[]>(SCHEMA.LOGS, [], (logs) => {
    const newLog: DbLog = {
      ...logData,
      id: logs.length + 1,
      created_at: new Date().toISOString(),
    }
    logs.push(newLog)

    // Keep only last 10000 logs to prevent file from growing too large
    if (logs.length > 10000) {
      logs.splice(0, logs.length - 10000)
    }

    return logs
  })
}

// Settings helpers
export async function getSetting(key: string): Promise<string | number | boolean | null> {
  const settings = await readData<Record<string, any>>(SCHEMA.SETTINGS, DEFAULT_SETTINGS)
  return settings[key]?.value || null
}

export async function updateSetting(key: string, value: string | number | boolean, updatedBy?: number): Promise<void> {
  await updateData<Record<string, any>>(SCHEMA.SETTINGS, DEFAULT_SETTINGS, (settings) => {
    settings[key] = {
      id: key,
      value,
      updated_at: new Date().toISOString(),
      updated_by: updatedBy,
    }
    return settings
  })
}

// Initialize database with default data
export async function initializeDatabase() {
  await readData(SCHEMA.CATEGORIES, DEFAULT_CATEGORIES)
  await readData(SCHEMA.PRODUCTS, DEFAULT_PRODUCTS)
  await readData(SCHEMA.PAYMENT_METHODS, DEFAULT_PAYMENT_METHODS)
  await readData(SCHEMA.SETTINGS, DEFAULT_SETTINGS)
  await readData(SCHEMA.USERS, [])
  await readData(SCHEMA.ORDERS, [])
  await readData(SCHEMA.RECHARGES, [])
  await readData(SCHEMA.TRANSACTIONS, [])
  await readData(SCHEMA.LOGS, [])
  await readData(SCHEMA.CART, [])
  await readData(SCHEMA.ADMINS, [])
}
