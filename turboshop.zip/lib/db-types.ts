export interface DbUser {
  id: number
  telegram_id: number
  username: string
  first_name: string
  last_name: string
  photo_url: string
  is_premium: boolean
  balance: number
  total_spent: number
  join_date: string
  updated_at: string
  last_active: string
  is_banned: boolean
  role: "user" | "admin"
}

export interface DbProduct {
  id: number
  name: string
  category_id: number
  category_name: string
  base_price: number
  markup_percentage: number
  final_price: number
  stock: number
  image_url: string
  description: string
  input_fields: Array<{
    label: string
    type: string
    placeholder: string
    validation?: string
    instructions?: string
  }>
  status: "active" | "inactive" | "out_of_stock"
  game_data?: {
    pid?: string
    amount?: string
    platform?: string
  }
  created_at: string
  updated_at: string
}

export interface DbCategory {
  id: number
  name: string
  icon: string
  image_url: string
  description: string
  markup_percentage: number
  is_active: boolean
  sort_order: number
  created_at: string
}

export interface DbOrder {
  id: number
  user_id: number
  product_id: number
  product_snapshot: DbProduct
  quantity: number
  unit_price: number
  total_price: number
  custom_fields: Record<string, string>
  status: "pending" | "processing" | "completed" | "rejected" | "refunded"
  payment_status: "unpaid" | "paid" | "refunded"
  mlbb_order_id?: string
  mlbb_username?: string
  admin_notes?: string
  created_at: string
  updated_at: string
  completed_at?: string
}

export interface DbRecharge {
  id: number
  user_id: number
  amount: number
  payment_method_id: number
  payment_method_name: string
  screenshot_path: string
  status: "pending" | "approved" | "rejected"
  admin_notes?: string
  processed_by?: number
  processed_at?: string
  created_at: string
}

export interface DbTransaction {
  id: number
  user_id: number
  type: "recharge" | "order" | "refund" | "admin_adjustment"
  amount: number
  balance_before: number
  balance_after: number
  reference_type: "order" | "recharge" | "manual"
  reference_id: number
  description: string
  created_at: string
}

export interface DbPaymentMethod {
  id: number
  name: string
  type: "mobile_banking" | "bank_transfer" | "crypto" | "other"
  account_info: string
  account_number?: string
  qr_code_url?: string
  instructions: string
  is_active: boolean
  sort_order: number
  created_at: string
}

export interface DbSettings {
  id: string
  value: string | number | boolean
  updated_at: string
  updated_by?: number
}

export interface DbLog {
  id: number
  type: "admin_action" | "order" | "recharge" | "system" | "error"
  action: string
  user_id?: number
  admin_id?: number
  details: Record<string, any>
  ip_address?: string
  user_agent?: string
  created_at: string
}

export interface DbCart {
  id: number
  user_id: number
  product_id: number
  quantity: number
  custom_fields: Record<string, string>
  created_at: string
}

export interface DbAdmin {
  id: number
  telegram_id: number
  username: string
  full_name: string
  role: "super_admin" | "admin" | "moderator"
  permissions: string[]
  is_active: boolean
  created_at: string
  last_login: string
}
