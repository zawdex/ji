import { getSetting } from "./db-helpers"

interface NotificationTemplate {
  title: string
  body: string
}

const NOTIFICATION_TEMPLATES: Record<string, (data: any) => NotificationTemplate> = {
  order_created: (data) => ({
    title: "New Order Received",
    body: `Order #${data.order_id}
Customer: ${data.user_name}${data.username ? ` (@${data.username})` : ""}
Product: ${data.product_name}
Amount: ${data.amount.toLocaleString()} MMK
Time: ${new Date().toLocaleString()}`,
  }),

  order_completed: (data) => ({
    title: "Order Completed",
    body: `Your order #${data.order_id} for ${data.product_name} has been completed successfully!`,
  }),

  order_rejected: (data) => ({
    title: "Order Rejected",
    body: `Your order #${data.order_id} has been rejected.${data.reason ? ` Reason: ${data.reason}` : ""} Your balance has been refunded.`,
  }),

  recharge_submitted: (data) => ({
    title: "New Recharge Request",
    body: `Recharge #${data.recharge_id}
Customer: ${data.user_name}${data.username ? ` (@${data.username})` : ""}
Amount: ${data.amount.toLocaleString()} MMK
Method: ${data.payment_method}
Time: ${new Date().toLocaleString()}`,
  }),

  recharge_approved: (data) => ({
    title: "Recharge Approved",
    body: `Your recharge of ${data.amount.toLocaleString()} MMK has been approved! Your new balance is ${data.new_balance.toLocaleString()} MMK.`,
  }),

  recharge_rejected: (data) => ({
    title: "Recharge Rejected",
    body: `Your recharge request of ${data.amount.toLocaleString()} MMK has been rejected.${data.reason ? ` Reason: ${data.reason}` : ""}`,
  }),

  balance_low: (data) => ({
    title: "Low Balance Warning",
    body: `Your balance is low (${data.balance.toLocaleString()} MMK). Top up now to continue shopping!`,
  }),

  welcome: (data) => ({
    title: "Welcome to Turbo Gaming!",
    body: `Hi ${data.first_name}! Welcome to Turbo Gaming. You've received ${data.bonus.toLocaleString()} MMK as a welcome bonus. Start shopping now!`,
  }),
}

export async function sendNotification(
  chatId: string | number,
  template: keyof typeof NOTIFICATION_TEMPLATES,
  data: any,
  options?: {
    parse_mode?: "Markdown" | "HTML"
    reply_markup?: any
  },
): Promise<boolean> {
  const botToken = (await getSetting("telegram_bot_token")) as string

  if (!botToken) {
    console.warn("[Notification] Bot token not configured")
    return false
  }

  const notification = NOTIFICATION_TEMPLATES[template](data)
  const message = `*${notification.title}*\n\n${notification.body}`

  try {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: options?.parse_mode || "Markdown",
        reply_markup: options?.reply_markup,
      }),
    })

    const result = await response.json()
    return result.ok
  } catch (error) {
    console.error("[Notification] Send failed:", error)
    return false
  }
}

export async function sendAdminNotification(
  template: keyof typeof NOTIFICATION_TEMPLATES,
  data: any,
  options?: {
    reply_markup?: any
  },
): Promise<boolean> {
  const adminChatId = (await getSetting("admin_chat_id")) as string

  if (!adminChatId) {
    console.warn("[Notification] Admin chat ID not configured")
    return false
  }

  return sendNotification(adminChatId, template, data, options)
}

export async function sendUserNotification(
  userId: number,
  template: keyof typeof NOTIFICATION_TEMPLATES,
  data: any,
): Promise<boolean> {
  return sendNotification(userId, template, data)
}

// Send custom message
export async function sendCustomNotification(
  chatId: string | number,
  message: string,
  options?: {
    parse_mode?: "Markdown" | "HTML"
    reply_markup?: any
  },
): Promise<boolean> {
  const botToken = (await getSetting("telegram_bot_token")) as string

  if (!botToken) {
    console.warn("[Notification] Bot token not configured")
    return false
  }

  try {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: options?.parse_mode || "Markdown",
        reply_markup: options?.reply_markup,
      }),
    })

    const result = await response.json()
    return result.ok
  } catch (error) {
    console.error("[Notification] Custom send failed:", error)
    return false
  }
}

// Send photo with caption
export async function sendPhotoNotification(
  chatId: string | number,
  photoUrl: string,
  caption: string,
): Promise<boolean> {
  const botToken = (await getSetting("telegram_bot_token")) as string

  if (!botToken) return false

  try {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendPhoto`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        photo: photoUrl,
        caption,
        parse_mode: "Markdown",
      }),
    })

    const result = await response.json()
    return result.ok
  } catch (error) {
    console.error("[Notification] Photo send failed:", error)
    return false
  }
}
