export interface TelegramInitData {
  user?: {
    id: number
    first_name: string
    last_name?: string
    username?: string
    language_code?: string
    is_premium?: boolean
    photo_url?: string
  }
  auth_date: number
  hash: string
  [key: string]: any
}

const MOCK_USER = {
  id: 6468293575,
  first_name: "Itachi",
  last_name: "Uchiha",
  username: "itachiXCoder",
  is_premium: true,
  photo_url: "",
}

export function validateTelegramInitData(initDataString: string, botToken: string): TelegramInitData | null {
  // Development mode - return mock user for v0 preview
  if (!initDataString || initDataString === "development_mode" || !botToken) {
    return {
      user: MOCK_USER,
      auth_date: Date.now(),
      hash: "dev_mode",
    }
  }

  try {
    const params = new URLSearchParams(initDataString)
    const userData = params.get("user")

    if (userData) {
      const user = JSON.parse(userData)
      return {
        user,
        auth_date: Number.parseInt(params.get("auth_date") || "0"),
        hash: params.get("hash") || "",
      }
    }

    // Fallback to mock user
    return {
      user: MOCK_USER,
      auth_date: Date.now(),
      hash: "dev_mode",
    }
  } catch (error) {
    console.error("[v0] Telegram auth error:", error)
    // Return mock user on error for development
    return {
      user: MOCK_USER,
      auth_date: Date.now(),
      hash: "dev_mode",
    }
  }
}

export function getTelegramUserFromRequest(request: Request): TelegramInitData["user"] | null {
  try {
    const url = new URL(request.url)
    const initData = url.searchParams.get("initData")

    // Also check body for POST requests
    if (!initData) {
      // For development, always return mock user
      return MOCK_USER
    }

    if (initData === "development_mode") {
      return MOCK_USER
    }

    const params = new URLSearchParams(initData)
    const userData = params.get("user")

    if (userData) {
      return JSON.parse(userData)
    }

    // Fallback to mock user
    return MOCK_USER
  } catch (error) {
    console.error("[v0] Error extracting Telegram user:", error)
    // Return mock user on error
    return MOCK_USER
  }
}

// Helper to get user from POST body
export async function getTelegramUserFromBody(request: Request): Promise<TelegramInitData["user"] | null> {
  try {
    const body = await request.clone().json()
    const initData = body.initData

    if (!initData || initData === "development_mode") {
      return MOCK_USER
    }

    const params = new URLSearchParams(initData)
    const userData = params.get("user")

    if (userData) {
      return JSON.parse(userData)
    }

    return MOCK_USER
  } catch {
    return MOCK_USER
  }
}
