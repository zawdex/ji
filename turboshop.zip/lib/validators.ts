export interface ValidationResult {
  valid: boolean
  errors: string[]
}

export function validateOrderInput(data: any): ValidationResult {
  const errors: string[] = []

  if (!data.product_id || typeof data.product_id !== "number" || data.product_id < 1) {
    errors.push("Valid product ID is required")
  }

  if (data.quantity !== undefined) {
    if (typeof data.quantity !== "number" || data.quantity < 1 || data.quantity > 100) {
      errors.push("Quantity must be between 1 and 100")
    }
  }

  if (data.custom_fields && typeof data.custom_fields !== "object") {
    errors.push("Custom fields must be an object")
  }

  return { valid: errors.length === 0, errors }
}

export function validateRechargeInput(data: any): ValidationResult {
  const errors: string[] = []

  const amount = Number.parseFloat(data.amount)
  if (isNaN(amount) || amount < 1000 || amount > 10000000) {
    errors.push("Amount must be between 1,000 and 10,000,000 MMK")
  }

  const paymentMethodId = Number.parseInt(data.payment_method_id)
  if (isNaN(paymentMethodId) || paymentMethodId < 1) {
    errors.push("Valid payment method is required")
  }

  return { valid: errors.length === 0, errors }
}

export function validateProductInput(data: any): ValidationResult {
  const errors: string[] = []

  if (!data.name || typeof data.name !== "string" || data.name.length < 3 || data.name.length > 100) {
    errors.push("Product name must be between 3 and 100 characters")
  }

  if (!data.category_id || typeof data.category_id !== "number") {
    errors.push("Valid category is required")
  }

  const basePrice = Number.parseFloat(data.base_price)
  if (isNaN(basePrice) || basePrice < 0) {
    errors.push("Base price must be a positive number")
  }

  const stock = Number.parseInt(data.stock)
  if (isNaN(stock) || stock < 0) {
    errors.push("Stock must be a non-negative number")
  }

  return { valid: errors.length === 0, errors }
}

export function validateUserUpdate(data: any): ValidationResult {
  const errors: string[] = []

  if (data.balance !== undefined) {
    const balance = Number.parseFloat(data.balance)
    if (isNaN(balance) || balance < 0) {
      errors.push("Balance must be a non-negative number")
    }
  }

  if (data.is_banned !== undefined && typeof data.is_banned !== "boolean") {
    errors.push("is_banned must be a boolean")
  }

  return { valid: errors.length === 0, errors }
}

export function validateSettingsInput(data: any): ValidationResult {
  const errors: string[] = []

  if (data.global_markup_percentage !== undefined) {
    const markup = Number.parseFloat(data.global_markup_percentage)
    if (isNaN(markup) || markup < 0 || markup > 100) {
      errors.push("Markup percentage must be between 0 and 100")
    }
  }

  if (data.shop_name !== undefined) {
    if (typeof data.shop_name !== "string" || data.shop_name.length < 1 || data.shop_name.length > 50) {
      errors.push("Shop name must be between 1 and 50 characters")
    }
  }

  return { valid: errors.length === 0, errors }
}

// Game account validation
export function validateMLBBAccount(accountId: string, serverId: string): ValidationResult {
  const errors: string[] = []

  if (!accountId || !/^\d{5,12}$/.test(accountId)) {
    errors.push("Account ID must be 5-12 digits")
  }

  if (!serverId || !/^\d{4,5}$/.test(serverId)) {
    errors.push("Server ID must be 4-5 digits")
  }

  return { valid: errors.length === 0, errors }
}

export function validatePUBGAccount(playerId: string): ValidationResult {
  const errors: string[] = []

  if (!playerId || !/^\d{8,12}$/.test(playerId)) {
    errors.push("Player ID must be 8-12 digits")
  }

  return { valid: errors.length === 0, errors }
}

export function validateFreeFireAccount(playerId: string): ValidationResult {
  const errors: string[] = []

  if (!playerId || !/^\d{6,12}$/.test(playerId)) {
    errors.push("Player ID must be 6-12 digits")
  }

  return { valid: errors.length === 0, errors }
}
