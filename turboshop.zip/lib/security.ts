import crypto from "crypto"

// Rate limiting store
const rateLimitStore = new Map<string, { count: number; resetTime: number }>()

// Anti-spam store for file uploads
const uploadSpamStore = new Map<string, { count: number; resetTime: number }>()

// Blocked IPs
const blockedIPs = new Set<string>()

export interface RateLimitConfig {
  windowMs: number
  maxRequests: number
}

export const RATE_LIMITS: Record<string, RateLimitConfig> = {
  default: { windowMs: 60000, maxRequests: 100 },
  auth: { windowMs: 300000, maxRequests: 5 },
  order: { windowMs: 60000, maxRequests: 10 },
  recharge: { windowMs: 300000, maxRequests: 3 },
  upload: { windowMs: 600000, maxRequests: 5 },
}

export function checkRateLimit(
  identifier: string,
  limitType: keyof typeof RATE_LIMITS = "default",
): { allowed: boolean; remaining: number; resetIn: number } {
  const config = RATE_LIMITS[limitType]
  const now = Date.now()
  const key = `${limitType}:${identifier}`

  const record = rateLimitStore.get(key)

  if (!record || now > record.resetTime) {
    rateLimitStore.set(key, { count: 1, resetTime: now + config.windowMs })
    return { allowed: true, remaining: config.maxRequests - 1, resetIn: config.windowMs }
  }

  if (record.count >= config.maxRequests) {
    return { allowed: false, remaining: 0, resetIn: record.resetTime - now }
  }

  record.count++
  return { allowed: true, remaining: config.maxRequests - record.count, resetIn: record.resetTime - now }
}

export function checkUploadSpam(userId: number): boolean {
  const config = RATE_LIMITS.upload
  const now = Date.now()
  const key = `upload:${userId}`

  const record = uploadSpamStore.get(key)

  if (!record || now > record.resetTime) {
    uploadSpamStore.set(key, { count: 1, resetTime: now + config.windowMs })
    return true
  }

  if (record.count >= config.maxRequests) {
    return false
  }

  record.count++
  return true
}

export function isIPBlocked(ip: string): boolean {
  return blockedIPs.has(ip)
}

export function blockIP(ip: string): void {
  blockedIPs.add(ip)
}

export function unblockIP(ip: string): void {
  blockedIPs.delete(ip)
}

// Telegram initData validation
export function validateTelegramHash(initData: string, botToken: string): boolean {
  if (!initData || !botToken || initData === "development_mode") {
    return process.env.NODE_ENV !== "production"
  }

  try {
    const params = new URLSearchParams(initData)
    const hash = params.get("hash")
    params.delete("hash")

    const dataCheckString = Array.from(params.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([key, value]) => `${key}=${value}`)
      .join("\n")

    const secretKey = crypto.createHmac("sha256", "WebAppData").update(botToken).digest()
    const calculatedHash = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex")

    return calculatedHash === hash
  } catch {
    return false
  }
}

// Input sanitization
export function sanitizeInput(input: string): string {
  if (typeof input !== "string") return ""
  return input
    .replace(/[<>]/g, "")
    .replace(/javascript:/gi, "")
    .replace(/on\w+=/gi, "")
    .trim()
    .slice(0, 1000)
}

export function sanitizeObject<T extends Record<string, any>>(obj: T): T {
  const sanitized: Record<string, any> = {}

  for (const [key, value] of Object.entries(obj)) {
    if (typeof value === "string") {
      sanitized[key] = sanitizeInput(value)
    } else if (typeof value === "object" && value !== null) {
      sanitized[key] = sanitizeObject(value)
    } else {
      sanitized[key] = value
    }
  }

  return sanitized as T
}

// Validate order data to prevent price manipulation
export async function validateOrderIntegrity(
  productId: number,
  submittedPrice: number,
  getActualPrice: () => Promise<number>,
): Promise<{ valid: boolean; actualPrice: number; message?: string }> {
  const actualPrice = await getActualPrice()

  if (submittedPrice !== actualPrice) {
    return {
      valid: false,
      actualPrice,
      message: "Price mismatch detected. Please refresh and try again.",
    }
  }

  return { valid: true, actualPrice }
}

// Generate CSRF token
export function generateCSRFToken(): string {
  return crypto.randomBytes(32).toString("hex")
}

// Validate file upload
export function validateFileUpload(
  file: File,
  options: {
    maxSize?: number
    allowedTypes?: string[]
  } = {},
): { valid: boolean; error?: string } {
  const { maxSize = 5 * 1024 * 1024, allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"] } = options

  if (file.size > maxSize) {
    return { valid: false, error: `File size must be less than ${maxSize / 1024 / 1024}MB` }
  }

  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: `File type ${file.type} is not allowed` }
  }

  return { valid: true }
}

// Validate user ID format
export function validateUserId(userId: any): userId is number {
  return typeof userId === "number" && userId > 0 && Number.isInteger(userId)
}

// Clean up old rate limit entries periodically
setInterval(() => {
  const now = Date.now()

  for (const [key, record] of rateLimitStore.entries()) {
    if (now > record.resetTime) {
      rateLimitStore.delete(key)
    }
  }

  for (const [key, record] of uploadSpamStore.entries()) {
    if (now > record.resetTime) {
      uploadSpamStore.delete(key)
    }
  }
}, 60000)
