import { readData, updateData } from "./database"
import { SCHEMA } from "./db-schema"
import type { DbCart, DbProduct, DbOrder } from "./db-types"
import { getProducts, createOrder, updateProductStock, createTransaction } from "./db-helpers"

export interface CartItem extends DbCart {
  product: DbProduct
}

export async function getCart(userId: number): Promise<CartItem[]> {
  const cart = await readData<DbCart[]>(SCHEMA.CART, [])
  const products = await getProducts()

  const userCart = cart.filter((c) => c.user_id === userId)

  return userCart
    .map((item) => ({
      ...item,
      product: products.find((p) => p.id === item.product_id)!,
    }))
    .filter((item) => item.product)
}

export async function addToCart(
  userId: number,
  productId: number,
  quantity: number,
  customFields: Record<string, string>,
): Promise<CartItem> {
  const products = await getProducts()
  const product = products.find((p) => p.id === productId)

  if (!product) {
    throw new Error("Product not found")
  }

  if (product.status !== "active") {
    throw new Error("Product is not available")
  }

  if (product.stock < quantity) {
    throw new Error("Insufficient stock")
  }

  const cart = await updateData<DbCart[]>(SCHEMA.CART, [], (cart) => {
    // Check if product already in cart with same custom fields
    const existingIndex = cart.findIndex(
      (c) =>
        c.user_id === userId &&
        c.product_id === productId &&
        JSON.stringify(c.custom_fields) === JSON.stringify(customFields),
    )

    if (existingIndex >= 0) {
      cart[existingIndex].quantity += quantity
    } else {
      cart.push({
        id: cart.length + 1,
        user_id: userId,
        product_id: productId,
        quantity,
        custom_fields: customFields,
        created_at: new Date().toISOString(),
      })
    }

    return cart
  })

  const newItem = cart.find(
    (c) =>
      c.user_id === userId &&
      c.product_id === productId &&
      JSON.stringify(c.custom_fields) === JSON.stringify(customFields),
  )!

  return {
    ...newItem,
    product,
  }
}

export async function updateCartItem(userId: number, cartItemId: number, quantity: number): Promise<void> {
  await updateData<DbCart[]>(SCHEMA.CART, [], (cart) => {
    const item = cart.find((c) => c.id === cartItemId && c.user_id === userId)
    if (item) {
      if (quantity <= 0) {
        return cart.filter((c) => c.id !== cartItemId)
      }
      item.quantity = quantity
    }
    return cart
  })
}

export async function removeFromCart(userId: number, cartItemId: number): Promise<void> {
  await updateData<DbCart[]>(SCHEMA.CART, [], (cart) => {
    return cart.filter((c) => !(c.id === cartItemId && c.user_id === userId))
  })
}

export async function clearCart(userId: number): Promise<void> {
  await updateData<DbCart[]>(SCHEMA.CART, [], (cart) => {
    return cart.filter((c) => c.user_id !== userId)
  })
}

export async function getCartTotal(userId: number): Promise<{ items: number; total: number }> {
  const cart = await getCart(userId)

  return {
    items: cart.reduce((sum, item) => sum + item.quantity, 0),
    total: cart.reduce((sum, item) => sum + item.product.final_price * item.quantity, 0),
  }
}

export async function checkoutCart(
  userId: number,
  userBalance: number,
): Promise<{ orders: DbOrder[]; newBalance: number }> {
  const cart = await getCart(userId)

  if (cart.length === 0) {
    throw new Error("Cart is empty")
  }

  const total = cart.reduce((sum, item) => sum + item.product.final_price * item.quantity, 0)

  if (userBalance < total) {
    throw new Error(`Insufficient balance. Need ${total} MMK but only have ${userBalance} MMK`)
  }

  const orders: DbOrder[] = []

  // Create individual orders for each cart item
  for (const item of cart) {
    const order = await createOrder({
      user_id: userId,
      product_id: item.product_id,
      product_snapshot: item.product,
      quantity: item.quantity,
      unit_price: item.product.final_price,
      total_price: item.product.final_price * item.quantity,
      custom_fields: item.custom_fields,
      status: "pending",
      payment_status: "paid",
    })

    orders.push(order)

    // Update stock
    await updateProductStock(item.product_id, item.quantity)
  }

  // Clear cart
  await clearCart(userId)

  // Create transaction
  await createTransaction({
    user_id: userId,
    type: "order",
    amount: total,
    balance_before: userBalance,
    balance_after: userBalance - total,
    reference_type: "order",
    reference_id: orders[0].id,
    description: `Cart checkout - ${orders.length} order(s)`,
  })

  return {
    orders,
    newBalance: userBalance - total,
  }
}
