import type { DbProduct, DbCategory, DbPaymentMethod, DbSettings } from "./db-types"

export const SCHEMA = {
  USERS: "users.json",
  PRODUCTS: "products.json",
  CATEGORIES: "categories.json",
  ORDERS: "orders.json",
  RECHARGES: "recharges.json",
  TRANSACTIONS: "transactions.json",
  PAYMENT_METHODS: "payment_methods.json",
  SETTINGS: "settings.json",
  LOGS: "logs.json",
  CART: "cart.json",
  ADMINS: "admins.json",
}

export const DEFAULT_CATEGORIES: DbCategory[] = [
  {
    id: 1,
    name: "Mobile Legends",
    icon: "fas fa-fist-raised",
    image_url: "https://i.ibb.co/QC8TrMw/bb30f2f164a3.jpg",
    description: "Mobile Legends Bang Bang Diamonds",
    markup_percentage: 5,
    is_active: true,
    sort_order: 1,
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    name: "PUBG Mobile",
    icon: "fas fa-crosshairs",
    image_url: "https://i.ibb.co/YbP7CtB/b372a0e576e8.jpg",
    description: "PUBG Mobile UC",
    markup_percentage: 5,
    is_active: true,
    sort_order: 2,
    created_at: new Date().toISOString(),
  },
  {
    id: 3,
    name: "Free Fire",
    icon: "fas fa-fire",
    image_url: "https://i.ibb.co/qWrsMtL/682a414a76c7.jpg",
    description: "Free Fire Diamonds",
    markup_percentage: 5,
    is_active: true,
    sort_order: 3,
    created_at: new Date().toISOString(),
  },
]

export const DEFAULT_PRODUCTS: DbProduct[] = [
  {
    id: 1,
    name: "11 Diamonds",
    category_id: 1,
    category_name: "Mobile Legends",
    base_price: 810,
    markup_percentage: 5,
    final_price: 850,
    stock: 1000,
    image_url: "https://i.ibb.co/QC8TrMw/bb30f2f164a3.jpg",
    description: "11 Diamonds for Mobile Legends Bang Bang",
    input_fields: [
      {
        label: "Account ID",
        type: "number",
        placeholder: "Enter your Account ID",
        validation: "required",
        instructions: "Your Mobile Legends Account ID",
      },
      {
        label: "Server ID",
        type: "text",
        placeholder: "Enter your Server ID",
        validation: "required",
        instructions: "Your Mobile Legends Server ID (e.g., 8001)",
      },
    ],
    status: "active",
    game_data: {
      pid: "212",
      amount: "11 Diamonds",
      platform: "PHP",
    },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  // Add more default products...
]

export const DEFAULT_PAYMENT_METHODS: DbPaymentMethod[] = [
  {
    id: 1,
    name: "KBZ Pay",
    type: "mobile_banking",
    account_info: "09XXXXXXXXX",
    account_number: "09XXXXXXXXX",
    instructions: "Send payment with your user ID as reference",
    is_active: true,
    sort_order: 1,
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    name: "Wave Money",
    type: "mobile_banking",
    account_info: "09XXXXXXXXX",
    account_number: "09XXXXXXXXX",
    instructions: "Include your user ID in payment note",
    is_active: true,
    sort_order: 2,
    created_at: new Date().toISOString(),
  },
]

export const DEFAULT_SETTINGS: Record<string, DbSettings> = {
  shop_name: {
    id: "shop_name",
    value: "Turbo Gaming",
    updated_at: new Date().toISOString(),
  },
  shop_status: {
    id: "shop_status",
    value: "open",
    updated_at: new Date().toISOString(),
  },
  maintenance_mode: {
    id: "maintenance_mode",
    value: false,
    updated_at: new Date().toISOString(),
  },
  global_markup_percentage: {
    id: "global_markup_percentage",
    value: 5,
    updated_at: new Date().toISOString(),
  },
  telegram_bot_token: {
    id: "telegram_bot_token",
    value: "",
    updated_at: new Date().toISOString(),
  },
  admin_chat_id: {
    id: "admin_chat_id",
    value: "",
    updated_at: new Date().toISOString(),
  },
  auto_approve_recharge: {
    id: "auto_approve_recharge",
    value: false,
    updated_at: new Date().toISOString(),
  },
}
