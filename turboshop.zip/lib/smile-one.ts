// Smile One API Integration Layer
// Handles authentication, role check, auto top-up, and balance management
// Uses single cookie for both PHP and BRL platforms

// In-memory cookie storage (in production, use secure database storage)
let smileOneCookie: string | null = null

export interface SmileOneConfig {
  platforms: {
    BRL: {
      baseUrl: string
      referer: string
    }
    PHP: {
      baseUrl: string
      referer: string
    }
  }
}

export const SMILE_ONE_CONFIG: SmileOneConfig = {
  platforms: {
    BRL: {
      baseUrl: "https://www.smile.one",
      referer: "https://www.smile.one/merchant/mobilelegends?source=other",
    },
    PHP: {
      baseUrl: "https://www.smile.one/ph",
      referer: "https://www.smile.one/ph/merchant/mobilelegends?source=other",
    },
  },
}

export type Platform = "BRL" | "PHP"

export interface RoleCheckResult {
  status: "success" | "error"
  name?: string
  user_id?: string
  zone_id?: string
  message?: string
}

export interface TopupResult {
  status: "success" | "fail" | "error" | "unknown"
  message: string
  username?: string
  flow_id?: string
  user_id?: string
  zone_id?: string
  platform?: string
  pid?: string
  transaction_id?: string
}

export interface BalanceResult {
  success: boolean
  platform: string
  user_name?: string
  balance?: string
  all_balance?: string
  error?: string
}

export interface CookieTestResult {
  success: boolean
  user_name?: string
  login_status?: boolean
  message?: string
  favorite?: boolean
  favorite_count?: number
}

export interface OrderHistoryResult {
  success: boolean
  data?: any
  message?: string
}

// Cookie Management Functions
export function getCookie(): string | null {
  return smileOneCookie
}

export function setCookie(cookie: string): void {
  smileOneCookie = cookie
}

export function deleteCookie(): void {
  smileOneCookie = null
}

export function hasCookie(): boolean {
  return smileOneCookie !== null && smileOneCookie.length > 0
}

// Role Check - Check MLBB account validity
export async function checkRole(userId: string, zoneId: string): Promise<RoleCheckResult> {
  const cookie = getCookie()
  if (!cookie) {
    return { status: "error", message: "Cookie not configured. Please set up Smile One cookie first." }
  }

  try {
    const url = `${SMILE_ONE_CONFIG.platforms.BRL.baseUrl}/merchant/mobilelegends/checkrole`

    const response = await fetch(url, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
        "X-Requested-With": "XMLHttpRequest",
        Cookie: cookie,
        Referer: SMILE_ONE_CONFIG.platforms.BRL.referer,
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
      },
      body: new URLSearchParams({
        user_id: userId,
        zone_id: zoneId,
        pid: "25",
        checkrole: "1",
        pay_methond: "",
        channel_method: "",
      }).toString(),
    })

    if (!response.ok) {
      return { status: "error", message: `HTTP Error: ${response.status}` }
    }

    const json = await response.json()

    if (json.code === 201) {
      return { status: "error", message: "Invalid User ID or Zone ID" }
    }

    if (!json.username) {
      return { status: "error", message: "Username not found in response" }
    }

    return {
      status: "success",
      name: json.username,
      user_id: userId,
      zone_id: zoneId,
    }
  } catch (error) {
    console.error("Role check error:", error)
    return {
      status: "error",
      message: error instanceof Error ? error.message : "Role check failed",
    }
  }
}

// Get CSRF Token for platform
async function getCsrfToken(platform: Platform): Promise<string> {
  const cookie = getCookie()
  if (!cookie) return ""

  try {
    const config = SMILE_ONE_CONFIG.platforms[platform]
    const url = `${config.baseUrl}/merchant/mobilelegends?source=other`

    const response = await fetch(url, {
      method: "GET",
      headers: {
        Cookie: cookie,
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
      },
    })

    const html = await response.text()
    const match = html.match(/name="_csrf" value="([^"]+)"/)
    return match ? match[1] : ""
  } catch (error) {
    console.error("CSRF token error:", error)
    return ""
  }
}

// Parse Smile One response HTML for success/failure
function parseSmileResponse(html: string): { status: string; message: string } {
  // Check for success patterns
  if (/sucesso|success|berhasil|completed|Order created successfully/i.test(html)) {
    return { status: "success", message: "Order created successfully" }
  }

  // Check for insufficient balance
  if (/insuficiente|insufficient|balance/i.test(html)) {
    return { status: "fail", message: "Insufficient smile coin balance" }
  }

  // Check for invalid user
  if (/invalid|user|zone/i.test(html)) {
    return { status: "fail", message: "Invalid user ID or zone ID" }
  }

  // Check for generic failure
  if (/fail|erro|error|gagal/i.test(html)) {
    return { status: "fail", message: "Transaction failed" }
  }

  return { status: "unknown", message: "Unable to determine transaction status" }
}

// Auto Top-up - Purchase diamonds automatically
export async function autoTopup(
  userId: string,
  zoneId: string,
  pid: string,
  platform: Platform = "BRL",
): Promise<TopupResult> {
  const cookie = getCookie()
  if (!cookie) {
    return { status: "error", message: "Cookie not configured. Please set up Smile One cookie first." }
  }

  try {
    const config = SMILE_ONE_CONFIG.platforms[platform]

    // Step 1: Query to get flow ID
    const queryUrl = `${config.baseUrl}/merchant/mobilelegends/query`

    const queryResponse = await fetch(queryUrl, {
      method: "POST",
      headers: {
        Accept: "application/json, text/javascript, */*; q=0.01",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
        Cookie: cookie,
        Referer: config.referer,
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
      },
      body: new URLSearchParams({
        user_id: userId,
        zone_id: zoneId,
        pid: pid,
        checkrole: "",
        pay_methond: "smilecoin",
        channel_method: "smilecoin",
      }).toString(),
    })

    if (!queryResponse.ok) {
      return { status: "error", message: `Query failed with HTTP ${queryResponse.status}` }
    }

    const queryData = await queryResponse.json()

    if (!queryData.flowid) {
      return {
        status: "error",
        message: "Failed to get flow ID from query response",
      }
    }

    const flowId = queryData.flowid
    const username = queryData.username || "Unknown"

    // Step 2: Final payment
    const csrfToken = await getCsrfToken(platform)
    const payUrl = `${config.baseUrl}/merchant/mobilelegends/pay`

    const payResponse = await fetch(payUrl, {
      method: "POST",
      headers: {
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Content-Type": "application/x-www-form-urlencoded",
        Cookie: cookie,
        Referer: config.referer,
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
      },
      body: new URLSearchParams({
        _csrf: csrfToken,
        user_id: userId,
        zone_id: zoneId,
        pay_methond: "smilecoin",
        product_id: pid,
        channel_method: "smilecoin",
        flowid: flowId,
        email: "",
        coupon_id: "",
      }).toString(),
    })

    const payHtml = await payResponse.text()
    const result = parseSmileResponse(payHtml)

    return {
      status: result.status as TopupResult["status"],
      message: result.message,
      username,
      flow_id: flowId,
      user_id: userId,
      zone_id: zoneId,
      platform,
      pid,
      transaction_id: `SMILE-${Date.now()}-${userId}`,
    }
  } catch (error) {
    console.error("Auto topup error:", error)
    return {
      status: "error",
      message: error instanceof Error ? error.message : "Auto top-up failed",
    }
  }
}

// Test cookie validity for a platform
export async function testCookie(platform: Platform): Promise<CookieTestResult> {
  const cookie = getCookie()
  if (!cookie) {
    return { success: false, message: "No cookie configured" }
  }

  try {
    const config = SMILE_ONE_CONFIG.platforms[platform]
    const url = `${config.baseUrl}/customer/ajax?currentUrl=${encodeURIComponent(config.baseUrl + "/customer/recharge")}&product_id=2DDA640F87A`

    const response = await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json, text/javascript, */*; q=0.01",
        "X-Requested-With": "XMLHttpRequest",
        Cookie: cookie,
        Referer: `${config.baseUrl}/customer/recharge`,
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
      },
    })

    if (!response.ok) {
      return { success: false, message: `HTTP Error: ${response.status}` }
    }

    const data = await response.json()

    if (data.loginStatus === true) {
      return {
        success: true,
        user_name: data.customer_name || "Unknown User",
        login_status: data.loginStatus,
        favorite: data.favorite || false,
        favorite_count: data.favorite_product_count || 0,
      }
    }

    return { success: false, message: "Cookie expired or invalid - Login status false" }
  } catch (error) {
    console.error("Cookie test error:", error)
    return {
      success: false,
      message: error instanceof Error ? error.message : "Cookie test failed",
    }
  }
}

// Get balance for both platforms
export async function getCombinedBalance(): Promise<{ BRL: BalanceResult; PHP: BalanceResult }> {
  const cookie = getCookie()

  const results: { BRL: BalanceResult; PHP: BalanceResult } = {
    BRL: { success: false, platform: "BRL", error: "Not configured" },
    PHP: { success: false, platform: "PHP", error: "Not configured" },
  }

  if (!cookie) {
    return results
  }

  for (const platform of ["BRL", "PHP"] as Platform[]) {
    try {
      const config = SMILE_ONE_CONFIG.platforms[platform]
      const url = `${config.baseUrl}/customer/order`

      const response = await fetch(url, {
        method: "GET",
        headers: {
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          Cookie: cookie,
          Referer: config.baseUrl,
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
        },
      })

      if (!response.ok) {
        results[platform] = {
          success: false,
          platform,
          error: `HTTP Error: ${response.status}`,
        }
        continue
      }

      const html = await response.text()

      // Parse user name
      const userNameMatch = html.match(/<div class="user-name">([^<]+)<\/div>/)
      const userName = userNameMatch ? userNameMatch[1].trim() : undefined

      // Parse balance
      const balanceMatch = html.match(
        /<div class="balance-coins">[\s\S]*?<p[^>]*>[\s\S]*?<\/p>[\s\S]*?<p[^>]*>([^<]+)<\/p>/,
      )
      const balance = balanceMatch ? balanceMatch[1].trim() : undefined

      // Parse all balance
      const allBalanceMatch = html.match(
        /<div id="all-balance">[\s\S]*?<span[^>]*>[\s\S]*?<\/span>[\s\S]*?<span[^>]*>([^<]+)<\/span>/,
      )
      const allBalance = allBalanceMatch ? allBalanceMatch[1].trim() : undefined

      if (userName || balance) {
        results[platform] = {
          success: true,
          platform,
          user_name: userName,
          balance,
          all_balance: allBalance,
        }
      } else {
        results[platform] = {
          success: false,
          platform,
          error: "Could not parse balance data. Cookie may be expired.",
        }
      }
    } catch (error) {
      console.error(`Balance check error for ${platform}:`, error)
      results[platform] = {
        success: false,
        platform,
        error: error instanceof Error ? error.message : "Balance check failed",
      }
    }
  }

  return results
}

// Get order history
export async function getOrderHistory(platform: Platform, days = 7): Promise<OrderHistoryResult> {
  const cookie = getCookie()
  if (!cookie) {
    return { success: false, message: "Cookie not configured" }
  }

  try {
    const config = SMILE_ONE_CONFIG.platforms[platform]
    const endDate = new Date().toISOString().split("T")[0]
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().split("T")[0]

    const url = `${config.baseUrl}/customer/activationcode/codelist?type=orderlist&p=1&pageSize=20&status=&startdate=${startDate}&enddate=${endDate}&key=&user_id=`

    const response = await fetch(url, {
      method: "POST",
      headers: {
        Accept: "application/json, text/javascript, */*; q=0.01",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "X-Requested-With": "XMLHttpRequest",
        Cookie: cookie,
        Referer: config.referer,
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36",
      },
    })

    if (!response.ok) {
      return { success: false, message: `HTTP Error: ${response.status}` }
    }

    const data = await response.json()
    return { success: true, data }
  } catch (error) {
    console.error("Order history error:", error)
    return {
      success: false,
      message: error instanceof Error ? error.message : "Failed to get order history",
    }
  }
}

// Diamond package definitions (from game.json structure)
export interface DiamondPackage {
  id: string
  pid: string
  amount: string
  price: number
  platform: Platform
  status: "in_stock" | "out_of_stock"
}

// Get diamond packages for MLBB
export function getDiamondPackages(): DiamondPackage[] {
  return [
    { id: "1", pid: "212", amount: "11 Diamonds", price: 850, platform: "PHP", status: "in_stock" },
    { id: "2", pid: "13", amount: "86 Diamonds", price: 5000, platform: "BRL", status: "in_stock" },
    { id: "3", pid: "25", amount: "100 Diamonds", price: 8000, platform: "BRL", status: "in_stock" },
    { id: "4", pid: "26", amount: "172 Diamonds", price: 13000, platform: "BRL", status: "in_stock" },
    { id: "5", pid: "27", amount: "257 Diamonds", price: 19000, platform: "BRL", status: "in_stock" },
    { id: "6", pid: "28", amount: "344 Diamonds", price: 25000, platform: "BRL", status: "in_stock" },
    { id: "7", pid: "29", amount: "429 Diamonds", price: 31000, platform: "BRL", status: "in_stock" },
    { id: "8", pid: "30", amount: "514 Diamonds", price: 37000, platform: "BRL", status: "in_stock" },
    { id: "9", pid: "31", amount: "600 Diamonds", price: 43000, platform: "BRL", status: "in_stock" },
    { id: "10", pid: "32", amount: "706 Diamonds", price: 50000, platform: "BRL", status: "in_stock" },
  ]
}
