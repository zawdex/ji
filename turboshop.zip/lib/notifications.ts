export async function sendTelegramNotification(
  botToken: string,
  chatId: string,
  message: string,
  options?: {
    parse_mode?: "Markdown" | "HTML"
    reply_markup?: any
  },
): Promise<boolean> {
  if (!botToken || !chatId) {
    console.warn("[v0] Telegram bot token or chat ID not configured")
    return false
  }

  try {
    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: options?.parse_mode || "Markdown",
        reply_markup: options?.reply_markup,
      }),
    })

    const result = await response.json()
    return result.ok
  } catch (error) {
    console.error("[v0] Telegram notification error:", error)
    return false
  }
}

export async function sendOrderNotification(
  botToken: string,
  adminChatId: string,
  order: {
    id: number
    user_name: string
    username?: string
    product_name: string
    amount: number
    status: string
  },
): Promise<void> {
  const message = `
*New Order Received*

Order ID: #${order.id}
Customer: ${order.user_name}${order.username ? ` (@${order.username})` : ""}
Product: ${order.product_name}
Amount: ${order.amount.toLocaleString()} MMK
Status: ${order.status}

Time: ${new Date().toLocaleString()}
  `.trim()

  await sendTelegramNotification(botToken, adminChatId, message)
}

export async function sendRechargeNotification(
  botToken: string,
  adminChatId: string,
  recharge: {
    id: number
    user_name: string
    username?: string
    amount: number
    payment_method: string
  },
): Promise<void> {
  const message = `
*New Recharge Request*

Request ID: #${recharge.id}
Customer: ${recharge.user_name}${recharge.username ? ` (@${recharge.username})` : ""}
Amount: ${recharge.amount.toLocaleString()} MMK
Payment Method: ${recharge.payment_method}

Time: ${new Date().toLocaleString()}
  `.trim()

  const keyboard = {
    inline_keyboard: [
      [
        { text: "Approve", callback_data: `recharge_approve_${recharge.id}` },
        { text: "Reject", callback_data: `recharge_reject_${recharge.id}` },
      ],
    ],
  }

  await sendTelegramNotification(botToken, adminChatId, message, { reply_markup: keyboard })
}
