import { getInitData } from "./telegram"
import type { Product, Category, Order, PaymentMethod, RechargeRequest, User, RoleCheckResult } from "./types"

const API_BASE = "/api"

interface ApiResponse<T> {
  success: boolean
  data: T
  error?: string
  timestamp: number
}

async function apiRequest<T>(
  endpoint: string,
  options?: {
    method?: string
    body?: Record<string, unknown>
    formData?: FormData
  },
): Promise<T> {
  const method = options?.method || "GET"
  const initData = getInitData()

  let url = `${API_BASE}/${endpoint}`
  const config: RequestInit = {
    method,
    headers: {},
  }

  if (options?.formData) {
    options.formData.append("initData", initData)
    config.body = options.formData
  } else if (method !== "GET" && options?.body) {
    config.headers = { "Content-Type": "application/json" }
    config.body = JSON.stringify({ ...options.body, initData })
  } else if (method === "GET") {
    const params = new URLSearchParams({ initData })
    if (options?.body) {
      Object.entries(options.body).forEach(([key, value]) => {
        if (value !== null && value !== undefined) {
          params.append(key, String(value))
        }
      })
    }
    url = `${url}?${params.toString()}`
  }

  const response = await fetch(url, config)
  const result: ApiResponse<T> = await response.json()

  if (!result.success) {
    throw new Error(result.error || "API request failed")
  }

  return result.data
}

export const api = {
  // Products
  getProducts: (category?: string) => apiRequest<Product[]>("products", { body: category ? { category } : undefined }),

  // Categories
  getCategories: () => apiRequest<Category[]>("categories"),

  // Orders
  placeOrder: (productId: number, customFields: Record<string, string>, quantity = 1) =>
    apiRequest<{ order_id: number; new_balance: number; message: string }>("orders", {
      method: "POST",
      body: { product_id: productId, custom_fields: customFields, quantity },
    }),

  autoTopup: (productId: number, customFields: Record<string, string>) =>
    apiRequest<{ order_id: number; new_balance: number; mlbb_order_id?: string; username?: string; message: string }>(
      "auto-topup",
      {
        method: "POST",
        body: { product_id: productId, custom_fields: customFields },
      },
    ),

  getOrders: (status = "all") => apiRequest<Order[]>("orders", { body: { status } }),

  // Cart
  getCart: () => apiRequest<{ items: any[]; total: number; items_count: number }>("cart"),

  addToCart: (productId: number, quantity: number, customFields: Record<string, string>) =>
    apiRequest<any>("cart", {
      method: "POST",
      body: { action: "add", product_id: productId, quantity, custom_fields: customFields },
    }),

  updateCartItem: (cartItemId: number, quantity: number) =>
    apiRequest<any>("cart", {
      method: "POST",
      body: { action: "update", cart_item_id: cartItemId, quantity },
    }),

  removeFromCart: (cartItemId: number) =>
    apiRequest<any>("cart", {
      method: "POST",
      body: { action: "remove", cart_item_id: cartItemId },
    }),

  clearCart: () =>
    apiRequest<any>("cart", {
      method: "POST",
      body: { action: "clear" },
    }),

  checkoutCart: () =>
    apiRequest<{ orders: Order[]; new_balance: number; message: string }>("cart", {
      method: "POST",
      body: { action: "checkout" },
    }),

  // Recharge
  submitRecharge: (amount: number, paymentMethodId: number, screenshot: File) => {
    const formData = new FormData()
    formData.append("amount", String(amount))
    formData.append("payment_method_id", String(paymentMethodId))
    formData.append("screenshot", screenshot)
    return apiRequest<{ recharge_id: number; message: string }>("recharge", {
      method: "POST",
      formData,
    })
  },

  getRechargeHistory: () => apiRequest<RechargeRequest[]>("recharge/history"),

  // Payment Methods
  getPaymentMethods: () => apiRequest<PaymentMethod[]>("payment-methods"),

  // Profile
  getProfile: () => apiRequest<{ user: User; recent_transactions?: any[] }>("profile"),

  // MLBB Role Check
  checkMLBBRole: (accountId: string, serverId: string) =>
    apiRequest<RoleCheckResult>("check-role", {
      method: "POST",
      body: { account_id: accountId, server_id: serverId },
    }),
}
