"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { AdminHeader } from "@/components/admin/admin-header"
import { Search, RefreshCw, Loader2, Eye, ShoppingCart, CheckCircle, Clock, XCircle } from "lucide-react"

interface Order {
  id: number
  user_id: number
  user_name: string
  product_id: number
  product_name: string
  total_price: number
  status: string
  payment_status: string
  custom_fields: Record<string, any>
  created_at: string
  mlbb_order_id?: string
}

export default function OrdersPage() {
  const router = useRouter()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [processing, setProcessing] = useState<number | null>(null)

  useEffect(() => {
    fetchOrders()
  }, [statusFilter])

  const fetchOrders = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/admin/orders?status=${statusFilter}`)
      const result = await response.json()

      if (result.success) {
        setOrders(result.data || [])
      }
    } catch (error) {
      console.error("Orders error:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleStatusChange = async (orderId: number, newStatus: string) => {
    setProcessing(orderId)
    try {
      const response = await fetch("/api/admin/orders/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order_id: orderId, status: newStatus }),
      })

      const result = await response.json()
      if (result.success) {
        fetchOrders()
        setSelectedOrder(null)
      }
    } catch (error) {
      console.error("Status update error:", error)
    } finally {
      setProcessing(null)
    }
  }

  const filteredOrders = orders.filter((order) => {
    if (!searchQuery) return true
    const query = searchQuery.toLowerCase()
    return (
      order.id.toString().includes(query) ||
      order.user_name?.toLowerCase().includes(query) ||
      order.product_name?.toLowerCase().includes(query) ||
      order.mlbb_order_id?.toLowerCase().includes(query)
    )
  })

  const getStatusBadge = (status: string) => {
    const config: Record<string, { variant: "default" | "secondary" | "outline" | "destructive"; icon: any }> = {
      completed: { variant: "default", icon: CheckCircle },
      processing: { variant: "outline", icon: Clock },
      pending: { variant: "secondary", icon: Clock },
      cancelled: { variant: "destructive", icon: XCircle },
    }
    const { variant, icon: Icon } = config[status] || { variant: "secondary", icon: Clock }
    return (
      <Badge variant={variant} className="flex items-center gap-1 w-fit">
        <Icon className="h-3 w-3" />
        {status}
      </Badge>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminSidebar />

      <div className="md:pl-64">
        <AdminHeader title="Orders" description="Manage customer orders">
          <Button variant="outline" size="sm" onClick={fetchOrders}>
            <RefreshCw className="h-4 w-4 mr-2" /> Refresh
          </Button>
        </AdminHeader>

        <main className="p-6">
          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by order ID, user, product..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Orders</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="processing">Processing</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Orders Table */}
          <Card>
            <CardHeader>
              <CardTitle>Orders ({filteredOrders.length})</CardTitle>
              <CardDescription>View and manage all customer orders</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                </div>
              ) : filteredOrders.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <ShoppingCart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No orders found</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Game Details</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredOrders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell className="font-mono">#{order.id}</TableCell>
                          <TableCell>{order.user_name}</TableCell>
                          <TableCell className="max-w-[150px] truncate">{order.product_name}</TableCell>
                          <TableCell className="font-medium">{order.total_price?.toLocaleString()} MMK</TableCell>
                          <TableCell className="text-xs">
                            {order.custom_fields?.account_id && <div>ID: {order.custom_fields.account_id}</div>}
                            {order.custom_fields?.server_id && <div>Server: {order.custom_fields.server_id}</div>}
                            {order.mlbb_order_id && (
                              <div className="text-blue-600 font-mono">MLBB: {order.mlbb_order_id}</div>
                            )}
                          </TableCell>
                          <TableCell>{getStatusBadge(order.status)}</TableCell>
                          <TableCell className="text-sm">{new Date(order.created_at).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <div className="flex gap-1">
                              <Button size="sm" variant="ghost" onClick={() => setSelectedOrder(order)}>
                                <Eye className="h-4 w-4" />
                              </Button>
                              {order.status === "pending" && (
                                <>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleStatusChange(order.id, "processing")}
                                    disabled={processing === order.id}
                                  >
                                    Process
                                  </Button>
                                  <Button
                                    size="sm"
                                    onClick={() => handleStatusChange(order.id, "completed")}
                                    disabled={processing === order.id}
                                  >
                                    Complete
                                  </Button>
                                </>
                              )}
                              {order.status === "processing" && (
                                <Button
                                  size="sm"
                                  onClick={() => handleStatusChange(order.id, "completed")}
                                  disabled={processing === order.id}
                                >
                                  Complete
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Order Detail Dialog */}
          <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Order #{selectedOrder?.id}</DialogTitle>
              </DialogHeader>
              {selectedOrder && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Customer</p>
                      <p className="font-medium">{selectedOrder.user_name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Product</p>
                      <p className="font-medium">{selectedOrder.product_name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Amount</p>
                      <p className="font-bold text-green-600">{selectedOrder.total_price.toLocaleString()} MMK</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Status</p>
                      {getStatusBadge(selectedOrder.status)}
                    </div>
                  </div>

                  {selectedOrder.custom_fields && Object.keys(selectedOrder.custom_fields).length > 0 && (
                    <div className="border-t pt-4">
                      <p className="text-sm text-gray-500 mb-2">Game Details</p>
                      <div className="bg-gray-50 rounded-lg p-3 space-y-1">
                        {Object.entries(selectedOrder.custom_fields).map(([key, value]) => (
                          <div key={key} className="flex justify-between text-sm">
                            <span className="text-gray-600 capitalize">{key.replace(/_/g, " ")}</span>
                            <span className="font-mono">{String(value)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedOrder.mlbb_order_id && (
                    <div className="border-t pt-4">
                      <p className="text-sm text-gray-500 mb-1">MLBB Order ID</p>
                      <p className="font-mono text-blue-600">{selectedOrder.mlbb_order_id}</p>
                    </div>
                  )}

                  <div className="border-t pt-4">
                    <p className="text-sm text-gray-500 mb-1">Created At</p>
                    <p className="text-sm">{new Date(selectedOrder.created_at).toLocaleString()}</p>
                  </div>

                  {selectedOrder.status !== "completed" && selectedOrder.status !== "cancelled" && (
                    <div className="flex gap-3 pt-4">
                      {selectedOrder.status === "pending" && (
                        <Button
                          variant="outline"
                          className="flex-1 bg-transparent"
                          onClick={() => handleStatusChange(selectedOrder.id, "processing")}
                          disabled={processing === selectedOrder.id}
                        >
                          Mark Processing
                        </Button>
                      )}
                      <Button
                        className="flex-1"
                        onClick={() => handleStatusChange(selectedOrder.id, "completed")}
                        disabled={processing === selectedOrder.id}
                      >
                        {processing === selectedOrder.id ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : (
                          <CheckCircle className="h-4 w-4 mr-2" />
                        )}
                        Mark Completed
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  )
}
