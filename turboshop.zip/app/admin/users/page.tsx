"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { AdminHeader } from "@/components/admin/admin-header"
import { Search, RefreshCw, Loader2, Plus, Minus, Wallet, UsersIcon, Crown } from "lucide-react"

interface User {
  id: number
  telegram_id: number
  username: string
  first_name: string
  last_name: string
  balance: number
  total_spent: number
  is_premium: boolean
  created_at: string
}

export default function UsersPage() {
  const router = useRouter()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [adjustAmount, setAdjustAmount] = useState("")
  const [adjustType, setAdjustType] = useState<"add" | "subtract">("add")
  const [adjusting, setAdjusting] = useState(false)

  useEffect(() => {
    fetchUsers()
  }, [])

  const fetchUsers = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/admin/users")
      const result = await response.json()

      if (result.success) {
        setUsers(result.data || [])
      }
    } catch (error) {
      console.error("Users error:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleBalanceAdjust = async () => {
    if (!selectedUser || !adjustAmount) return

    setAdjusting(true)
    try {
      const response = await fetch("/api/admin/users/balance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: selectedUser.id,
          amount: Number.parseFloat(adjustAmount),
          type: adjustType,
        }),
      })

      const result = await response.json()
      if (result.success) {
        fetchUsers()
        setSelectedUser(null)
        setAdjustAmount("")
      } else {
        alert(result.error || "Failed to adjust balance")
      }
    } catch (error) {
      alert("Error adjusting balance")
    } finally {
      setAdjusting(false)
    }
  }

  const filteredUsers = users.filter((user) => {
    if (!searchQuery) return true
    const query = searchQuery.toLowerCase()
    return (
      user.id.toString().includes(query) ||
      user.telegram_id.toString().includes(query) ||
      user.username?.toLowerCase().includes(query) ||
      user.first_name?.toLowerCase().includes(query)
    )
  })

  const totalBalance = users.reduce((sum, u) => sum + (u.balance || 0), 0)

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminSidebar />

      <div className="md:pl-64">
        <AdminHeader title="Users" description="Manage user accounts and balances">
          <Button variant="outline" size="sm" onClick={fetchUsers}>
            <RefreshCw className="h-4 w-4 mr-2" /> Refresh
          </Button>
        </AdminHeader>

        <main className="p-6">
          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Total Users</p>
                    <p className="text-2xl font-bold">{users.length}</p>
                  </div>
                  <UsersIcon className="h-8 w-8 text-blue-200" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Premium Users</p>
                    <p className="text-2xl font-bold text-purple-600">{users.filter((u) => u.is_premium).length}</p>
                  </div>
                  <Crown className="h-8 w-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Total Balance</p>
                    <p className="text-2xl font-bold text-green-600">{(totalBalance / 1000).toFixed(0)}K MMK</p>
                  </div>
                  <Wallet className="h-8 w-8 text-green-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Search */}
          <div className="mb-6">
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by ID, username, or name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Users Table */}
          <Card>
            <CardHeader>
              <CardTitle>Users ({filteredUsers.length})</CardTitle>
              <CardDescription>View and manage user accounts</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                </div>
              ) : filteredUsers.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <UsersIcon className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No users found</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Telegram ID</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Username</TableHead>
                        <TableHead>Balance</TableHead>
                        <TableHead>Total Spent</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-mono">#{user.id}</TableCell>
                          <TableCell className="font-mono text-sm">{user.telegram_id}</TableCell>
                          <TableCell>
                            {user.first_name} {user.last_name}
                          </TableCell>
                          <TableCell>@{user.username || "—"}</TableCell>
                          <TableCell className="font-medium text-green-600">
                            {(user.balance || 0).toLocaleString()} MMK
                          </TableCell>
                          <TableCell>{(user.total_spent || 0).toLocaleString()} MMK</TableCell>
                          <TableCell>
                            {user.is_premium ? (
                              <Badge className="bg-purple-100 text-purple-700">
                                <Crown className="h-3 w-3 mr-1" /> Premium
                              </Badge>
                            ) : (
                              <Badge variant="outline">Normal</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-sm">{new Date(user.created_at).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <Button size="sm" variant="outline" onClick={() => setSelectedUser(user)}>
                              <Wallet className="h-4 w-4 mr-1" /> Adjust
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Balance Adjust Dialog */}
          <Dialog open={!!selectedUser} onOpenChange={() => setSelectedUser(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adjust Balance</DialogTitle>
              </DialogHeader>
              {selectedUser && (
                <div className="space-y-4 pt-4">
                  <div>
                    <p className="text-sm text-gray-500">User</p>
                    <p className="font-medium">
                      {selectedUser.first_name} {selectedUser.last_name} (@{selectedUser.username})
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Current Balance</p>
                    <p className="text-2xl font-bold text-green-600">
                      {(selectedUser.balance || 0).toLocaleString()} MMK
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant={adjustType === "add" ? "default" : "outline"}
                      onClick={() => setAdjustType("add")}
                      className="flex-1"
                    >
                      <Plus className="h-4 w-4 mr-1" /> Add
                    </Button>
                    <Button
                      variant={adjustType === "subtract" ? "default" : "outline"}
                      onClick={() => setAdjustType("subtract")}
                      className="flex-1"
                    >
                      <Minus className="h-4 w-4 mr-1" /> Subtract
                    </Button>
                  </div>

                  <div>
                    <Label>Amount (MMK)</Label>
                    <Input
                      type="number"
                      placeholder="Enter amount"
                      value={adjustAmount}
                      onChange={(e) => setAdjustAmount(e.target.value)}
                      min="0"
                    />
                  </div>

                  {adjustAmount && (
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-500">New Balance</p>
                      <p className="text-xl font-bold">
                        {(
                          (selectedUser.balance || 0) +
                          (adjustType === "add" ? 1 : -1) * Number.parseFloat(adjustAmount || "0")
                        ).toLocaleString()}{" "}
                        MMK
                      </p>
                    </div>
                  )}

                  <Button className="w-full" onClick={handleBalanceAdjust} disabled={adjusting || !adjustAmount}>
                    {adjusting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                    Confirm Adjustment
                  </Button>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  )
}
