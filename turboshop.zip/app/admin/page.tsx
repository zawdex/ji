"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { AdminHeader } from "@/components/admin/admin-header"
import {
  Users,
  ShoppingCart,
  Wallet,
  TrendingUp,
  Package,
  AlertCircle,
  CheckCircle,
  Clock,
  RefreshCw,
  Loader2,
} from "lucide-react"

interface DashboardStats {
  total_users: number
  total_orders: number
  total_revenue: number
  pending_orders: number
  pending_recharges: number
  total_products: number
}

interface RecentOrder {
  id: number
  user_name: string
  product_name: string
  amount: number
  status: string
  created_at: string
}

interface PendingRecharge {
  id: number
  user_name: string
  amount: number
  payment_method: string
  status: string
  created_at: string
}

export default function AdminDashboard() {
  const router = useRouter()
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [recentOrders, setRecentOrders] = useState<RecentOrder[]>([])
  const [pendingRecharges, setPendingRecharges] = useState<PendingRecharge[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      const response = await fetch("/api/admin/dashboard")
      const result = await response.json()

      if (result.success) {
        setStats(result.data.stats)
        setRecentOrders(result.data.recent_orders)
        setPendingRecharges(result.data.pending_recharges)
      } else if (result.error === "Unauthorized") {
        router.push("/admin/login")
      }
    } catch (error) {
      console.error("Dashboard error:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleRechargeAction = async (id: number, action: "approve" | "reject") => {
    try {
      const response = await fetch("/api/admin/recharges/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ recharge_id: id, action }),
      })

      const result = await response.json()
      if (result.success) {
        fetchDashboardData()
      }
    } catch (error) {
      console.error("Recharge action error:", error)
    }
  }

  const handleOrderAction = async (id: number, status: string) => {
    try {
      const response = await fetch("/api/admin/orders/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order_id: id, status }),
      })

      const result = await response.json()
      if (result.success) {
        fetchDashboardData()
      }
    } catch (error) {
      console.error("Order action error:", error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminSidebar />

      <div className="md:pl-64">
        <AdminHeader title="Dashboard" description="Overview of your gaming store">
          <Button variant="outline" size="sm" onClick={fetchDashboardData}>
            <RefreshCw className="h-4 w-4 mr-2" /> Refresh
          </Button>
        </AdminHeader>

        <main className="p-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Total Users</p>
                    <p className="text-3xl font-bold text-gray-900">{stats?.total_users || 0}</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Total Orders</p>
                    <p className="text-3xl font-bold text-gray-900">{stats?.total_orders || 0}</p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <ShoppingCart className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Revenue</p>
                    <p className="text-3xl font-bold text-gray-900">
                      {((stats?.total_revenue || 0) / 1000).toFixed(0)}K
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <TrendingUp className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Pending Actions</p>
                    <p className="text-3xl font-bold text-orange-600">
                      {(stats?.pending_orders || 0) + (stats?.pending_recharges || 0)}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <AlertCircle className="h-6 w-6 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
            <Button
              variant="outline"
              className="h-24 flex-col gap-2 bg-transparent"
              onClick={() => router.push("/admin/products")}
            >
              <Package className="h-6 w-6 text-blue-600" />
              <span className="text-sm">Products</span>
            </Button>
            <Button
              variant="outline"
              className="h-24 flex-col gap-2 bg-transparent"
              onClick={() => router.push("/admin/orders")}
            >
              <ShoppingCart className="h-6 w-6 text-green-600" />
              <span className="text-sm">Orders</span>
            </Button>
            <Button
              variant="outline"
              className="h-24 flex-col gap-2 relative bg-transparent"
              onClick={() => router.push("/admin/recharges")}
            >
              <Wallet className="h-6 w-6 text-purple-600" />
              <span className="text-sm">Recharges</span>
              {(stats?.pending_recharges || 0) > 0 && (
                <Badge className="absolute -top-2 -right-2" variant="destructive">
                  {stats?.pending_recharges}
                </Badge>
              )}
            </Button>
            <Button
              variant="outline"
              className="h-24 flex-col gap-2 bg-transparent"
              onClick={() => router.push("/admin/users")}
            >
              <Users className="h-6 w-6 text-orange-600" />
              <span className="text-sm">Users</span>
            </Button>
            <Button
              variant="outline"
              className="h-24 flex-col gap-2 bg-gradient-to-br from-blue-500 to-purple-600 text-white border-0 hover:from-blue-600 hover:to-purple-700"
              onClick={() => router.push("/admin/smile-one")}
            >
              <span className="text-2xl">😊</span>
              <span className="text-sm">Smile One</span>
            </Button>
            <Button
              variant="outline"
              className="h-24 flex-col gap-2 bg-transparent"
              onClick={() => router.push("/admin/settings")}
            >
              <svg className="h-6 w-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                />
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                />
              </svg>
              <span className="text-sm">Settings</span>
            </Button>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="pending-recharges" className="relative">
                Pending Recharges
                {(stats?.pending_recharges || 0) > 0 && (
                  <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 flex items-center justify-center">
                    {stats?.pending_recharges}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="recent-orders">Recent Orders</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Quick Statistics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <p className="text-sm text-blue-600 font-medium">Products</p>
                        <p className="text-2xl font-bold text-blue-700">{stats?.total_products || 0}</p>
                      </div>
                      <div className="p-4 bg-green-50 rounded-lg">
                        <p className="text-sm text-green-600 font-medium">Completed</p>
                        <p className="text-2xl font-bold text-green-700">
                          {recentOrders.filter((o) => o.status === "completed").length}
                        </p>
                      </div>
                      <div className="p-4 bg-orange-50 rounded-lg">
                        <p className="text-sm text-orange-600 font-medium">Pending Orders</p>
                        <p className="text-2xl font-bold text-orange-700">{stats?.pending_orders || 0}</p>
                      </div>
                      <div className="p-4 bg-purple-50 rounded-lg">
                        <p className="text-sm text-purple-600 font-medium">Pending Recharges</p>
                        <p className="text-2xl font-bold text-purple-700">{stats?.pending_recharges || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">System Status</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <span className="font-medium">API Status</span>
                      </div>
                      <Badge className="bg-green-100 text-green-700">Online</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <span className="font-medium">Database</span>
                      </div>
                      <Badge className="bg-green-100 text-green-700">Connected</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Clock className="h-5 w-5 text-blue-500" />
                        <span className="font-medium">Last Sync</span>
                      </div>
                      <span className="text-sm text-gray-500">Just now</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="pending-recharges">
              <Card>
                <CardHeader>
                  <CardTitle>Pending Recharge Requests</CardTitle>
                  <CardDescription>Approve or reject recharge requests</CardDescription>
                </CardHeader>
                <CardContent>
                  {pendingRecharges.length === 0 ? (
                    <div className="text-center py-12 text-gray-500">
                      <Wallet className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No pending recharges</p>
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>User</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Method</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pendingRecharges.map((recharge) => (
                          <TableRow key={recharge.id}>
                            <TableCell className="font-mono">#{recharge.id}</TableCell>
                            <TableCell>{recharge.user_name}</TableCell>
                            <TableCell className="font-medium">{recharge.amount.toLocaleString()} MMK</TableCell>
                            <TableCell>{recharge.payment_method}</TableCell>
                            <TableCell>{new Date(recharge.created_at).toLocaleDateString()}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button size="sm" onClick={() => handleRechargeAction(recharge.id, "approve")}>
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleRechargeAction(recharge.id, "reject")}
                                >
                                  Reject
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="recent-orders">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Orders</CardTitle>
                  <CardDescription>Latest orders from customers</CardDescription>
                </CardHeader>
                <CardContent>
                  {recentOrders.length === 0 ? (
                    <div className="text-center py-12 text-gray-500">
                      <ShoppingCart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No orders yet</p>
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Customer</TableHead>
                          <TableHead>Product</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {recentOrders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-mono">#{order.id}</TableCell>
                            <TableCell>{order.user_name}</TableCell>
                            <TableCell className="max-w-[150px] truncate">{order.product_name}</TableCell>
                            <TableCell className="font-medium">{order.amount.toLocaleString()} MMK</TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  order.status === "completed"
                                    ? "default"
                                    : order.status === "pending"
                                      ? "secondary"
                                      : order.status === "processing"
                                        ? "outline"
                                        : "destructive"
                                }
                              >
                                {order.status}
                              </Badge>
                            </TableCell>
                            <TableCell>{new Date(order.created_at).toLocaleDateString()}</TableCell>
                            <TableCell>
                              {order.status === "pending" && (
                                <div className="flex gap-1">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleOrderAction(order.id, "processing")}
                                  >
                                    Process
                                  </Button>
                                  <Button size="sm" onClick={() => handleOrderAction(order.id, "completed")}>
                                    Complete
                                  </Button>
                                </div>
                              )}
                              {order.status === "processing" && (
                                <Button size="sm" onClick={() => handleOrderAction(order.id, "completed")}>
                                  Complete
                                </Button>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
