"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { AdminHeader } from "@/components/admin/admin-header"
import { Loader2, Save } from "lucide-react"

interface Settings {
  shop_name: string
  global_markup_percentage: number
  telegram_bot_token: string
  admin_chat_id: string
  maintenance_mode: boolean
  auto_approve_recharge: boolean
}

export default function AdminSettingsPage() {
  const router = useRouter()
  const [settings, setSettings] = useState<Settings>({
    shop_name: "Turbo Gaming",
    global_markup_percentage: 5,
    telegram_bot_token: "",
    admin_chat_id: "",
    maintenance_mode: false,
    auto_approve_recharge: false,
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    try {
      const response = await fetch("/api/admin/settings")
      const result = await response.json()

      if (result.success) {
        setSettings(result.data)
      } else if (result.error === "Unauthorized") {
        router.push("/admin/login")
      }
    } catch (error) {
      console.error("Settings error:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const response = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      })

      const result = await response.json()
      if (result.success) {
        alert("Settings saved successfully!")
      } else {
        alert("Failed to save settings: " + result.error)
      }
    } catch (error) {
      alert("Error saving settings")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <AdminSidebar />
        <div className="md:pl-64 flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminSidebar />

      <div className="md:pl-64">
        <AdminHeader title="Settings" description="Configure your store settings">
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
            Save Changes
          </Button>
        </AdminHeader>

        <main className="p-6">
          <Tabs defaultValue="general">
            <TabsList className="mb-6">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="pricing">Pricing</TabsTrigger>
              <TabsTrigger value="telegram">Telegram</TabsTrigger>
              <TabsTrigger value="advanced">Advanced</TabsTrigger>
            </TabsList>

            <TabsContent value="general">
              <Card>
                <CardHeader>
                  <CardTitle>General Settings</CardTitle>
                  <CardDescription>Basic shop configuration</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="shop_name">Shop Name</Label>
                    <Input
                      id="shop_name"
                      value={settings.shop_name}
                      onChange={(e) => setSettings({ ...settings, shop_name: e.target.value })}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <Label>Maintenance Mode</Label>
                      <p className="text-sm text-gray-500">Disable shop for users</p>
                    </div>
                    <Switch
                      checked={settings.maintenance_mode}
                      onCheckedChange={(checked) => setSettings({ ...settings, maintenance_mode: checked })}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="pricing">
              <Card>
                <CardHeader>
                  <CardTitle>Pricing Settings</CardTitle>
                  <CardDescription>Configure markup and pricing</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="markup">Global Markup Percentage (%)</Label>
                    <Input
                      id="markup"
                      type="number"
                      min="0"
                      max="100"
                      value={settings.global_markup_percentage}
                      onChange={(e) =>
                        setSettings({ ...settings, global_markup_percentage: Number.parseInt(e.target.value) || 0 })
                      }
                    />
                    <p className="text-sm text-gray-500">This percentage will be added to all product base prices</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="telegram">
              <Card>
                <CardHeader>
                  <CardTitle>Telegram Settings</CardTitle>
                  <CardDescription>Configure Telegram Bot notifications</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="bot_token">Bot Token</Label>
                    <Input
                      id="bot_token"
                      type="password"
                      placeholder="Enter your Telegram Bot Token"
                      value={settings.telegram_bot_token}
                      onChange={(e) => setSettings({ ...settings, telegram_bot_token: e.target.value })}
                    />
                    <p className="text-sm text-gray-500">Get this from @BotFather on Telegram</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="admin_chat">Admin Chat ID</Label>
                    <Input
                      id="admin_chat"
                      placeholder="Enter admin chat/group ID"
                      value={settings.admin_chat_id}
                      onChange={(e) => setSettings({ ...settings, admin_chat_id: e.target.value })}
                    />
                    <p className="text-sm text-gray-500">Notifications will be sent to this chat</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="advanced">
              <Card>
                <CardHeader>
                  <CardTitle>Advanced Settings</CardTitle>
                  <CardDescription>Advanced configuration options</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <Label>Auto-Approve Recharges</Label>
                      <p className="text-sm text-gray-500">
                        Automatically approve all recharge requests (not recommended)
                      </p>
                    </div>
                    <Switch
                      checked={settings.auto_approve_recharge}
                      onCheckedChange={(checked) => setSettings({ ...settings, auto_approve_recharge: checked })}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
