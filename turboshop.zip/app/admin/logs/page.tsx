"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { AdminHeader } from "@/components/admin/admin-header"
import { RefreshCw, Loader2, FileText, Search } from "lucide-react"

interface LogEntry {
  id: number
  type: string
  action: string
  user_id?: number
  admin_id?: number
  details: Record<string, any>
  ip_address?: string
  created_at: string
}

export default function AdminLogsPage() {
  const router = useRouter()
  const [logs, setLogs] = useState<LogEntry[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({
    type: "all",
    level: "all",
    search: "",
  })
  const [page, setPage] = useState(1)
  const limit = 20

  useEffect(() => {
    fetchLogs()
  }, [filters, page])

  const fetchLogs = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({
        limit: String(limit),
        offset: String((page - 1) * limit),
      })

      if (filters.type !== "all") params.append("type", filters.type)
      if (filters.level !== "all") params.append("level", filters.level)

      const response = await fetch(`/api/admin/logs?${params}`)
      const result = await response.json()

      if (result.success) {
        setLogs(result.data.logs)
        setTotal(result.data.total)
      } else if (result.error === "Unauthorized") {
        router.push("/admin/login")
      }
    } catch (error) {
      console.error("Logs error:", error)
    } finally {
      setLoading(false)
    }
  }

  const getLevelBadge = (level: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      info: "secondary",
      warning: "outline",
      error: "destructive",
      critical: "destructive",
    }
    return <Badge variant={variants[level] || "secondary"}>{level}</Badge>
  }

  const getTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      admin_action: "bg-purple-100 text-purple-800",
      order: "bg-blue-100 text-blue-800",
      recharge: "bg-green-100 text-green-800",
      system: "bg-gray-100 text-gray-800",
      error: "bg-red-100 text-red-800",
      security: "bg-orange-100 text-orange-800",
    }
    return <span className={`px-2 py-1 rounded text-xs font-medium ${colors[type] || "bg-gray-100"}`}>{type}</span>
  }

  const totalPages = Math.ceil(total / limit)

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminSidebar />

      <div className="md:pl-64">
        <AdminHeader title="System Logs" description="Activity logs and audit trail">
          <Button variant="outline" size="sm" onClick={fetchLogs}>
            <RefreshCw className="h-4 w-4 mr-2" /> Refresh
          </Button>
        </AdminHeader>

        <main className="p-6">
          {/* Filters */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex flex-wrap gap-4">
                <div className="w-40">
                  <Select value={filters.type} onValueChange={(v) => setFilters({ ...filters, type: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Log Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="admin_action">Admin Actions</SelectItem>
                      <SelectItem value="order">Orders</SelectItem>
                      <SelectItem value="recharge">Recharges</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                      <SelectItem value="error">Errors</SelectItem>
                      <SelectItem value="security">Security</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="w-40">
                  <Select value={filters.level} onValueChange={(v) => setFilters({ ...filters, level: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Log Level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="info">Info</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="error">Error</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex-1 min-w-[200px] relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search logs..."
                    value={filters.search}
                    onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Logs Table */}
          <Card>
            <CardHeader>
              <CardTitle>Logs ({total})</CardTitle>
              <CardDescription>System activity and audit trail</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                </div>
              ) : logs.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No logs found</p>
                </div>
              ) : (
                <>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Level</TableHead>
                          <TableHead>Action</TableHead>
                          <TableHead>User/Admin</TableHead>
                          <TableHead>Details</TableHead>
                          <TableHead>Time</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {logs.map((log) => (
                          <TableRow key={log.id}>
                            <TableCell className="font-mono text-xs">#{log.id}</TableCell>
                            <TableCell>{getTypeBadge(log.type)}</TableCell>
                            <TableCell>{getLevelBadge(log.details?.level || "info")}</TableCell>
                            <TableCell className="font-medium">{log.action}</TableCell>
                            <TableCell>
                              {log.admin_id ? `Admin #${log.admin_id}` : log.user_id ? `User #${log.user_id}` : "-"}
                            </TableCell>
                            <TableCell className="max-w-xs truncate text-xs text-gray-500">
                              {JSON.stringify(log.details).slice(0, 50)}...
                            </TableCell>
                            <TableCell className="text-xs">{new Date(log.created_at).toLocaleString()}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Pagination */}
                  <div className="flex justify-between items-center mt-4 pt-4 border-t">
                    <p className="text-sm text-gray-500">
                      Showing {(page - 1) * limit + 1} - {Math.min(page * limit, total)} of {total}
                    </p>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>
                        Previous
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={page >= totalPages}
                        onClick={() => setPage((p) => p + 1)}
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  )
}
