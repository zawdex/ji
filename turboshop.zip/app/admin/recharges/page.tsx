"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { AdminHeader } from "@/components/admin/admin-header"
import { Search, RefreshCw, Loader2, CheckCircle, XCircle, Eye, Wallet, ImageIcon } from "lucide-react"

interface Recharge {
  id: number
  user_id: number
  user_name: string
  amount: number
  payment_method_name: string
  transaction_id: string
  screenshot_path?: string
  status: "pending" | "approved" | "rejected"
  admin_note?: string
  created_at: string
  processed_at?: string
}

export default function RechargesPage() {
  const router = useRouter()
  const [recharges, setRecharges] = useState<Recharge[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedRecharge, setSelectedRecharge] = useState<Recharge | null>(null)
  const [processing, setProcessing] = useState<number | null>(null)

  useEffect(() => {
    fetchRecharges()
  }, [statusFilter])

  const fetchRecharges = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/admin/recharges?status=${statusFilter}`)
      const result = await response.json()

      if (result.success) {
        setRecharges(result.data || [])
      }
    } catch (error) {
      console.error("Recharges error:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleAction = async (id: number, action: "approve" | "reject") => {
    setProcessing(id)
    try {
      const response = await fetch("/api/admin/recharges/action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ recharge_id: id, action }),
      })

      const result = await response.json()
      if (result.success) {
        fetchRecharges()
        setSelectedRecharge(null)
      } else {
        alert(result.error || "Action failed")
      }
    } catch (error) {
      alert("Error processing recharge")
    } finally {
      setProcessing(null)
    }
  }

  const filteredRecharges = recharges.filter((recharge) => {
    if (!searchQuery) return true
    const query = searchQuery.toLowerCase()
    return (
      recharge.id.toString().includes(query) ||
      recharge.user_name?.toLowerCase().includes(query) ||
      recharge.transaction_id?.toLowerCase().includes(query)
    )
  })

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      approved: "default",
      pending: "secondary",
      rejected: "destructive",
    }
    return <Badge variant={variants[status] || "secondary"}>{status}</Badge>
  }

  const pendingCount = recharges.filter((r) => r.status === "pending").length

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminSidebar />

      <div className="md:pl-64">
        <AdminHeader title="Recharges" description="Manage user balance recharges">
          <Button variant="outline" size="sm" onClick={fetchRecharges}>
            <RefreshCw className="h-4 w-4 mr-2" /> Refresh
          </Button>
        </AdminHeader>

        <main className="p-6">
          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Pending</p>
                    <p className="text-2xl font-bold text-orange-600">{pendingCount}</p>
                  </div>
                  <Wallet className="h-8 w-8 text-orange-200" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Approved Today</p>
                    <p className="text-2xl font-bold text-green-600">
                      {recharges.filter((r) => r.status === "approved").length}
                    </p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-green-200" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Total Amount</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {(
                        recharges.filter((r) => r.status === "approved").reduce((sum, r) => sum + r.amount, 0) / 1000
                      ).toFixed(0)}
                      K
                    </p>
                  </div>
                  <Wallet className="h-8 w-8 text-blue-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by ID, user, or transaction..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Recharges</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Recharges Table */}
          <Card>
            <CardHeader>
              <CardTitle>Recharge Requests ({filteredRecharges.length})</CardTitle>
              <CardDescription>Review and process recharge requests</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                </div>
              ) : filteredRecharges.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Wallet className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>No recharges found</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>User</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Method</TableHead>
                        <TableHead>Transaction ID</TableHead>
                        <TableHead>Screenshot</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredRecharges.map((recharge) => (
                        <TableRow key={recharge.id}>
                          <TableCell className="font-mono">#{recharge.id}</TableCell>
                          <TableCell>{recharge.user_name}</TableCell>
                          <TableCell className="font-medium text-green-600">
                            {recharge.amount.toLocaleString()} MMK
                          </TableCell>
                          <TableCell>{recharge.payment_method_name}</TableCell>
                          <TableCell className="font-mono text-xs max-w-[120px] truncate">
                            {recharge.transaction_id || "—"}
                          </TableCell>
                          <TableCell>
                            {recharge.screenshot_path ? (
                              <Button size="sm" variant="ghost" onClick={() => setSelectedRecharge(recharge)}>
                                <ImageIcon className="h-4 w-4" />
                              </Button>
                            ) : (
                              "—"
                            )}
                          </TableCell>
                          <TableCell>{getStatusBadge(recharge.status)}</TableCell>
                          <TableCell className="text-sm">
                            {new Date(recharge.created_at).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            {recharge.status === "pending" ? (
                              <div className="flex gap-1">
                                <Button
                                  size="sm"
                                  onClick={() => handleAction(recharge.id, "approve")}
                                  disabled={processing === recharge.id}
                                >
                                  {processing === recharge.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <CheckCircle className="h-4 w-4" />
                                  )}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleAction(recharge.id, "reject")}
                                  disabled={processing === recharge.id}
                                >
                                  <XCircle className="h-4 w-4" />
                                </Button>
                              </div>
                            ) : (
                              <Button size="sm" variant="ghost" onClick={() => setSelectedRecharge(recharge)}>
                                <Eye className="h-4 w-4" />
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recharge Detail Dialog */}
          <Dialog open={!!selectedRecharge} onOpenChange={() => setSelectedRecharge(null)}>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Recharge Details #{selectedRecharge?.id}</DialogTitle>
              </DialogHeader>
              {selectedRecharge && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">User</p>
                      <p className="font-medium">{selectedRecharge.user_name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Amount</p>
                      <p className="font-bold text-green-600">{selectedRecharge.amount.toLocaleString()} MMK</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Payment Method</p>
                      <p className="font-medium">{selectedRecharge.payment_method_name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Transaction ID</p>
                      <p className="font-mono text-sm">{selectedRecharge.transaction_id || "—"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Status</p>
                      {getStatusBadge(selectedRecharge.status)}
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Date</p>
                      <p className="text-sm">{new Date(selectedRecharge.created_at).toLocaleString()}</p>
                    </div>
                  </div>

                  {selectedRecharge.screenshot_path && (
                    <div>
                      <p className="text-sm text-gray-500 mb-2">Screenshot</p>
                      <div className="border rounded-lg overflow-hidden">
                        <img
                          src={selectedRecharge.screenshot_path || "/placeholder.svg"}
                          alt="Payment screenshot"
                          className="w-full max-h-64 object-contain"
                        />
                      </div>
                    </div>
                  )}

                  {selectedRecharge.status === "pending" && (
                    <div className="flex gap-3 pt-4">
                      <Button
                        className="flex-1"
                        onClick={() => handleAction(selectedRecharge.id, "approve")}
                        disabled={processing === selectedRecharge.id}
                      >
                        {processing === selectedRecharge.id ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : (
                          <CheckCircle className="h-4 w-4 mr-2" />
                        )}
                        Approve
                      </Button>
                      <Button
                        variant="destructive"
                        className="flex-1"
                        onClick={() => handleAction(selectedRecharge.id, "reject")}
                        disabled={processing === selectedRecharge.id}
                      >
                        <XCircle className="h-4 w-4 mr-2" />
                        Reject
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </DialogContent>
          </Dialog>
        </main>
      </div>
    </div>
  )
}
