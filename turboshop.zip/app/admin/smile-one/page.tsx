"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { AdminHeader } from "@/components/admin/admin-header"
import {
  RefreshCw,
  Save,
  Trash2,
  CheckCircle,
  XCircle,
  Loader2,
  Cookie,
  Wallet,
  History,
  AlertTriangle,
} from "lucide-react"

interface PlatformStatus {
  success: boolean
  user_name?: string
  login_status?: boolean
  message?: string
}

interface BalanceData {
  success: boolean
  platform: string
  user_name?: string
  balance?: string
  all_balance?: string
  error?: string
}

interface OrderHistoryItem {
  id: string
  product: string
  amount: string
  status: string
  date: string
}

export default function SmileOnePage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState(false)
  const [deleting, setDeleting] = useState(false)

  const [cookieValue, setCookieValue] = useState("")
  const [configured, setConfigured] = useState(false)
  const [platforms, setPlatforms] = useState<{ BRL?: PlatformStatus; PHP?: PlatformStatus }>({})
  const [balances, setBalances] = useState<{ BRL?: BalanceData; PHP?: BalanceData }>({})
  const [orders, setOrders] = useState<OrderHistoryItem[]>([])
  const [activeTab, setActiveTab] = useState("cookie")
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)

  useEffect(() => {
    fetchStatus()
  }, [])

  const fetchStatus = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/admin/smile-one?action=status")
      const result = await response.json()

      if (result.success) {
        setConfigured(result.data.configured)
        if (result.data.platforms) {
          setPlatforms(result.data.platforms)
        }
      }
    } catch (error) {
      console.error("Status error:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchBalances = async () => {
    try {
      const response = await fetch("/api/admin/smile-one?action=balance")
      const result = await response.json()

      if (result.success) {
        setBalances(result.data)
      }
    } catch (error) {
      console.error("Balance error:", error)
    }
  }

  const fetchOrders = async (platform: "BRL" | "PHP" = "BRL") => {
    try {
      const response = await fetch(`/api/admin/smile-one?action=orders&platform=${platform}`)
      const result = await response.json()

      if (result.success && result.data) {
        setOrders(result.data.list || [])
      }
    } catch (error) {
      console.error("Orders error:", error)
    }
  }

  const handleSaveCookie = async () => {
    if (!cookieValue.trim()) {
      setMessage({ type: "error", text: "Please enter a cookie value" })
      return
    }

    setSaving(true)
    setMessage(null)

    try {
      const response = await fetch("/api/admin/smile-one", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "save", cookie: cookieValue }),
      })

      const result = await response.json()

      if (result.success) {
        setMessage({ type: "success", text: "Cookie saved and validated successfully!" })
        setConfigured(true)
        setPlatforms(result.data.platforms)
        setCookieValue("")
        fetchBalances()
      } else {
        setMessage({ type: "error", text: result.error || "Failed to save cookie" })
      }
    } catch (error) {
      setMessage({ type: "error", text: "Network error. Please try again." })
    } finally {
      setSaving(false)
    }
  }

  const handleTestCookie = async () => {
    setTesting(true)
    setMessage(null)

    try {
      const response = await fetch("/api/admin/smile-one", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "test" }),
      })

      const result = await response.json()

      if (result.success) {
        setPlatforms(result.data)
        const brlOk = result.data.BRL?.success
        const phpOk = result.data.PHP?.success

        if (brlOk && phpOk) {
          setMessage({ type: "success", text: "Cookie is valid on both platforms!" })
        } else if (brlOk || phpOk) {
          setMessage({ type: "success", text: `Cookie is valid on ${brlOk ? "BRL" : "PHP"} platform only.` })
        } else {
          setMessage({ type: "error", text: "Cookie is invalid or expired on both platforms." })
        }
      } else {
        setMessage({ type: "error", text: result.error || "Test failed" })
      }
    } catch (error) {
      setMessage({ type: "error", text: "Network error. Please try again." })
    } finally {
      setTesting(false)
    }
  }

  const handleDeleteCookie = async () => {
    if (!confirm("Are you sure you want to delete the Smile One cookie?")) return

    setDeleting(true)
    setMessage(null)

    try {
      const response = await fetch("/api/admin/smile-one", { method: "DELETE" })
      const result = await response.json()

      if (result.success) {
        setMessage({ type: "success", text: "Cookie deleted successfully" })
        setConfigured(false)
        setPlatforms({})
        setBalances({})
      } else {
        setMessage({ type: "error", text: result.error || "Failed to delete cookie" })
      }
    } catch (error) {
      setMessage({ type: "error", text: "Network error. Please try again." })
    } finally {
      setDeleting(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <AdminSidebar />
        <div className="md:pl-64 flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminSidebar />

      <div className="md:pl-64">
        <AdminHeader title="Smile One Integration" description="Manage cookie and auto top-up settings">
          <Button variant="outline" size="sm" onClick={fetchStatus}>
            <RefreshCw className="h-4 w-4 mr-2" /> Refresh
          </Button>
        </AdminHeader>

        <main className="p-6">
          {/* Status Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Cookie Status</p>
                    <div className="flex items-center gap-2 mt-1">
                      {configured ? (
                        <>
                          <CheckCircle className="h-5 w-5 text-green-500" />
                          <span className="font-medium text-green-600">Configured</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="h-5 w-5 text-red-500" />
                          <span className="font-medium text-red-600">Not Configured</span>
                        </>
                      )}
                    </div>
                  </div>
                  <Cookie className="h-8 w-8 text-gray-200" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">BRL Platform</p>
                    <div className="flex items-center gap-2 mt-1">
                      {platforms.BRL?.success ? (
                        <>
                          <CheckCircle className="h-5 w-5 text-green-500" />
                          <span className="font-medium text-green-600">{platforms.BRL.user_name || "Active"}</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="h-5 w-5 text-gray-400" />
                          <span className="font-medium text-gray-500">Inactive</span>
                        </>
                      )}
                    </div>
                  </div>
                  <span className="text-2xl">🇧🇷</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">PHP Platform</p>
                    <div className="flex items-center gap-2 mt-1">
                      {platforms.PHP?.success ? (
                        <>
                          <CheckCircle className="h-5 w-5 text-green-500" />
                          <span className="font-medium text-green-600">{platforms.PHP.user_name || "Active"}</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="h-5 w-5 text-gray-400" />
                          <span className="font-medium text-gray-500">Inactive</span>
                        </>
                      )}
                    </div>
                  </div>
                  <span className="text-2xl">🇵🇭</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Message Alert */}
          {message && (
            <Alert
              className={`mb-6 ${message.type === "success" ? "border-green-500 bg-green-50" : "border-red-500 bg-red-50"}`}
            >
              {message.type === "success" ? (
                <CheckCircle className="h-4 w-4 text-green-600" />
              ) : (
                <AlertTriangle className="h-4 w-4 text-red-600" />
              )}
              <AlertDescription className={message.type === "success" ? "text-green-700" : "text-red-700"}>
                {message.text}
              </AlertDescription>
            </Alert>
          )}

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="cookie" className="flex items-center gap-2">
                <Cookie className="h-4 w-4" /> Cookie Management
              </TabsTrigger>
              <TabsTrigger value="balance" className="flex items-center gap-2" onClick={fetchBalances}>
                <Wallet className="h-4 w-4" /> Balance
              </TabsTrigger>
              <TabsTrigger value="history" className="flex items-center gap-2" onClick={() => fetchOrders("BRL")}>
                <History className="h-4 w-4" /> Order History
              </TabsTrigger>
            </TabsList>

            <TabsContent value="cookie">
              <Card>
                <CardHeader>
                  <CardTitle>Smile One Cookie</CardTitle>
                  <CardDescription>
                    Enter your Smile One cookie to enable auto top-up functionality. One cookie works for both BRL and
                    PHP platforms.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Cookie String</label>
                    <Textarea
                      placeholder="Paste your Smile One cookie here..."
                      value={cookieValue}
                      onChange={(e) => setCookieValue(e.target.value)}
                      rows={4}
                      className="font-mono text-xs"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Get this from browser DevTools (Network tab) when logged into smile.one
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <Button onClick={handleSaveCookie} disabled={saving || !cookieValue.trim()}>
                      {saving ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                      Save Cookie
                    </Button>

                    {configured && (
                      <>
                        <Button variant="outline" onClick={handleTestCookie} disabled={testing}>
                          {testing ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : (
                            <RefreshCw className="h-4 w-4 mr-2" />
                          )}
                          Test Cookie
                        </Button>

                        <Button variant="destructive" onClick={handleDeleteCookie} disabled={deleting}>
                          {deleting ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : (
                            <Trash2 className="h-4 w-4 mr-2" />
                          )}
                          Delete Cookie
                        </Button>
                      </>
                    )}
                  </div>

                  {/* Platform Status Details */}
                  {configured && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 pt-6 border-t">
                      <div
                        className={`p-4 rounded-lg ${platforms.BRL?.success ? "bg-green-50 border border-green-200" : "bg-gray-50 border border-gray-200"}`}
                      >
                        <h4 className="font-medium text-gray-900 mb-2">BRL Platform (Brazil)</h4>
                        {platforms.BRL?.success ? (
                          <div className="text-sm text-green-700">
                            <p>Status: Active</p>
                            <p>User: {platforms.BRL.user_name}</p>
                          </div>
                        ) : (
                          <p className="text-sm text-gray-500">{platforms.BRL?.message || "Not active"}</p>
                        )}
                      </div>

                      <div
                        className={`p-4 rounded-lg ${platforms.PHP?.success ? "bg-green-50 border border-green-200" : "bg-gray-50 border border-gray-200"}`}
                      >
                        <h4 className="font-medium text-gray-900 mb-2">PHP Platform (Philippines)</h4>
                        {platforms.PHP?.success ? (
                          <div className="text-sm text-green-700">
                            <p>Status: Active</p>
                            <p>User: {platforms.PHP.user_name}</p>
                          </div>
                        ) : (
                          <p className="text-sm text-gray-500">{platforms.PHP?.message || "Not active"}</p>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="balance">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Smile Coin Balance</CardTitle>
                    <CardDescription>Current balance on both platforms</CardDescription>
                  </div>
                  <Button variant="outline" size="sm" onClick={fetchBalances}>
                    <RefreshCw className="h-4 w-4 mr-2" /> Refresh
                  </Button>
                </CardHeader>
                <CardContent>
                  {!configured ? (
                    <div className="text-center py-8 text-gray-500">Please configure Smile One cookie first</div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="p-6 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl text-white">
                        <h3 className="text-lg font-medium mb-1 opacity-90">BRL Platform</h3>
                        {balances.BRL?.success ? (
                          <>
                            <p className="text-3xl font-bold">{balances.BRL.balance || "0"}</p>
                            <p className="text-sm opacity-75 mt-1">User: {balances.BRL.user_name}</p>
                            {balances.BRL.all_balance && (
                              <p className="text-sm opacity-75">Total: {balances.BRL.all_balance}</p>
                            )}
                          </>
                        ) : (
                          <p className="text-sm opacity-75">{balances.BRL?.error || "Unable to fetch balance"}</p>
                        )}
                      </div>

                      <div className="p-6 bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl text-white">
                        <h3 className="text-lg font-medium mb-1 opacity-90">PHP Platform</h3>
                        {balances.PHP?.success ? (
                          <>
                            <p className="text-3xl font-bold">{balances.PHP.balance || "0"}</p>
                            <p className="text-sm opacity-75 mt-1">User: {balances.PHP.user_name}</p>
                            {balances.PHP.all_balance && (
                              <p className="text-sm opacity-75">Total: {balances.PHP.all_balance}</p>
                            )}
                          </>
                        ) : (
                          <p className="text-sm opacity-75">{balances.PHP?.error || "Unable to fetch balance"}</p>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="history">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Smile One Order History</CardTitle>
                    <CardDescription>Recent orders from Smile One</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => fetchOrders("BRL")}>
                      BRL Orders
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => fetchOrders("PHP")}>
                      PHP Orders
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {!configured ? (
                    <div className="text-center py-8 text-gray-500">Please configure Smile One cookie first</div>
                  ) : orders.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">No orders found</div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Order ID</TableHead>
                          <TableHead>Product</TableHead>
                          <TableHead>Amount</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {orders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-mono text-sm">{order.id}</TableCell>
                            <TableCell>{order.product}</TableCell>
                            <TableCell>{order.amount}</TableCell>
                            <TableCell>
                              <Badge variant={order.status === "success" ? "default" : "destructive"}>
                                {order.status}
                              </Badge>
                            </TableCell>
                            <TableCell>{order.date}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
