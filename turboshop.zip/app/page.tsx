import { TelegramProvider } from "@/components/telegram-provider"
import { AppContent } from "@/components/app-content"

export default function Home() {
  return (
    <TelegramProvider>
      <AppContent />
    </TelegramProvider>
  )
}
