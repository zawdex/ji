import { NextResponse } from "next/server"
import { getTelegramUserFromRequest } from "@/lib/telegram-auth"
import { getUser, createUser } from "@/lib/db-helpers"
import {
  getCart,
  addToCart,
  updateCartItem,
  removeFromCart,
  clearCart,
  getCartTotal,
  checkoutCart,
} from "@/lib/cart-helpers"
import { createLog } from "@/lib/db-helpers"

export async function GET(request: Request) {
  try {
    const telegramUser = getTelegramUserFromRequest(request)

    if (!telegramUser) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    let user = await getUser(telegramUser.id)
    if (!user) {
      user = await createUser(telegramUser.id, telegramUser)
    }

    const cart = await getCart(user.id)
    const totals = await getCartTotal(user.id)

    return NextResponse.json({
      success: true,
      data: {
        items: cart,
        ...totals,
      },
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("[Cart GET] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to get cart" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const telegramUser = getTelegramUserFromRequest(request)

    if (!telegramUser) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    let user = await getUser(telegramUser.id)
    if (!user) {
      user = await createUser(telegramUser.id, telegramUser)
    }

    const body = await request.json()
    const { action, product_id, quantity = 1, custom_fields = {}, cart_item_id } = body

    switch (action) {
      case "add": {
        const item = await addToCart(user.id, product_id, quantity, custom_fields)
        await createLog({
          type: "order",
          action: "cart_add",
          user_id: user.id,
          details: { product_id, quantity },
        })
        return NextResponse.json({
          success: true,
          data: item,
          message: "Added to cart",
          timestamp: Date.now(),
        })
      }

      case "update": {
        await updateCartItem(user.id, cart_item_id, quantity)
        return NextResponse.json({
          success: true,
          message: "Cart updated",
          timestamp: Date.now(),
        })
      }

      case "remove": {
        await removeFromCart(user.id, cart_item_id)
        return NextResponse.json({
          success: true,
          message: "Removed from cart",
          timestamp: Date.now(),
        })
      }

      case "clear": {
        await clearCart(user.id)
        return NextResponse.json({
          success: true,
          message: "Cart cleared",
          timestamp: Date.now(),
        })
      }

      case "checkout": {
        const result = await checkoutCart(user.id, user.balance)

        // Update user balance in database
        const { updateData } = await import("@/lib/database")
        const { SCHEMA } = await import("@/lib/db-schema")

        await updateData(SCHEMA.USERS, [], (users: any[]) => {
          const u = users.find((u) => u.id === user!.id)
          if (u) {
            u.balance = result.newBalance
            u.total_spent += result.orders.reduce((sum, o) => sum + o.total_price, 0)
          }
          return users
        })

        await createLog({
          type: "order",
          action: "cart_checkout",
          user_id: user.id,
          details: {
            orders_count: result.orders.length,
            total_amount: result.orders.reduce((sum, o) => sum + o.total_price, 0),
          },
        })

        return NextResponse.json({
          success: true,
          data: {
            orders: result.orders,
            new_balance: result.newBalance,
          },
          message: `Checkout complete. ${result.orders.length} order(s) created.`,
          timestamp: Date.now(),
        })
      }

      default:
        return NextResponse.json({ success: false, error: "Invalid action" }, { status: 400 })
    }
  } catch (error: any) {
    console.error("[Cart POST] Error:", error)
    return NextResponse.json({ success: false, error: error.message || "Cart operation failed" }, { status: 500 })
  }
}
