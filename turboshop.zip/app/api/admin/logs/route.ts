import { NextResponse } from "next/server"
import { getAdminFromRequest } from "@/lib/admin-auth"
import { getLogs } from "@/lib/logger"
import type { LogType, LogLevel } from "@/lib/logger"

export async function GET(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)

    const options: {
      type?: LogType
      level?: LogLevel
      user_id?: number
      admin_id?: number
      from_date?: string
      to_date?: string
      limit?: number
      offset?: number
    } = {}

    const type = searchParams.get("type")
    if (type && type !== "all") options.type = type as LogType

    const level = searchParams.get("level")
    if (level && level !== "all") options.level = level as LogLevel

    const userId = searchParams.get("user_id")
    if (userId) options.user_id = Number.parseInt(userId)

    const adminId = searchParams.get("admin_id")
    if (adminId) options.admin_id = Number.parseInt(adminId)

    const fromDate = searchParams.get("from_date")
    if (fromDate) options.from_date = fromDate

    const toDate = searchParams.get("to_date")
    if (toDate) options.to_date = toDate

    const limit = searchParams.get("limit")
    options.limit = limit ? Number.parseInt(limit) : 50

    const offset = searchParams.get("offset")
    options.offset = offset ? Number.parseInt(offset) : 0

    const { logs, total } = await getLogs(options)

    return NextResponse.json({
      success: true,
      data: { logs, total },
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("[Admin Logs] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch logs" }, { status: 500 })
  }
}
