import { NextResponse } from "next/server"
import { getAdminFromRequest, hasPermission } from "@/lib/admin-auth"
import { readData, writeData } from "@/lib/database"
import { SCHEMA, DEFAULT_PRODUCTS } from "@/lib/db-schema"
import { createLog } from "@/lib/db-helpers"
import type { DbProduct } from "@/lib/db-types"

export async function GET(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const products = await readData<DbProduct[]>(SCHEMA.PRODUCTS, DEFAULT_PRODUCTS)

    return NextResponse.json({
      success: true,
      data: products.sort((a, b) => b.id - a.id),
    })
  } catch (error) {
    console.error("[Admin Products GET] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch products" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    if (!hasPermission(admin, "manage_products")) {
      return NextResponse.json({ success: false, error: "Permission denied" }, { status: 403 })
    }

    const body = await request.json()
    const products = await readData<DbProduct[]>(SCHEMA.PRODUCTS, DEFAULT_PRODUCTS)

    const newProduct: DbProduct = {
      id: Math.max(0, ...products.map((p) => p.id)) + 1,
      name: body.name,
      description: body.description || "",
      category_id: body.category_id,
      base_price: body.base_price,
      final_price: body.base_price,
      image_url: body.image_url || "",
      is_active: body.is_active !== false,
      stock: body.stock ?? -1,
      auto_delivery: body.auto_delivery || false,
      platform: body.platform || "BRL",
      pid: body.pid || "",
      custom_fields: [],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }

    products.push(newProduct)
    await writeData(SCHEMA.PRODUCTS, products)

    await createLog({
      type: "admin_action",
      action: "product_created",
      admin_id: admin.id,
      details: { product_id: newProduct.id, name: newProduct.name },
    })

    return NextResponse.json({
      success: true,
      data: newProduct,
    })
  } catch (error) {
    console.error("[Admin Products POST] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to create product" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    if (!hasPermission(admin, "manage_products")) {
      return NextResponse.json({ success: false, error: "Permission denied" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const productId = Number.parseInt(searchParams.get("id") || "0")

    if (!productId) {
      return NextResponse.json({ success: false, error: "Product ID required" }, { status: 400 })
    }

    const body = await request.json()
    const products = await readData<DbProduct[]>(SCHEMA.PRODUCTS, DEFAULT_PRODUCTS)

    const index = products.findIndex((p) => p.id === productId)
    if (index === -1) {
      return NextResponse.json({ success: false, error: "Product not found" }, { status: 404 })
    }

    products[index] = {
      ...products[index],
      name: body.name ?? products[index].name,
      description: body.description ?? products[index].description,
      category_id: body.category_id ?? products[index].category_id,
      base_price: body.base_price ?? products[index].base_price,
      final_price: body.base_price ?? products[index].base_price,
      image_url: body.image_url ?? products[index].image_url,
      is_active: body.is_active ?? products[index].is_active,
      stock: body.stock ?? products[index].stock,
      auto_delivery: body.auto_delivery ?? products[index].auto_delivery,
      platform: body.platform ?? products[index].platform,
      pid: body.pid ?? products[index].pid,
      updated_at: new Date().toISOString(),
    }

    await writeData(SCHEMA.PRODUCTS, products)

    await createLog({
      type: "admin_action",
      action: "product_updated",
      admin_id: admin.id,
      details: { product_id: productId },
    })

    return NextResponse.json({
      success: true,
      data: products[index],
    })
  } catch (error) {
    console.error("[Admin Products PUT] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to update product" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    if (!hasPermission(admin, "manage_products")) {
      return NextResponse.json({ success: false, error: "Permission denied" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const productId = Number.parseInt(searchParams.get("id") || "0")

    if (!productId) {
      return NextResponse.json({ success: false, error: "Product ID required" }, { status: 400 })
    }

    const products = await readData<DbProduct[]>(SCHEMA.PRODUCTS, DEFAULT_PRODUCTS)
    const filtered = products.filter((p) => p.id !== productId)

    if (filtered.length === products.length) {
      return NextResponse.json({ success: false, error: "Product not found" }, { status: 404 })
    }

    await writeData(SCHEMA.PRODUCTS, filtered)

    await createLog({
      type: "admin_action",
      action: "product_deleted",
      admin_id: admin.id,
      details: { product_id: productId },
    })

    return NextResponse.json({
      success: true,
      message: "Product deleted",
    })
  } catch (error) {
    console.error("[Admin Products DELETE] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to delete product" }, { status: 500 })
  }
}
