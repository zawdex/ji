import { NextResponse } from "next/server"
import { updateUserBalance, getUser, createTransaction } from "@/lib/db-helpers"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { user_id, amount, type } = body

    if (!user_id || !amount || !type) {
      return NextResponse.json(
        {
          success: false,
          error: "User ID, amount, and type are required",
        },
        { status: 400 },
      )
    }

    if (!["add", "subtract"].includes(type)) {
      return NextResponse.json(
        {
          success: false,
          error: "Type must be 'add' or 'subtract'",
        },
        { status: 400 },
      )
    }

    const user = await getUser(user_id)
    if (!user) {
      return NextResponse.json(
        {
          success: false,
          error: "User not found",
        },
        { status: 404 },
      )
    }

    const balanceBefore = user.balance
    const newBalance = type === "add" ? balanceBefore + amount : Math.max(0, balanceBefore - amount)

    await updateUserBalance(user_id, amount, type)

    // Log the transaction
    await createTransaction({
      user_id: user_id,
      type: type === "add" ? "admin_credit" : "admin_debit",
      amount: amount,
      balance_before: balanceBefore,
      balance_after: newBalance,
      reference_type: "admin_adjustment",
      reference_id: 0,
      description: `Admin balance adjustment: ${type} ${amount} MMK`,
    })

    return NextResponse.json({
      success: true,
      data: {
        user_id,
        balance_before: balanceBefore,
        balance_after: newBalance,
        adjustment: type === "add" ? amount : -amount,
      },
    })
  } catch (error) {
    console.error("Balance adjust error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to adjust balance",
      },
      { status: 500 },
    )
  }
}
