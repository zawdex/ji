import { NextResponse } from "next/server"
import { readData } from "@/lib/database"
import type { User } from "@/lib/db-types"

export async function GET() {
  try {
    const users = await readData<User[]>("users.json", [])

    return NextResponse.json({
      success: true,
      data: users.map((u) => ({
        id: u.id,
        telegram_id: u.telegram_id,
        username: u.username,
        first_name: u.first_name,
        last_name: u.last_name,
        balance: u.balance,
        total_spent: u.total_spent,
        is_premium: u.is_premium,
        created_at: u.created_at,
      })),
    })
  } catch (error) {
    console.error("Get users error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to get users",
      },
      { status: 500 },
    )
  }
}
