import { NextResponse } from "next/server"
import { getAdminFromRequest, hasPermission } from "@/lib/admin-auth"
import { readData, writeData } from "@/lib/database"
import { SCHEMA, DEFAULT_CATEGORIES } from "@/lib/db-schema"
import { createLog } from "@/lib/db-helpers"
import type { DbCategory } from "@/lib/db-types"

export async function GET(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const categories = await readData<DbCategory[]>(SCHEMA.CATEGORIES, DEFAULT_CATEGORIES)

    return NextResponse.json({
      success: true,
      data: categories,
    })
  } catch (error) {
    console.error("[Admin Categories GET] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch categories" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    if (!hasPermission(admin, "manage_products")) {
      return NextResponse.json({ success: false, error: "Permission denied" }, { status: 403 })
    }

    const body = await request.json()
    const categories = await readData<DbCategory[]>(SCHEMA.CATEGORIES, DEFAULT_CATEGORIES)

    const newCategory: DbCategory = {
      id: Math.max(0, ...categories.map((c) => c.id)) + 1,
      name: body.name,
      slug: body.slug || body.name.toLowerCase().replace(/\s+/g, "-"),
      description: body.description || "",
      image_url: body.image_url || "",
      is_active: body.is_active !== false,
      sort_order: body.sort_order || categories.length,
      created_at: new Date().toISOString(),
    }

    categories.push(newCategory)
    await writeData(SCHEMA.CATEGORIES, categories)

    await createLog({
      type: "admin_action",
      action: "category_created",
      admin_id: admin.id,
      details: { category_id: newCategory.id, name: newCategory.name },
    })

    return NextResponse.json({
      success: true,
      data: newCategory,
    })
  } catch (error) {
    console.error("[Admin Categories POST] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to create category" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    if (!hasPermission(admin, "manage_products")) {
      return NextResponse.json({ success: false, error: "Permission denied" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const categoryId = Number.parseInt(searchParams.get("id") || "0")

    if (!categoryId) {
      return NextResponse.json({ success: false, error: "Category ID required" }, { status: 400 })
    }

    const body = await request.json()
    const categories = await readData<DbCategory[]>(SCHEMA.CATEGORIES, DEFAULT_CATEGORIES)

    const index = categories.findIndex((c) => c.id === categoryId)
    if (index === -1) {
      return NextResponse.json({ success: false, error: "Category not found" }, { status: 404 })
    }

    categories[index] = {
      ...categories[index],
      name: body.name ?? categories[index].name,
      slug: body.slug ?? categories[index].slug,
      description: body.description ?? categories[index].description,
      image_url: body.image_url ?? categories[index].image_url,
      is_active: body.is_active ?? categories[index].is_active,
      sort_order: body.sort_order ?? categories[index].sort_order,
    }

    await writeData(SCHEMA.CATEGORIES, categories)

    await createLog({
      type: "admin_action",
      action: "category_updated",
      admin_id: admin.id,
      details: { category_id: categoryId },
    })

    return NextResponse.json({
      success: true,
      data: categories[index],
    })
  } catch (error) {
    console.error("[Admin Categories PUT] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to update category" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    if (!hasPermission(admin, "manage_products")) {
      return NextResponse.json({ success: false, error: "Permission denied" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const categoryId = Number.parseInt(searchParams.get("id") || "0")

    if (!categoryId) {
      return NextResponse.json({ success: false, error: "Category ID required" }, { status: 400 })
    }

    const categories = await readData<DbCategory[]>(SCHEMA.CATEGORIES, DEFAULT_CATEGORIES)
    const filtered = categories.filter((c) => c.id !== categoryId)

    if (filtered.length === categories.length) {
      return NextResponse.json({ success: false, error: "Category not found" }, { status: 404 })
    }

    await writeData(SCHEMA.CATEGORIES, filtered)

    await createLog({
      type: "admin_action",
      action: "category_deleted",
      admin_id: admin.id,
      details: { category_id: categoryId },
    })

    return NextResponse.json({
      success: true,
      message: "Category deleted",
    })
  } catch (error) {
    console.error("[Admin Categories DELETE] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to delete category" }, { status: 500 })
  }
}
