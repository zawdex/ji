import { NextResponse } from "next/server"
import { getAdminFromRequest, hasPermission } from "@/lib/admin-auth"
import { readData, writeData } from "@/lib/database"
import { SCHEMA, DEFAULT_SETTINGS } from "@/lib/db-schema"
import { createLog } from "@/lib/db-helpers"

export async function GET(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const settings = await readData<Record<string, any>>(SCHEMA.SETTINGS, DEFAULT_SETTINGS)

    const formattedSettings = {
      shop_name: settings.shop_name?.value || "Turbo Gaming",
      global_markup_percentage: settings.global_markup_percentage?.value || 5,
      telegram_bot_token: settings.telegram_bot_token?.value || "",
      admin_chat_id: settings.admin_chat_id?.value || "",
      maintenance_mode: settings.maintenance_mode?.value || false,
      auto_approve_recharge: settings.auto_approve_recharge?.value || false,
    }

    return NextResponse.json({
      success: true,
      data: formattedSettings,
    })
  } catch (error) {
    console.error("[Admin Settings GET] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch settings" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    if (!hasPermission(admin, "manage_settings")) {
      return NextResponse.json({ success: false, error: "Permission denied" }, { status: 403 })
    }

    const body = await request.json()
    const settings = await readData<Record<string, any>>(SCHEMA.SETTINGS, DEFAULT_SETTINGS)

    const updatedSettings = { ...settings }
    const now = new Date().toISOString()

    for (const [key, value] of Object.entries(body)) {
      updatedSettings[key] = {
        id: key,
        value,
        updated_at: now,
        updated_by: admin.id,
      }
    }

    await writeData(SCHEMA.SETTINGS, updatedSettings)

    // Log action
    await createLog({
      type: "admin_action",
      action: "settings_updated",
      admin_id: admin.id,
      details: { updated_keys: Object.keys(body) },
    })

    return NextResponse.json({
      success: true,
      message: "Settings updated successfully",
    })
  } catch (error) {
    console.error("[Admin Settings POST] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to update settings" }, { status: 500 })
  }
}
