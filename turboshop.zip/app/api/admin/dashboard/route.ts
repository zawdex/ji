import { NextResponse } from "next/server"
import { getAdminFromRequest } from "@/lib/admin-auth"
import { readData } from "@/lib/database"
import { SCHEMA, DEFAULT_PRODUCTS } from "@/lib/db-schema"
import type { DbUser, DbOrder, DbRecharge, DbProduct } from "@/lib/db-types"

export async function GET(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    // Fetch all data
    const users = await readData<DbUser[]>(SCHEMA.USERS, [])
    const orders = await readData<DbOrder[]>(SCHEMA.ORDERS, [])
    const recharges = await readData<DbRecharge[]>(SCHEMA.RECHARGES, [])
    const products = await readData<DbProduct[]>(SCHEMA.PRODUCTS, DEFAULT_PRODUCTS)

    // Calculate stats
    const stats = {
      total_users: users.length,
      total_orders: orders.length,
      total_revenue: orders.filter((o) => o.status === "completed").reduce((sum, o) => sum + o.total_price, 0),
      pending_orders: orders.filter((o) => o.status === "pending").length,
      pending_recharges: recharges.filter((r) => r.status === "pending").length,
      total_products: products.length,
    }

    // Recent orders with user info
    const recentOrders = orders
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 10)
      .map((order) => {
        const user = users.find((u) => u.id === order.user_id)
        return {
          id: order.id,
          user_name: user ? `${user.first_name} ${user.last_name}`.trim() : "Unknown",
          product_name: order.product_snapshot?.name || "Unknown Product",
          amount: order.total_price,
          status: order.status,
          created_at: order.created_at,
        }
      })

    // Pending recharges with user info
    const pendingRecharges = recharges
      .filter((r) => r.status === "pending")
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .map((recharge) => {
        const user = users.find((u) => u.id === recharge.user_id)
        return {
          id: recharge.id,
          user_name: user ? `${user.first_name} ${user.last_name}`.trim() : "Unknown",
          amount: recharge.amount,
          payment_method: recharge.payment_method_name,
          screenshot_path: recharge.screenshot_path,
          status: recharge.status,
          created_at: recharge.created_at,
        }
      })

    return NextResponse.json({
      success: true,
      data: {
        stats,
        recent_orders: recentOrders,
        pending_recharges: pendingRecharges,
      },
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("[Admin Dashboard] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch dashboard data" }, { status: 500 })
  }
}
