import { NextResponse } from "next/server"
import { getAdminFromRequest } from "@/lib/admin-auth"
import { updateOrderStatus, createLog, getSetting } from "@/lib/db-helpers"
import { readData } from "@/lib/database"
import { SCHEMA } from "@/lib/db-schema"
import { sendTelegramNotification } from "@/lib/notifications"
import type { DbUser, DbOrder } from "@/lib/db-types"

export async function POST(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { order_id, status, admin_notes } = body

    if (!order_id || !["pending", "processing", "completed", "rejected", "refunded"].includes(status)) {
      return NextResponse.json({ success: false, error: "Invalid request" }, { status: 400 })
    }

    await updateOrderStatus(order_id, status, admin_notes)

    // Log action
    await createLog({
      type: "admin_action",
      action: `order_status_${status}`,
      admin_id: admin.id,
      details: { order_id, status, admin_notes },
    })

    // Notify user via Telegram
    const botToken = (await getSetting("telegram_bot_token")) as string
    const orders = await readData<DbOrder[]>(SCHEMA.ORDERS, [])
    const order = orders.find((o) => o.id === order_id)

    if (order && botToken) {
      const users = await readData<DbUser[]>(SCHEMA.USERS, [])
      const user = users.find((u) => u.id === order.user_id)

      if (user) {
        const statusMessages: Record<string, string> = {
          processing: `Your order #${order_id} is now being processed.`,
          completed: `Your order #${order_id} has been completed! Enjoy your purchase.`,
          rejected: `Your order #${order_id} has been rejected.${admin_notes ? ` Reason: ${admin_notes}` : ""} Your balance has been refunded.`,
          refunded: `Your order #${order_id} has been refunded. The amount has been added back to your balance.`,
        }

        const message = statusMessages[status]
        if (message) {
          await sendTelegramNotification(botToken, String(user.telegram_id), message)
        }
      }
    }

    return NextResponse.json({
      success: true,
      message: `Order status updated to ${status}`,
    })
  } catch (error) {
    console.error("[Admin Order Action] Error:", error)
    return NextResponse.json({ success: false, error: "Action failed" }, { status: 500 })
  }
}
