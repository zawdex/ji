import { NextResponse } from "next/server"
import { getAdminFromRequest } from "@/lib/admin-auth"
import { readData } from "@/lib/database"
import { SCHEMA } from "@/lib/db-schema"
import type { DbOrder, DbUser } from "@/lib/db-types"

export async function GET(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status") || "all"

    const orders = await readData<DbOrder[]>(SCHEMA.ORDERS, [])
    const users = await readData<DbUser[]>(SCHEMA.USERS, [])

    let filtered = orders
    if (status !== "all") {
      filtered = orders.filter((o) => o.status === status)
    }

    // Sort by created_at desc
    filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())

    const enriched = filtered.map((o) => {
      const user = users.find((u) => u.id === o.user_id)
      return {
        id: o.id,
        user_id: o.user_id,
        user_name: user ? `${user.first_name} ${user.last_name}`.trim() : "Unknown",
        product_id: o.product_id,
        product_name: o.product_snapshot?.name || "Unknown Product",
        total_price: o.total_price,
        status: o.status,
        payment_status: o.payment_status,
        custom_fields: o.custom_fields,
        created_at: o.created_at,
        mlbb_order_id: o.custom_fields?.mlbb_order_id,
      }
    })

    return NextResponse.json({
      success: true,
      data: enriched,
    })
  } catch (error) {
    console.error("Get orders error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to get orders",
      },
      { status: 500 },
    )
  }
}
