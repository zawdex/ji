import { NextResponse } from "next/server"
import { setCookie, deleteCookie, testCookie, getCombinedBalance, getOrderHistory, hasCookie } from "@/lib/smile-one"

// GET - Get current cookie status and balance
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const action = searchParams.get("action")

    // Check cookie status
    if (action === "status") {
      const hasSmileCookie = hasCookie()

      if (!hasSmileCookie) {
        return NextResponse.json({
          success: true,
          data: {
            configured: false,
            message: "No Smile One cookie configured",
          },
        })
      }

      // Test cookie on both platforms
      const [brlTest, phpTest] = await Promise.all([testCookie("BRL"), testCookie("PHP")])

      return NextResponse.json({
        success: true,
        data: {
          configured: true,
          platforms: {
            BRL: brlTest,
            PHP: phpTest,
          },
        },
      })
    }

    // Get balance
    if (action === "balance") {
      const balances = await getCombinedBalance()
      return NextResponse.json({
        success: true,
        data: balances,
      })
    }

    // Get order history
    if (action === "orders") {
      const platform = (searchParams.get("platform") || "BRL") as "BRL" | "PHP"
      const days = Number.parseInt(searchParams.get("days") || "7")

      const history = await getOrderHistory(platform, days)
      return NextResponse.json({
        success: history.success,
        data: history.data,
        error: history.message,
      })
    }

    return NextResponse.json(
      {
        success: false,
        error: "Invalid action",
      },
      { status: 400 },
    )
  } catch (error) {
    console.error("Smile One status error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to get Smile One status",
      },
      { status: 500 },
    )
  }
}

// POST - Save or test cookie
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { action, cookie } = body

    if (action === "save") {
      if (!cookie || typeof cookie !== "string" || cookie.trim().length === 0) {
        return NextResponse.json(
          {
            success: false,
            error: "Cookie string is required",
          },
          { status: 400 },
        )
      }

      // Save the cookie
      setCookie(cookie.trim())

      // Test on both platforms
      const [brlTest, phpTest] = await Promise.all([testCookie("BRL"), testCookie("PHP")])

      const isValid = brlTest.success || phpTest.success

      if (!isValid) {
        deleteCookie()
        return NextResponse.json(
          {
            success: false,
            error: "Cookie validation failed on both platforms. Please check your cookie.",
            details: { BRL: brlTest, PHP: phpTest },
          },
          { status: 400 },
        )
      }

      return NextResponse.json({
        success: true,
        data: {
          message: "Cookie saved and validated successfully",
          platforms: {
            BRL: brlTest,
            PHP: phpTest,
          },
        },
      })
    }

    if (action === "test") {
      if (!hasCookie()) {
        return NextResponse.json(
          {
            success: false,
            error: "No cookie configured",
          },
          { status: 400 },
        )
      }

      const [brlTest, phpTest] = await Promise.all([testCookie("BRL"), testCookie("PHP")])

      return NextResponse.json({
        success: true,
        data: {
          BRL: brlTest,
          PHP: phpTest,
        },
      })
    }

    return NextResponse.json(
      {
        success: false,
        error: "Invalid action",
      },
      { status: 400 },
    )
  } catch (error) {
    console.error("Smile One save error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to save cookie",
      },
      { status: 500 },
    )
  }
}

// DELETE - Remove cookie
export async function DELETE() {
  try {
    deleteCookie()
    return NextResponse.json({
      success: true,
      data: { message: "Cookie deleted successfully" },
    })
  } catch (error) {
    console.error("Smile One delete error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to delete cookie",
      },
      { status: 500 },
    )
  }
}
