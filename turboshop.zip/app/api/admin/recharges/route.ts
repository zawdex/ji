import { NextResponse } from "next/server"
import { getAdminFromRequest } from "@/lib/admin-auth"
import { readData } from "@/lib/database"
import { SCHEMA } from "@/lib/db-schema"
import type { DbRecharge, DbUser } from "@/lib/db-types"

export async function GET(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status")

    const recharges = await readData<DbRecharge[]>(SCHEMA.RECHARGES, [])
    const users = await readData<DbUser[]>(SCHEMA.USERS, [])

    let filtered = recharges
    if (status && status !== "all") {
      filtered = recharges.filter((r) => r.status === status)
    }

    const enriched = filtered
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .map((recharge) => {
        const user = users.find((u) => u.id === recharge.user_id)
        return {
          ...recharge,
          user_name: user ? `${user.first_name} ${user.last_name}`.trim() : "Unknown",
        }
      })

    return NextResponse.json({
      success: true,
      data: enriched,
    })
  } catch (error) {
    console.error("[Admin Recharges GET] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch recharges" }, { status: 500 })
  }
}
