import { NextResponse } from "next/server"
import { getAdminFromRequest } from "@/lib/admin-auth"
import { updateRechargeStatus, createLog, getSetting } from "@/lib/db-helpers"
import { readData } from "@/lib/database"
import { SCHEMA } from "@/lib/db-schema"
import { sendTelegramNotification } from "@/lib/notifications"
import type { DbUser, DbRecharge } from "@/lib/db-types"

export async function POST(request: Request) {
  try {
    const admin = await getAdminFromRequest(request)

    if (!admin) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { recharge_id, action, admin_notes } = body

    if (!recharge_id || !["approve", "reject"].includes(action)) {
      return NextResponse.json({ success: false, error: "Invalid request" }, { status: 400 })
    }

    const status = action === "approve" ? "approved" : "rejected"

    await updateRechargeStatus(recharge_id, status, admin.id, admin_notes)

    // Log action
    await createLog({
      type: "admin_action",
      action: `recharge_${action}`,
      admin_id: admin.id,
      details: { recharge_id, status, admin_notes },
    })

    // Notify user via Telegram
    const botToken = (await getSetting("telegram_bot_token")) as string
    const recharges = await readData<DbRecharge[]>(SCHEMA.RECHARGES, [])
    const recharge = recharges.find((r) => r.id === recharge_id)

    if (recharge && botToken) {
      const users = await readData<DbUser[]>(SCHEMA.USERS, [])
      const user = users.find((u) => u.id === recharge.user_id)

      if (user) {
        const message =
          action === "approve"
            ? `Your recharge of ${recharge.amount.toLocaleString()} MMK has been approved! Your new balance has been updated.`
            : `Your recharge request of ${recharge.amount.toLocaleString()} MMK has been rejected.${admin_notes ? ` Reason: ${admin_notes}` : ""}`

        await sendTelegramNotification(botToken, String(user.telegram_id), message)
      }
    }

    return NextResponse.json({
      success: true,
      message: `Recharge ${action}d successfully`,
    })
  } catch (error) {
    console.error("[Admin Recharge Action] Error:", error)
    return NextResponse.json({ success: false, error: "Action failed" }, { status: 500 })
  }
}
