import { NextResponse } from "next/server"
import { destroyAdminSession } from "@/lib/admin-auth"

export async function POST(request: Request) {
  try {
    const cookieHeader = request.headers.get("cookie")
    if (cookieHeader) {
      const cookies = Object.fromEntries(cookieHeader.split("; ").map((c) => c.split("=")))
      const token = cookies["admin_session"]
      if (token) {
        await destroyAdminSession(token)
      }
    }

    const response = NextResponse.json({ success: true })
    response.cookies.delete("admin_session")
    return response
  } catch (error) {
    console.error("[Admin Logout] Error:", error)
    return NextResponse.json({ success: false, error: "Logout failed" }, { status: 500 })
  }
}
