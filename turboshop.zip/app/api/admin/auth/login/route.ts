import { NextResponse } from "next/server"
import { readData, updateData } from "@/lib/database"
import { SCHEMA } from "@/lib/db-schema"
import { createAdminSession, hashPassword, createAdmin } from "@/lib/admin-auth"
import type { DbAdmin } from "@/lib/db-types"

// Default admin credentials
const DEFAULT_ADMIN_TELEGRAM_ID = 6468293575
const DEFAULT_ADMIN_PASSWORD = hashPassword("admin123")

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { telegram_id, password } = body

    if (!telegram_id || !password) {
      return NextResponse.json({ success: false, error: "Missing credentials" }, { status: 400 })
    }

    const telegramId = Number.parseInt(telegram_id)
    const hashedPassword = hashPassword(password)

    // Check for default admin first
    if (telegramId === DEFAULT_ADMIN_TELEGRAM_ID && hashedPassword === DEFAULT_ADMIN_PASSWORD) {
      // Create default admin if not exists
      const admins = await readData<DbAdmin[]>(SCHEMA.ADMINS, [])
      let admin = admins.find((a) => a.telegram_id === telegramId)

      if (!admin) {
        admin = await createAdmin({
          telegram_id: telegramId,
          username: "itachiXCoder",
          full_name: "Super Admin",
          role: "super_admin",
          permissions: ["all"],
        })
      }

      // Update last login
      await updateData<DbAdmin[]>(SCHEMA.ADMINS, [], (admins) => {
        const a = admins.find((a) => a.telegram_id === telegramId)
        if (a) {
          a.last_login = new Date().toISOString()
        }
        return admins
      })

      const token = await createAdminSession(admin.id)

      const response = NextResponse.json({
        success: true,
        data: {
          admin: {
            id: admin.id,
            username: admin.username,
            role: admin.role,
          },
        },
      })

      response.cookies.set("admin_session", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 24 * 60 * 60, // 24 hours
      })

      return response
    }

    return NextResponse.json({ success: false, error: "Invalid credentials" }, { status: 401 })
  } catch (error) {
    console.error("[Admin Login] Error:", error)
    return NextResponse.json({ success: false, error: "Login failed" }, { status: 500 })
  }
}
