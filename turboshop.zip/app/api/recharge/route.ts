import { NextResponse } from "next/server"
import { getUser, createUser, createRecharge, getSetting, createLog } from "@/lib/db-helpers"
import { readData } from "@/lib/database"
import { SCHEMA, DEFAULT_PAYMENT_METHODS } from "@/lib/db-schema"
import { sendRechargeNotification } from "@/lib/notifications"
import { promises as fs } from "fs"
import path from "path"

export async function POST(request: Request) {
  try {
    const formData = await request.formData()
    const amount = Number.parseFloat(formData.get("amount") as string)
    const paymentMethodId = Number.parseInt(formData.get("payment_method_id") as string)
    const screenshot = formData.get("screenshot") as File
    const initData = formData.get("initData") as string

    // Validate input
    if (!amount || amount <= 0) {
      return NextResponse.json({ success: false, error: "Invalid amount" }, { status: 400 })
    }

    if (!paymentMethodId) {
      return NextResponse.json({ success: false, error: "Payment method is required" }, { status: 400 })
    }

    if (!screenshot) {
      return NextResponse.json({ success: false, error: "Payment screenshot is required" }, { status: 400 })
    }

    // Validate file size (max 5MB)
    if (screenshot.size > 5 * 1024 * 1024) {
      return NextResponse.json({ success: false, error: "File size must be less than 5MB" }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"]
    if (!allowedTypes.includes(screenshot.type)) {
      return NextResponse.json(
        { success: false, error: "Only JPG, PNG, GIF, and WebP images are allowed" },
        { status: 400 },
      )
    }

    // Get user from Telegram init data
    let telegramUser = null
    if (initData && initData !== "development_mode") {
      const params = new URLSearchParams(initData)
      const userData = params.get("user")
      if (userData) {
        telegramUser = JSON.parse(userData)
      }
    }

    if (!telegramUser) {
      telegramUser = {
        id: 6468293575,
        first_name: "Itachi",
        last_name: "Uchiha",
        username: "itachiXCoder",
      }
    }

    let user = await getUser(telegramUser.id)
    if (!user) {
      user = await createUser(telegramUser.id, telegramUser)
    }

    if (user.is_banned) {
      return NextResponse.json({ success: false, error: "Account is banned" }, { status: 403 })
    }

    // Get payment method
    const paymentMethods = await readData(SCHEMA.PAYMENT_METHODS, DEFAULT_PAYMENT_METHODS)
    const paymentMethod = paymentMethods.find((m: any) => m.id === paymentMethodId)

    if (!paymentMethod || !paymentMethod.is_active) {
      return NextResponse.json({ success: false, error: "Invalid payment method" }, { status: 400 })
    }

    // Save screenshot
    const uploadsDir = path.join(process.cwd(), "public", "uploads", "screenshots")
    await fs.mkdir(uploadsDir, { recursive: true })

    const fileExt = screenshot.name.split(".").pop() || "jpg"
    const fileName = `${Date.now()}_${user.id}.${fileExt}`
    const filePath = path.join(uploadsDir, fileName)

    const buffer = Buffer.from(await screenshot.arrayBuffer())
    await fs.writeFile(filePath, buffer)

    const screenshotPath = `/uploads/screenshots/${fileName}`

    // Create recharge request
    const recharge = await createRecharge({
      user_id: user.id,
      amount,
      payment_method_id: paymentMethodId,
      payment_method_name: paymentMethod.name,
      screenshot_path: screenshotPath,
      status: "pending",
    })

    // Log action
    await createLog({
      type: "recharge",
      action: "recharge_submitted",
      user_id: user.id,
      details: {
        recharge_id: recharge.id,
        amount,
        payment_method: paymentMethod.name,
      },
    })

    // Send admin notification
    const botToken = (await getSetting("telegram_bot_token")) as string
    const adminChatId = (await getSetting("admin_chat_id")) as string

    if (botToken && adminChatId) {
      await sendRechargeNotification(botToken, adminChatId, {
        id: recharge.id,
        user_name: `${user.first_name} ${user.last_name}`.trim(),
        username: user.username,
        amount,
        payment_method: paymentMethod.name,
      })
    }

    return NextResponse.json({
      success: true,
      data: {
        recharge_id: recharge.id,
        message: "Recharge request submitted successfully. Admin will review it shortly.",
      },
      timestamp: Date.now(),
    })
  } catch (error: any) {
    console.error("[Recharge POST] Error:", error)
    return NextResponse.json(
      { success: false, error: error.message || "Failed to submit recharge request" },
      { status: 500 },
    )
  }
}
