import { NextResponse } from "next/server"
import { getTelegramUserFromRequest } from "@/lib/telegram-auth"
import { getUser, createUser, getRecharges } from "@/lib/db-helpers"

export async function GET(request: Request) {
  try {
    const telegramUser = getTelegramUserFromRequest(request)

    if (!telegramUser) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    let user = await getUser(telegramUser.id)
    if (!user) {
      user = await createUser(telegramUser.id, telegramUser)
    }

    const recharges = await getRecharges(user.id)
    const limitedRecharges = recharges.slice(0, 10)

    return NextResponse.json({
      success: true,
      data: limitedRecharges,
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("[Recharge History] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch recharge history" }, { status: 500 })
  }
}
