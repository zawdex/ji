import { NextResponse } from "next/server"
import { getTelegramUserFromRequest } from "@/lib/telegram-auth"
import {
  getUser,
  createUser,
  getProducts,
  createOrder,
  getOrders,
  updateProductStock,
  createTransaction,
  createLog,
  getSetting,
} from "@/lib/db-helpers"
import { updateData } from "@/lib/database"
import { SCHEMA } from "@/lib/db-schema"
import { sendOrderNotification } from "@/lib/notifications"
import type { DbUser } from "@/lib/db-types"

export async function GET(request: Request) {
  try {
    const telegramUser = getTelegramUserFromRequest(request)

    if (!telegramUser) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    let user = await getUser(telegramUser.id)
    if (!user) {
      user = await createUser(telegramUser.id, telegramUser)
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get("status") || "all"

    const orders = await getOrders(user.id, status)

    return NextResponse.json({
      success: true,
      data: orders,
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("[Orders GET] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch orders" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const telegramUser = getTelegramUserFromRequest(request)

    if (!telegramUser) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    let user = await getUser(telegramUser.id)
    if (!user) {
      user = await createUser(telegramUser.id, telegramUser)
    }

    if (user.is_banned) {
      return NextResponse.json({ success: false, error: "Account is banned" }, { status: 403 })
    }

    const body = await request.json()
    const { product_id, custom_fields, quantity = 1 } = body

    if (!product_id) {
      return NextResponse.json({ success: false, error: "Product ID is required" }, { status: 400 })
    }

    const products = await getProducts()
    const product = products.find((p) => p.id === product_id)

    if (!product) {
      return NextResponse.json({ success: false, error: "Product not found" }, { status: 404 })
    }

    if (product.status !== "active") {
      return NextResponse.json({ success: false, error: "Product is not available" }, { status: 400 })
    }

    if (product.stock < quantity) {
      return NextResponse.json({ success: false, error: "Insufficient stock" }, { status: 400 })
    }

    const totalPrice = product.final_price * quantity

    if (user.balance < totalPrice) {
      return NextResponse.json(
        {
          success: false,
          error: `Insufficient balance. Need ${totalPrice.toLocaleString()} MMK but only have ${user.balance.toLocaleString()} MMK`,
        },
        { status: 400 },
      )
    }

    // Create order
    const order = await createOrder({
      user_id: user.id,
      product_id,
      product_snapshot: product,
      quantity,
      unit_price: product.final_price,
      total_price: totalPrice,
      custom_fields: custom_fields || {},
      status: "pending",
      payment_status: "paid",
    })

    // Update user balance
    const newBalance = user.balance - totalPrice
    await updateData<DbUser[]>(SCHEMA.USERS, [], (users) => {
      const u = users.find((u) => u.id === user!.id)
      if (u) {
        u.balance = newBalance
        u.total_spent += totalPrice
        u.updated_at = new Date().toISOString()
      }
      return users
    })

    // Update stock
    await updateProductStock(product_id, quantity)

    // Create transaction log
    await createTransaction({
      user_id: user.id,
      type: "order",
      amount: totalPrice,
      balance_before: user.balance,
      balance_after: newBalance,
      reference_type: "order",
      reference_id: order.id,
      description: `Order #${order.id} - ${product.name}`,
    })

    // Log action
    await createLog({
      type: "order",
      action: "order_created",
      user_id: user.id,
      details: {
        order_id: order.id,
        product_id,
        product_name: product.name,
        amount: totalPrice,
      },
    })

    // Send admin notification
    const botToken = (await getSetting("telegram_bot_token")) as string
    const adminChatId = (await getSetting("admin_chat_id")) as string

    if (botToken && adminChatId) {
      await sendOrderNotification(botToken, adminChatId, {
        id: order.id,
        user_name: `${user.first_name} ${user.last_name}`.trim(),
        username: user.username,
        product_name: product.name,
        amount: totalPrice,
        status: "pending",
      })
    }

    return NextResponse.json({
      success: true,
      data: {
        order_id: order.id,
        new_balance: newBalance,
        message: "Order placed successfully",
      },
      timestamp: Date.now(),
    })
  } catch (error: any) {
    console.error("[Orders POST] Error:", error)
    return NextResponse.json({ success: false, error: error.message || "Failed to place order" }, { status: 500 })
  }
}
