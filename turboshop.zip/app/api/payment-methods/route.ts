import { NextResponse } from "next/server"

const paymentMethods = [
  {
    id: 1,
    name: "KBZ Pay",
    account_info: "09XXXXXXXXX",
    instructions: "Send payment with your user ID as reference",
    status: "active",
  },
  {
    id: 2,
    name: "Wave Money",
    account_info: "09XXXXXXXXX",
    instructions: "Include your user ID in payment note",
    status: "active",
  },
  {
    id: 3,
    name: "CB Bank",
    account_info: "1234567890",
    instructions: "Transfer with user ID as description",
    status: "active",
  },
]

export async function GET() {
  return NextResponse.json({
    success: true,
    data: paymentMethods,
    timestamp: Date.now(),
  })
}
