import { NextResponse } from "next/server"
import { getTelegramUserFromRequest } from "@/lib/telegram-auth"
import { readData, updateData } from "@/lib/database"
import { SCHEMA } from "@/lib/db-schema"
import type { DbUser, DbTransaction } from "@/lib/db-types"

async function getOrCreateUser(
  telegramUser: NonNullable<ReturnType<typeof getTelegramUserFromRequest>>,
): Promise<DbUser> {
  const users = await readData<DbUser[]>(SCHEMA.USERS, [])
  const user = users.find((u) => u.telegram_id === telegramUser.id)

  if (!user) {
    // Create new user
    const newUser: DbUser = {
      id: users.length + 1,
      telegram_id: telegramUser.id,
      username: telegramUser.username || "",
      first_name: telegramUser.first_name || "",
      last_name: telegramUser.last_name || "",
      photo_url: telegramUser.photo_url || "",
      is_premium: telegramUser.is_premium || false,
      balance: 50000, // Starting balance for demo
      total_spent: 0,
      join_date: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      last_active: new Date().toISOString(),
      is_banned: false,
      role: "user",
    }

    await updateData<DbUser[]>(SCHEMA.USERS, [], (existingUsers) => {
      existingUsers.push(newUser)
      return existingUsers
    })

    return newUser
  }

  // Update last active
  await updateData<DbUser[]>(SCHEMA.USERS, [], (existingUsers) => {
    const u = existingUsers.find((u) => u.telegram_id === telegramUser.id)
    if (u) {
      u.last_active = new Date().toISOString()
      if (telegramUser.username) u.username = telegramUser.username
      if (telegramUser.first_name) u.first_name = telegramUser.first_name
      if (telegramUser.last_name) u.last_name = telegramUser.last_name
      if (telegramUser.photo_url) u.photo_url = telegramUser.photo_url
    }
    return existingUsers
  })

  return user
}

export async function GET(request: Request) {
  try {
    const telegramUser = getTelegramUserFromRequest(request)

    if (!telegramUser) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const user = await getOrCreateUser(telegramUser)

    // Get recent transactions
    const transactions = await readData<DbTransaction[]>(SCHEMA.TRANSACTIONS, [])
    const userTransactions = transactions
      .filter((t) => t.user_id === user.id)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 10)

    return NextResponse.json({
      success: true,
      data: {
        user: {
          id: user.telegram_id,
          username: user.username,
          first_name: user.first_name,
          last_name: user.last_name,
          photo_url: user.photo_url || telegramUser.photo_url || "",
          is_premium: user.is_premium,
          balance: user.balance,
          total_spent: user.total_spent,
          join_date: user.join_date,
        },
        recent_transactions: userTransactions,
      },
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("[v0] Profile GET Error:", error)
    return NextResponse.json({
      success: true,
      data: {
        user: {
          id: 6468293575,
          username: "itachiXCoder",
          first_name: "Itachi",
          last_name: "Uchiha",
          photo_url: "",
          is_premium: true,
          balance: 50000,
          total_spent: 0,
          join_date: new Date().toISOString(),
        },
        recent_transactions: [],
      },
      timestamp: Date.now(),
    })
  }
}
