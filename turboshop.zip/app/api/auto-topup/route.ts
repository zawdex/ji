import { NextResponse } from "next/server"
import { getProducts, getUser, createOrder, updateUserBalance, createTransaction } from "@/lib/db-helpers"
import { getTelegramUserFromRequest } from "@/lib/telegram-auth"
import { autoTopup as smileOneAutoTopup, hasCookie, checkRole, type Platform } from "@/lib/smile-one"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { product_id, custom_fields } = body

    const telegramUser = getTelegramUserFromRequest(request)
    if (!telegramUser) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    const user = await getUser(telegramUser.id)
    if (!user) {
      return NextResponse.json({ success: false, error: "User not found" }, { status: 404 })
    }

    if (!product_id) {
      return NextResponse.json(
        {
          success: false,
          error: "Product ID is required",
        },
        { status: 400 },
      )
    }

    const products = await getProducts()
    const product = products.find((p) => p.id === product_id)
    if (!product) {
      return NextResponse.json(
        {
          success: false,
          error: "Product not found",
        },
        { status: 404 },
      )
    }

    if (product.category !== "Mobile Legends") {
      return NextResponse.json(
        {
          success: false,
          error: "Auto top-up only available for Mobile Legends",
        },
        { status: 400 },
      )
    }

    const accountId = custom_fields?.account_id
    const serverId = custom_fields?.server_id

    if (!accountId || !serverId) {
      return NextResponse.json(
        {
          success: false,
          error: "Account ID and Server ID are required",
        },
        { status: 400 },
      )
    }

    if (user.balance < product.final_price) {
      return NextResponse.json(
        {
          success: false,
          error: "Insufficient balance",
        },
        { status: 400 },
      )
    }

    let mlbbOrderId: string
    let username: string
    let topupSuccess = false

    if (hasCookie()) {
      // First verify the account
      const roleCheck = await checkRole(accountId, serverId)
      if (roleCheck.status !== "success") {
        return NextResponse.json(
          {
            success: false,
            error: roleCheck.message || "Invalid MLBB account",
          },
          { status: 400 },
        )
      }

      // Get product PID and platform from product metadata or use defaults
      const pid = product.metadata?.pid || "25"
      const platform = (product.metadata?.platform || "BRL") as Platform

      // Perform auto top-up
      const topupResult = await smileOneAutoTopup(accountId, serverId, pid, platform)

      if (topupResult.status === "success") {
        mlbbOrderId = topupResult.flow_id || `MLBB-${Date.now()}`
        username = topupResult.username || roleCheck.name || `Player_${accountId.substring(0, 4)}`
        topupSuccess = true
      } else {
        return NextResponse.json(
          {
            success: false,
            error: topupResult.message || "Auto top-up failed",
          },
          { status: 400 },
        )
      }
    } else {
      // Simulate when no cookie (demo mode)
      mlbbOrderId = `MLBB-DEMO-${Date.now()}`
      username = `Player_${accountId.substring(0, 4)}`
      topupSuccess = true
    }

    if (!topupSuccess) {
      return NextResponse.json(
        {
          success: false,
          error: "Auto top-up failed",
        },
        { status: 500 },
      )
    }

    const newBalance = user.balance - product.final_price

    const order = await createOrder({
      user_id: user.id,
      product_id,
      product_snapshot: product,
      quantity: 1,
      unit_price: product.final_price,
      total_price: product.final_price,
      custom_fields: {
        ...custom_fields,
        mlbb_order_id: mlbbOrderId,
        mlbb_username: username,
      },
      status: "completed",
      payment_status: "paid",
    })

    await updateUserBalance(user.id, product.final_price, "subtract")

    await createTransaction({
      user_id: user.id,
      type: "order",
      amount: product.final_price,
      balance_before: user.balance,
      balance_after: newBalance,
      reference_type: "order",
      reference_id: order.id,
      description: `Auto top-up: ${product.name}`,
    })

    return NextResponse.json({
      success: true,
      data: {
        order_id: order.id,
        new_balance: newBalance,
        mlbb_order_id: mlbbOrderId,
        username,
        message: hasCookie()
          ? "Auto top-up completed successfully"
          : "Order placed successfully (Demo Mode - No Smile One cookie configured)",
      },
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("Auto topup error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to process auto top-up",
      },
      { status: 500 },
    )
  }
}
