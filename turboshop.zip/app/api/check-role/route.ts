import { NextResponse } from "next/server"
import { checkRole, hasCookie } from "@/lib/smile-one"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { account_id, server_id } = body

    if (!account_id || !server_id) {
      return NextResponse.json(
        {
          success: false,
          error: "Account ID and Server ID are required",
        },
        { status: 400 },
      )
    }

    // Validate format
    if (!/^\d+$/.test(account_id) || !/^\d+$/.test(server_id)) {
      return NextResponse.json(
        {
          success: false,
          error: "Account ID and Server ID must contain only numbers",
        },
        { status: 400 },
      )
    }

    if (hasCookie()) {
      const result = await checkRole(account_id, server_id)
      return NextResponse.json({
        success: true,
        data: result,
        timestamp: Date.now(),
      })
    }

    // Fallback simulation when no cookie configured
    const isValidAccount = account_id.length >= 5 && Number.parseInt(server_id) >= 1000

    if (isValidAccount) {
      return NextResponse.json({
        success: true,
        data: {
          status: "success",
          name: `Player_${account_id.substring(0, 4)}`,
          user_id: account_id,
          zone_id: server_id,
          message: "Role verified successfully (Demo Mode)",
        },
        timestamp: Date.now(),
      })
    }

    return NextResponse.json({
      success: true,
      data: {
        status: "error",
        message: "Invalid User ID or Zone ID. Please check your account details.",
      },
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("Role check error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to check role",
      },
      { status: 500 },
    )
  }
}
