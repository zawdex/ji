import { NextResponse } from "next/server"
import { readData, writeData } from "@/lib/database"
import { SCHEMA, DEFAULT_PRODUCTS } from "@/lib/db-schema"
import type { DbProduct } from "@/lib/db-types"

// Game images mapping
const gameImages: Record<string, string> = {
  mlbb: "https://i.ibb.co/QC8TrMw/bb30f2f164a3.jpg",
  pubg: "https://i.ibb.co/YbP7CtB/b372a0e576e8.jpg",
  freefire: "https://i.ibb.co/qWrsMtL/682a414a76c7.jpg",
}

// Input fields for games
const inputFields: Record<string, Array<{ label: string; type: string; placeholder: string; instructions: string }>> = {
  mlbb: [
    {
      label: "Account ID",
      type: "number",
      placeholder: "Enter your Account ID",
      instructions: "Your Mobile Legends Account ID",
    },
    {
      label: "Server ID",
      type: "text",
      placeholder: "Enter your Server ID",
      instructions: "Your Mobile Legends Server ID (e.g., 8001)",
    },
  ],
  pubg: [
    {
      label: "Player ID",
      type: "text",
      placeholder: "Enter your Player ID",
      instructions: "Your PUBG Mobile Player ID",
    },
  ],
  freefire: [
    { label: "Player ID", type: "text", placeholder: "Enter your Player ID", instructions: "Your Free Fire Player ID" },
  ],
}

// Default products data
const defaultProducts = [
  {
    id: 1,
    name: "Mobile Legends - 11 Diamonds",
    category_name: "Mobile Legends",
    final_price: 850,
    base_price: 850,
    stock: 100,
    image_url: gameImages.mlbb,
    description: "11 Diamonds for Mobile Legends",
    input_fields: inputFields.mlbb,
    status: "active",
    game_data: { pid: "212", amount: "11 Diamonds", platform: "PHP" },
  },
  {
    id: 2,
    name: "Mobile Legends - 86 Diamonds",
    category_name: "Mobile Legends",
    final_price: 5000,
    base_price: 5000,
    stock: 100,
    image_url: gameImages.mlbb,
    description: "86 Diamonds for Mobile Legends",
    input_fields: inputFields.mlbb,
    status: "active",
    game_data: { pid: "13", amount: "86 Diamonds", platform: "BRL" },
  },
  {
    id: 3,
    name: "Mobile Legends - 100 Diamonds",
    category_name: "Mobile Legends",
    final_price: 8000,
    base_price: 8000,
    stock: 100,
    image_url: gameImages.mlbb,
    description: "100 Diamonds for Mobile Legends",
    input_fields: inputFields.mlbb,
    status: "active",
    game_data: { pid: "25", amount: "100 Diamonds", platform: "BRL" },
  },
  {
    id: 4,
    name: "PUBG Mobile - 60 UC",
    category_name: "PUBG Mobile",
    final_price: 4150,
    base_price: 4150,
    stock: 100,
    image_url: gameImages.pubg,
    description: "60 UC for PUBG Mobile",
    input_fields: inputFields.pubg,
    status: "active",
    game_data: { amount: "60 UC" },
  },
  {
    id: 5,
    name: "PUBG Mobile - 100 UC",
    category_name: "PUBG Mobile",
    final_price: 6500,
    base_price: 6500,
    stock: 100,
    image_url: gameImages.pubg,
    description: "100 UC for PUBG Mobile",
    input_fields: inputFields.pubg,
    status: "active",
    game_data: { amount: "100 UC" },
  },
  {
    id: 6,
    name: "Free Fire - 100 Diamonds",
    category_name: "Free Fire",
    final_price: 4500,
    base_price: 4500,
    stock: 100,
    image_url: gameImages.freefire,
    description: "100 Diamonds for Free Fire",
    input_fields: inputFields.freefire,
    status: "active",
    game_data: { amount: "100 Diamonds" },
  },
]

async function initializeProducts(): Promise<DbProduct[]> {
  try {
    const products = await readData<DbProduct[]>(SCHEMA.PRODUCTS, [])
    if (!products || products.length === 0) {
      await writeData(SCHEMA.PRODUCTS, DEFAULT_PRODUCTS)
      return DEFAULT_PRODUCTS
    }
    return products
  } catch (error) {
    console.error("[v0] Error initializing products:", error)
    return DEFAULT_PRODUCTS
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const status = searchParams.get("status")

    let products = await initializeProducts()

    // Filter by category if specified
    if (category) {
      products = products.filter((p) => p.category_name.toLowerCase() === category.toLowerCase())
    }

    // Filter by status (default to active only for public API)
    if (status) {
      products = products.filter((p) => p.status === status)
    } else {
      products = products.filter((p) => p.status === "active")
    }

    // Transform for frontend compatibility
    const transformedProducts = products.map((p) => ({
      id: p.id,
      name: p.name,
      category: p.category_name,
      price: p.final_price,
      base_price: p.base_price,
      stock: p.stock,
      image_url: p.image_url,
      description: p.description,
      input_fields: p.input_fields,
      status: p.status,
      game_data: p.game_data,
    }))

    return NextResponse.json({
      success: true,
      data: transformedProducts,
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("[v0] Products GET Error:", error)
    return NextResponse.json({
      success: true,
      data: [],
      timestamp: Date.now(),
    })
  }
}
