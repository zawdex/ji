import { NextResponse } from "next/server"
import { getTelegramUserFromRequest } from "@/lib/telegram-auth"
import { getUser, createUser, getTransactions } from "@/lib/db-helpers"

export async function GET(request: Request) {
  try {
    const telegramUser = getTelegramUserFromRequest(request)

    if (!telegramUser) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 })
    }

    let user = await getUser(telegramUser.id)
    if (!user) {
      user = await createUser(telegramUser.id, telegramUser)
    }

    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "20")

    const transactions = await getTransactions(user.id, limit)

    return NextResponse.json({
      success: true,
      data: transactions,
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("[Transactions GET] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch transactions" }, { status: 500 })
  }
}
