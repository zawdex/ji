import { NextResponse } from "next/server"
import { readData } from "@/lib/database"
import { SCHEMA, DEFAULT_CATEGORIES, DEFAULT_PRODUCTS } from "@/lib/db-schema"
import type { DbCategory, DbProduct } from "@/lib/db-types"

export async function GET() {
  try {
    const categories = await readData<DbCategory[]>(SCHEMA.CATEGORIES, DEFAULT_CATEGORIES)
    const products = await readData<DbProduct[]>(SCHEMA.PRODUCTS, DEFAULT_PRODUCTS)

    // Calculate product count for each category
    const categoriesWithCount = categories
      .filter((c) => c.is_active)
      .map((category) => {
        const productCount = products.filter((p) => p.category_name === category.name && p.status === "active").length

        return {
          id: category.id,
          name: category.name,
          icon: category.icon,
          product_count: productCount,
          image_url: category.image_url,
          description: category.description,
        }
      })
      .sort((a, b) => a.id - b.id)

    return NextResponse.json({
      success: true,
      data: categoriesWithCount,
      timestamp: Date.now(),
    })
  } catch (error) {
    console.error("[Categories GET] Error:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch categories" }, { status: 500 })
  }
}
