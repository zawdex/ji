import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// In-memory rate limiting (for edge runtime compatibility)
const requestCounts = new Map<string, { count: number; resetTime: number }>()

const RATE_LIMITS = {
  api: { windowMs: 60000, maxRequests: 100 },
  admin: { windowMs: 60000, maxRequests: 50 },
  auth: { windowMs: 300000, maxRequests: 10 },
}

function getRateLimit(pathname: string) {
  if (pathname.includes("/auth")) return RATE_LIMITS.auth
  if (pathname.startsWith("/admin")) return RATE_LIMITS.admin
  return RATE_LIMITS.api
}

function checkRateLimit(ip: string, pathname: string): { allowed: boolean; remaining: number } {
  const config = getRateLimit(pathname)
  const now = Date.now()
  const key = `${ip}:${pathname.split("/").slice(0, 3).join("/")}`

  const record = requestCounts.get(key)

  if (!record || now > record.resetTime) {
    requestCounts.set(key, { count: 1, resetTime: now + config.windowMs })
    return { allowed: true, remaining: config.maxRequests - 1 }
  }

  if (record.count >= config.maxRequests) {
    return { allowed: false, remaining: 0 }
  }

  record.count++
  return { allowed: true, remaining: config.maxRequests - record.count }
}

export async function middleware(request: NextRequest) {
  const ip = request.ip || request.headers.get("x-forwarded-for")?.split(",")[0] || "unknown"
  const pathname = request.nextUrl.pathname

  // Security headers
  const response = NextResponse.next()
  response.headers.set("X-Content-Type-Options", "nosniff")
  response.headers.set("X-Frame-Options", "DENY")
  response.headers.set("X-XSS-Protection", "1; mode=block")
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin")

  // Rate limiting for API routes
  if (pathname.startsWith("/api/")) {
    const { allowed, remaining } = checkRateLimit(ip, pathname)

    response.headers.set("X-RateLimit-Remaining", String(remaining))

    if (!allowed) {
      return NextResponse.json(
        { success: false, error: "Too many requests. Please try again later." },
        {
          status: 429,
          headers: {
            "Retry-After": "60",
            "X-RateLimit-Remaining": "0",
          },
        },
      )
    }
  }

  // Admin route protection
  if (pathname.startsWith("/admin") && !pathname.startsWith("/admin/login")) {
    const adminSession = request.cookies.get("admin_session")

    if (!adminSession) {
      return NextResponse.redirect(new URL("/admin/login", request.url))
    }
  }

  // Block suspicious user agents
  const userAgent = request.headers.get("user-agent") || ""
  const suspiciousAgents = ["sqlmap", "nikto", "nessus", "masscan"]

  if (suspiciousAgents.some((agent) => userAgent.toLowerCase().includes(agent))) {
    return NextResponse.json({ success: false, error: "Access denied" }, { status: 403 })
  }

  return response
}

export const config = {
  matcher: ["/api/:path*", "/admin/:path*"],
}
